# Kalibrasi Pro

Aplikasi manajemen kalibrasi alat kesehatan klinik. Bagian dari ekosistem
**TeknoMedis** (MedOps Pro, UnitCost Pro, CaseMix Pro, Kalibrasi Pro).

Dulu tergabung di MedOps Pro sebagai modul — sejak v1.0 dipisah jadi
produk standalone agar klinik yang hanya butuh tracking kalibrasi tidak
perlu beli seluruh MedOps Pro.

## Fitur

- **Dashboard** — ringkasan alkes, jadwal kalibrasi akan datang, alert overdue
- **Master Alkes** — CRUD alat kesehatan (tensimeter, stetoskop, defibrillator, dll.) per unit/ruangan
- **Vendor Kalibrasi** — direktori penyedia jasa kalibrasi beserta akreditasi KAN
- **Harga Kalibrasi** — mapping harga per alkes × vendor
- **Jadwal** — otomatis hitung jatuh tempo dari `last_calibration + interval`
- **Riwayat Kalibrasi** — history lengkap dengan sertifikat (PDF upload)
- **Laporan** — export Excel per periode / vendor / unit
- **Audit Log** — siapa ubah apa kapan

## Arsitektur

```
[ Kalibrasi Pro :8100 ]  ← runs on clinic PC, standalone
        ↓
[ license_manager ]       ← shared HWID + Fernet with all TeknoMedis products
        ↓
[ data/kalibrasi.db ]     ← SQLite, isolated per-clinic
```

License dan pembayaran dikelola oleh **TeknoMedis Hub**, bukan aplikasi
ini. Kalibrasi Pro hanya validasi lisensi lokal di setiap API request;
kalau expired / revoked, API mengembalikan 403 dan UI minta user buka Hub.

## Port

**8100** (set via env `PORT`). Match port yang terdaftar di
`teknomedis-hub/hub_manager.py INSTALL_DEFAULTS`.

## Setup

```bash
pip install -r requirements.txt
./start.sh          # production
./start.sh demo     # seed demo data (6 units, 2 vendors, 3 alkes)
```

Default logins di demo seed:
- `admin` / `admin123`
- `direktur` / `direktur123`
- `ugd` / `1234`, `rawatjalan` / `1234`, ... (per unit)

## Database schema

7 tabel total:
- `units` — ruangan/departemen klinik (UGD, Poli, ICU, ...)
- `users` — admin, direktur, per-unit
- `audit_log` — trail semua aksi
- `alkes` — inventory alat kesehatan
- `calibration_vendors` — direktori vendor kalibrasi
- `calibration_prices` — harga kalibrasi (alkes × vendor)
- `calibrations` — history kalibrasi dengan sertifikat
- `calibration_schedules` — jadwal jatuh tempo

## Related repos

- [teknomedis-hub](https://github.com/FariszAkbar/teknomedis-hub) — catalog + launcher + payment
- [teknomedis-license](https://github.com/FariszAkbar/teknomedis-license) — license + admin panel
- [teknomedis-brand](https://github.com/FariszAkbar/teknomedis-brand) — logos & colors
- [medops-pro](https://github.com/FariszAkbar/medops-pro) — ATK/RTK management
- [unitcost-pro](https://github.com/FariszAkbar/unitcost-pro) — unit cost calculation
