"""Kalibrasi Pro — medical equipment calibration management.

Standalone product. License is validated locally via license_manager
(shared HWID + Fernet with all TeknoMedis products). Unlike MedOps,
the "Lisensi" UI lives in the Hub, not in the product itself — so this
app only checks that a valid license exists before serving data.
"""
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from db_manager import init_db, seed_data
from helpers import safe_db
from license_manager import (
    validate_license,
    update_online_check,
    get_hardware_id,
    format_hwid,
    get_license_info,
)
from routes import auth, master, calibration
import os
import json
import logging

APP_VERSION = '1.0.0'
PRODUCT_CODE = 'kalibrasi'


def get_license_server_url():
    url = os.environ.get('LICENSE_SERVER', '')
    if not url:
        cfg_path = os.path.join(os.path.dirname(__file__), 'data', 'config.json')
        if os.path.exists(cfg_path):
            try:
                with open(cfg_path) as f:
                    url = json.load(f).get('license_server', '')
            except Exception:
                pass
    return url or 'http://localhost:8061'


app = Flask(__name__, static_folder='.', static_url_path='')
app.secret_key = os.environ.get('SECRET_KEY', 'kalibrasi-pro-secret-2026')
CORS(app)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

app.register_blueprint(auth.bp)
app.register_blueprint(master.bp)
app.register_blueprint(calibration.bp)


@app.errorhandler(Exception)
def handle_error(e):
    logger.exception(f"Unhandled error: {e}")
    return jsonify({'ok': False, 'error': 'Internal server error'}), 500


# ===================== LICENSE GUARD =====================
# Every API request passes through this. If the local license is missing,
# expired, or mismatched, we 403 the caller; the frontend should then
# show a "hubungi admin" page (no in-product renewal UI — that's the Hub).
@app.before_request
def check_license():
    path = request.path
    # Allow the landing page, login, version probe, and the license status
    # read so the UI can render a nice "no license" banner.
    if path in ('/', '/api/login', '/api/license', '/api/version', '/api/restart'):
        return
    if not path.startswith('/api/'):
        return
    revoked_file = os.path.join(os.path.dirname(__file__), 'data', '.revoked')
    if os.path.exists(revoked_file):
        return jsonify({
            'ok': False, 'error': 'LICENSE_REVOKED',
            'license': {'valid': False, 'status': 'revoked',
                        'message': 'Lisensi dicabut. Hubungi admin TeknoMedis.'}
        }), 403
    lic = validate_license()
    if not lic['valid']:
        return jsonify({'ok': False, 'error': 'LICENSE_INVALID', 'license': lic}), 403


# ===================== LICENSE STATUS (read-only) =====================
@app.route('/api/license')
@safe_db
def license_status():
    info = get_license_info()
    revoked_file = os.path.join(os.path.dirname(__file__), 'data', '.revoked')
    if os.path.exists(revoked_file):
        info['valid'] = False
        info['status'] = 'revoked'
        info['message'] = 'Lisensi dicabut. Hubungi admin.'
    return jsonify(info)


# ===================== VERSION =====================
@app.route('/api/version')
def get_version():
    return jsonify({'version': APP_VERSION, 'product': PRODUCT_CODE})


# ===================== PING (heartbeat to license server) =====================
@app.route('/api/ping', methods=['POST'])
@safe_db
def ping_license_server():
    """Phone home so admin panel can track last-seen / app version.
    Best-effort only — never fails the caller."""
    import urllib.request as urllib_req
    try:
        hwid = get_hardware_id()
        payload = json.dumps({
            'hwid': hwid, 'app_version': APP_VERSION, 'product': PRODUCT_CODE,
        }).encode()
        req = urllib_req.Request(
            f'{get_license_server_url()}/ping', data=payload,
            headers={'Content-Type': 'application/json'}, method='POST',
        )
        urllib_req.urlopen(req, timeout=5).read()
        update_online_check()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)})


# ===================== STATIC =====================
@app.route('/')
@safe_db
def index():
    return send_from_directory('.', 'index.html')


# ===================== STARTUP =====================
if __name__ == '__main__':
    import sys
    demo = '--demo' in sys.argv
    port = int(os.environ.get('PORT', 8100))

    init_db()
    seed_data(demo=demo)
    lic = get_license_info()
    print("\n" + "=" * 50)
    print(f"  Kalibrasi Pro v{APP_VERSION} — Server Running")
    print("=" * 50)
    print(f"  Mode:    {'DEMO' if demo else 'PRODUCTION'}")
    print(f"  Local:   http://localhost:{port}")
    print(f"  LAN:     http://0.0.0.0:{port}")
    print(f"  HWID:    {lic['hwid']}")
    print(f"  License: {lic['status'].upper()}")
    if lic.get('data'):
        print(f"  Clinic:  {lic['data'].get('clinic', '-')}")
        print(f"  Expires: {(lic['data'].get('expires', '-') or '-')[:10]}")
    print("=" * 50 + "\n")
    app.run(host='0.0.0.0', port=port, debug=False)
