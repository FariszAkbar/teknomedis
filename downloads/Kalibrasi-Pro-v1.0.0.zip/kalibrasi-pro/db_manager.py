"""Kalibrasi Pro — database manager.

Schema scope: medical-equipment calibration tracking. Tables are a
subset of the (now retired) MedOps Pro calibration module, extracted
so Kalibrasi Pro ships as an independent product with its own DB.
"""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'data', 'kalibrasi.db')


def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def log_audit(user_id, user_name, action, entity, entity_id='', detail=''):
    """Append one row to audit_log. Silent on errors (never block caller)."""
    from datetime import datetime
    try:
        conn = get_db()
        conn.execute("""
            INSERT INTO audit_log (timestamp, user_id, user_name, action, entity, entity_id, detail)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (datetime.now().isoformat(), user_id, user_name, action, entity, entity_id, detail))
        conn.commit()
        conn.close()
    except Exception:
        pass


def init_db():
    conn = get_db()
    c = conn.cursor()
    c.executescript("""
    -- ==================== UNITS (lokasi/ruangan klinik) ====================
    CREATE TABLE IF NOT EXISTS units (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE
    );

    -- ==================== USERS & AUTH ====================
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'unit' CHECK(role IN ('admin','direktur','unit')),
        unit_id TEXT,
        display_name TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (unit_id) REFERENCES units(id)
    );

    -- ==================== AUDIT LOG ====================
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        user_id TEXT NOT NULL DEFAULT '',
        user_name TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        entity TEXT NOT NULL,
        entity_id TEXT NOT NULL DEFAULT '',
        detail TEXT NOT NULL DEFAULT ''
    );

    -- ==================== ALAT KESEHATAN ====================
    CREATE TABLE IF NOT EXISTS alkes (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Lainnya',
        brand TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '',
        serial_number TEXT NOT NULL DEFAULT '',
        unit_id TEXT,
        purchase_date TEXT NOT NULL DEFAULT '',
        purchase_price INTEGER NOT NULL DEFAULT 0,
        condition TEXT NOT NULL DEFAULT 'Baik' CHECK(condition IN ('Baik','Rusak Ringan','Rusak Berat','Tidak Aktif')),
        calibration_interval INTEGER NOT NULL DEFAULT 12,
        last_calibration TEXT NOT NULL DEFAULT '',
        next_calibration TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (unit_id) REFERENCES units(id)
    );

    -- ==================== VENDOR KALIBRASI ====================
    CREATE TABLE IF NOT EXISTS calibration_vendors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        accreditation TEXT NOT NULL DEFAULT '',
        contact TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        specialization TEXT NOT NULL DEFAULT 'Umum'
    );

    CREATE TABLE IF NOT EXISTS calibration_prices (
        id TEXT PRIMARY KEY,
        alkes_id TEXT NOT NULL,
        vendor_id TEXT NOT NULL,
        price INTEGER NOT NULL DEFAULT 0,
        is_default INTEGER NOT NULL DEFAULT 0,
        UNIQUE(alkes_id, vendor_id),
        FOREIGN KEY (alkes_id) REFERENCES alkes(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES calibration_vendors(id) ON DELETE CASCADE
    );

    -- ==================== HISTORY KALIBRASI ====================
    CREATE TABLE IF NOT EXISTS calibrations (
        id TEXT PRIMARY KEY,
        alkes_id TEXT NOT NULL,
        vendor_id TEXT,
        date TEXT NOT NULL,
        result TEXT NOT NULL DEFAULT 'Laik Pakai' CHECK(result IN ('Laik Pakai','Tidak Laik','Kalibrasi Ulang')),
        certificate_no TEXT NOT NULL DEFAULT '',
        certificate_file TEXT NOT NULL DEFAULT '',
        cost INTEGER NOT NULL DEFAULT 0,
        technician TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '',
        next_due TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (alkes_id) REFERENCES alkes(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES calibration_vendors(id)
    );

    -- ==================== JADWAL KALIBRASI ====================
    CREATE TABLE IF NOT EXISTS calibration_schedules (
        id TEXT PRIMARY KEY,
        alkes_id TEXT NOT NULL,
        due_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','completed','overdue','cancelled')),
        assigned_vendor TEXT,
        notes TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (alkes_id) REFERENCES alkes(id) ON DELETE CASCADE,
        FOREIGN KEY (assigned_vendor) REFERENCES calibration_vendors(id)
    );

    -- ==================== INDEXES ====================
    CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity, entity_id);
    CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(timestamp);
    CREATE INDEX IF NOT EXISTS idx_alkes_unit ON alkes(unit_id);
    CREATE INDEX IF NOT EXISTS idx_alkes_category ON alkes(category);
    CREATE INDEX IF NOT EXISTS idx_alkes_next_cal ON alkes(next_calibration);
    CREATE INDEX IF NOT EXISTS idx_cal_alkes ON calibrations(alkes_id);
    CREATE INDEX IF NOT EXISTS idx_cal_date ON calibrations(date);
    CREATE INDEX IF NOT EXISTS idx_cal_vendor ON calibrations(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_calp_alkes ON calibration_prices(alkes_id);
    CREATE INDEX IF NOT EXISTS idx_calp_vendor ON calibration_prices(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_cals_alkes ON calibration_schedules(alkes_id);
    CREATE INDEX IF NOT EXISTS idx_cals_due ON calibration_schedules(due_date);
    CREATE INDEX IF NOT EXISTS idx_cals_status ON calibration_schedules(status);
    """)
    conn.commit()
    conn.close()


def seed_data(demo=False):
    """Seed admin/direktur users. In demo mode also inserts sample units + one alkes."""
    conn = get_db()
    c = conn.cursor()
    if c.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0:
        conn.close()
        return

    from werkzeug.security import generate_password_hash
    c.executemany("INSERT INTO users VALUES (?,?,?,?,?,?)", [
        ('usr_admin', 'admin', generate_password_hash('admin123'), 'admin', None, 'Administrator'),
        ('usr_direktur', 'direktur', generate_password_hash('direktur123'), 'direktur', None, 'Direktur Klinik'),
    ])

    if not demo:
        conn.commit()
        conn.close()
        print("[DB] Production seed: admin + direktur users created")
        return

    units = [
        ('u1', 'UGD'), ('u2', 'Rawat Jalan'), ('u3', 'Rawat Inap'),
        ('u4', 'Radiologi'), ('u5', 'Laboratorium'), ('u6', 'ICU'),
    ]
    c.executemany("INSERT INTO units VALUES (?,?)", units)
    for u in units:
        uid = f'usr_{u[0]}'
        uname = u[1].lower().replace(' ', '')
        c.execute("INSERT INTO users VALUES (?,?,?,?,?,?)",
                  (uid, uname, generate_password_hash('1234'), 'unit', u[0], u[1]))

    vendors = [
        ('cv1', 'Balai Pengamanan Fasilitas Kesehatan', 'KAN LK-001', '021-5201234', 'Jakarta', 'Umum'),
        ('cv2', 'PT. Kalibrasi Mandiri', 'KAN LK-045', '021-7894561', 'Bekasi', 'Elektromedik'),
    ]
    c.executemany("INSERT INTO calibration_vendors VALUES (?,?,?,?,?,?)", vendors)

    alkes = [
        ('a1', 'Tensimeter Digital', 'Monitoring Pasien', 'Omron', 'HEM-7120', 'OMR-001234',
         'u1', '2024-06-15', 1500000, 'Baik', 12, '2026-01-15', '2027-01-15', ''),
        ('a2', 'Stetoskop Cardiology', 'Pemeriksaan Dasar', 'Littmann', 'III', 'LTM-3322',
         'u2', '2023-03-10', 2800000, 'Baik', 24, '2025-10-01', '2027-10-01', ''),
        ('a3', 'Defibrillator', 'Kritis', 'Philips', 'HeartStart FRx', 'PHI-5501',
         'u6', '2024-01-20', 35000000, 'Baik', 12, '2026-02-01', '2027-02-01', ''),
    ]
    c.executemany("INSERT INTO alkes VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", alkes)

    conn.commit()
    conn.close()
    print("[DB] Demo seed: 6 units, 2 vendors, 3 alkes, 7 users")


if __name__ == '__main__':
    init_db()
    seed_data(demo='--demo' in __import__('sys').argv)
