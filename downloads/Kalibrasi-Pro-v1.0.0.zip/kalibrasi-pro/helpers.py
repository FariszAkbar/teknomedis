"""Shared helpers: validation, formatting, auth decorator."""
import uuid
import re
import logging
from datetime import date, datetime
from functools import wraps
from flask import request, jsonify

logger = logging.getLogger(__name__)


def safe_db(fn):
    """Decorator: wraps route in try/except with proper DB cleanup."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            logger.exception(f"Error in {fn.__name__}: {e}")
            return jsonify({'ok': False, 'error': 'Terjadi kesalahan internal'}), 500
    return wrapper


def gid():
    return uuid.uuid4().hex[:8]


def now_ts():
    return f"{date.today().isoformat()} {datetime.now().strftime('%H:%M')}"


def validate_date(s):
    """Validate and return ISO date string, or None."""
    if not s:
        return None
    try:
        datetime.strptime(s, '%Y-%m-%d')
        return s
    except ValueError:
        return None


def validate_int(val, min_val=0, max_val=999999999, default=0):
    """Safely convert to int within range."""
    try:
        v = int(val)
        return max(min_val, min(v, max_val))
    except (TypeError, ValueError):
        return default


def validate_month(s):
    """Validate YYYY-MM format."""
    if not s or not re.match(r'^\d{4}-\d{2}$', s):
        return None
    return s


def get_json():
    """Get request JSON with fallback to empty dict."""
    return request.json or {}


def dict_row(row):
    if row is None:
        return None
    return dict(row)


def dict_rows(rows):
    return [dict(r) for r in rows]


def ok(data=None, **kwargs):
    """Standard success response."""
    resp = {'ok': True}
    if data is not None:
        resp['data'] = data
    resp.update(kwargs)
    return jsonify(resp)


def err(message, status=400):
    """Standard error response."""
    return jsonify({'ok': False, 'error': message}), status


def require_json(*fields):
    """Validate required fields in request JSON."""
    data = get_json()
    missing = [f for f in fields if not data.get(f)]
    if missing:
        return None, err(f"Field wajib: {', '.join(missing)}")
    return data, None


def get_clinic_name():
    """Get clinic name from license data for Excel headers etc."""
    try:
        from license_manager import get_license_info
        info = get_license_info()
        if info.get('data') and info['data'].get('clinic'):
            return info['data']['clinic'].upper()
    except Exception:
        pass
    return 'Kalibrasi Pro'
