@echo off
echo ==========================================
echo   Kalibrasi Pro - Installer
echo ==========================================
echo.
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.10+ tidak terdeteksi. Install Python dulu dari python.org
    pause
    exit /b 1
)
echo [OK] Python ditemukan
echo.
echo [1/2] Installing Python dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERROR] Gagal install dependencies
    pause
    exit /b 1
)
echo.
echo [2/2] Initializing database...
python db_manager.py
echo.
echo ==========================================
echo   Instalasi berhasil!
echo   Jalankan: start.bat
echo   Buka browser: http://localhost:8100
echo ==========================================
pause
