#!/bin/bash
echo "=========================================="
echo "  Kalibrasi Pro - Installer"
echo "=========================================="
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3.10+ tidak terdeteksi"
    exit 1
fi
echo "[OK] Python ditemukan"
echo "[1/2] Installing dependencies..."
pip3 install -r requirements.txt
echo "[2/2] Initializing database..."
python3 db_manager.py
echo "=========================================="
echo "  Instalasi berhasil!"
echo "  Jalankan: bash start.sh"
echo "  Buka browser: http://localhost:8100"
echo "=========================================="
