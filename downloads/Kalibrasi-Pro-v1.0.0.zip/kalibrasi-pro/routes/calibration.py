"""Calibration routes: alkes CRUD, vendors, prices, calibrations, schedules, dashboard, reports."""
import io
import os
from flask import Blueprint, request, jsonify, send_file
from datetime import date, datetime, timedelta
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from db_manager import get_db, log_audit
from helpers import gid, dict_rows, safe_db, get_clinic_name

bp = Blueprint('calibration', __name__)

CERT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'certificates')


def add_months(d, months):
    """Add months to a date without dateutil."""
    m = d.month + months
    y = d.year + (m - 1) // 12
    m = (m - 1) % 12 + 1
    day = min(d.day, [31, 29 if y % 4 == 0 and (y % 100 != 0 or y % 400 == 0) else 28,
                       31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1])
    return d.replace(year=y, month=m, day=day)


def parse_date(s):
    """Parse ISO date string to date object, or None."""
    if not s:
        return None
    try:
        return datetime.strptime(s, '%Y-%m-%d').date()
    except ValueError:
        return None


# ===================== ALKES CRUD =====================

@bp.route('/api/cal/alkes')
@safe_db
def list_alkes():
    unit_id = request.args.get('unit_id')
    conn = get_db()
    if unit_id:
        rows = conn.execute("""
            SELECT a.*, u.name as unit_name
            FROM alkes a LEFT JOIN units u ON a.unit_id = u.id
            WHERE a.unit_id = ? ORDER BY a.name
        """, (unit_id,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT a.*, u.name as unit_name
            FROM alkes a LEFT JOIN units u ON a.unit_id = u.id
            ORDER BY a.name
        """).fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/cal/alkes/<aid>')
@safe_db
def get_alkes(aid):
    conn = get_db()
    row = conn.execute("""
        SELECT a.*, u.name as unit_name
        FROM alkes a LEFT JOIN units u ON a.unit_id = u.id
        WHERE a.id = ?
    """, (aid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({'ok': False, 'error': 'Tidak ditemukan'}), 404
    result = dict(row)
    cals = conn.execute("""
        SELECT c.*, v.name as vendor_name
        FROM calibrations c LEFT JOIN calibration_vendors v ON c.vendor_id = v.id
        WHERE c.alkes_id = ? ORDER BY c.date DESC
    """, (aid,)).fetchall()
    result['calibrations'] = dict_rows(cals)
    conn.close()
    return jsonify(result)


@bp.route('/api/cal/alkes', methods=['POST'])
@safe_db
def create_alkes():
    data = request.json or {}
    aid = gid()
    interval = int(data.get('calibration_interval', 12))
    purchase_date = data.get('purchase_date', '')
    next_cal = ''
    if purchase_date:
        pd = parse_date(purchase_date)
        if pd:
            next_cal = add_months(pd, interval).isoformat()
    conn = get_db()
    conn.execute("""
        INSERT INTO alkes (id, name, category, brand, model, serial_number, unit_id,
            purchase_date, purchase_price, condition, calibration_interval,
            last_calibration, next_calibration, notes)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (aid, data.get('name', ''), data.get('category', 'Lainnya'),
          data.get('brand', ''), data.get('model', ''), data.get('serial_number', ''),
          data.get('unit_id'), purchase_date,
          int(data.get('purchase_price', 0)), data.get('condition', 'Baik'),
          interval, data.get('last_calibration', ''), next_cal,
          data.get('notes', '')))
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': aid})


@bp.route('/api/cal/alkes/<aid>', methods=['PUT'])
@safe_db
def update_alkes(aid):
    data = request.json or {}
    conn = get_db()
    existing = conn.execute("SELECT * FROM alkes WHERE id=?", (aid,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({'ok': False, 'error': 'Tidak ditemukan'}), 404
    interval = int(data.get('calibration_interval', existing['calibration_interval']))
    last_cal = data.get('last_calibration', existing['last_calibration'])
    next_cal = data.get('next_calibration', existing['next_calibration'])
    # Recalculate next_calibration if last_calibration changed
    if last_cal and last_cal != existing['last_calibration']:
        ld = parse_date(last_cal)
        if ld:
            next_cal = add_months(ld, interval).isoformat()
    conn.execute("""
        UPDATE alkes SET name=?, category=?, brand=?, model=?, serial_number=?,
            unit_id=?, purchase_date=?, purchase_price=?, condition=?,
            calibration_interval=?, last_calibration=?, next_calibration=?, notes=?
        WHERE id=?
    """, (data.get('name', existing['name']),
          data.get('category', existing['category']),
          data.get('brand', existing['brand']),
          data.get('model', existing['model']),
          data.get('serial_number', existing['serial_number']),
          data.get('unit_id', existing['unit_id']),
          data.get('purchase_date', existing['purchase_date']),
          int(data.get('purchase_price', existing['purchase_price'])),
          data.get('condition', existing['condition']),
          interval, last_cal, next_cal,
          data.get('notes', existing['notes']),
          aid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/alkes/<aid>', methods=['DELETE'])
@safe_db
def delete_alkes(aid):
    conn = get_db()
    conn.execute("DELETE FROM alkes WHERE id=?", (aid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== CALIBRATION VENDORS CRUD =====================

@bp.route('/api/cal/vendors')
@safe_db
def list_vendors():
    conn = get_db()
    rows = conn.execute("SELECT * FROM calibration_vendors ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/cal/vendors', methods=['POST'])
@safe_db
def create_vendor():
    data = request.json or {}
    vid = gid()
    conn = get_db()
    conn.execute("""
        INSERT INTO calibration_vendors (id, name, accreditation, contact, address, specialization)
        VALUES (?,?,?,?,?,?)
    """, (vid, data.get('name', ''), data.get('accreditation', ''),
          data.get('contact', ''), data.get('address', ''),
          data.get('specialization', 'Umum')))
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': vid})


@bp.route('/api/cal/vendors/<vid>', methods=['PUT'])
@safe_db
def update_vendor(vid):
    data = request.json or {}
    conn = get_db()
    conn.execute("""
        UPDATE calibration_vendors SET name=?, accreditation=?, contact=?, address=?, specialization=?
        WHERE id=?
    """, (data.get('name', ''), data.get('accreditation', ''),
          data.get('contact', ''), data.get('address', ''),
          data.get('specialization', 'Umum'), vid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/vendors/<vid>', methods=['DELETE'])
@safe_db
def delete_vendor(vid):
    conn = get_db()
    conn.execute("DELETE FROM calibration_vendors WHERE id=?", (vid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== CALIBRATION PRICES =====================

@bp.route('/api/cal/prices')
@safe_db
def list_prices():
    alkes_id = request.args.get('alkes_id')
    conn = get_db()
    if alkes_id:
        rows = conn.execute("""
            SELECT cp.*, a.name as alkes_name, v.name as vendor_name
            FROM calibration_prices cp
            JOIN alkes a ON cp.alkes_id = a.id
            JOIN calibration_vendors v ON cp.vendor_id = v.id
            WHERE cp.alkes_id = ? ORDER BY cp.is_default DESC, v.name
        """, (alkes_id,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT cp.*, a.name as alkes_name, v.name as vendor_name
            FROM calibration_prices cp
            JOIN alkes a ON cp.alkes_id = a.id
            JOIN calibration_vendors v ON cp.vendor_id = v.id
            ORDER BY a.name, cp.is_default DESC
        """).fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/cal/prices', methods=['POST'])
@safe_db
def create_price():
    data = request.json or {}
    pid = gid()
    alkes_id = data.get('alkes_id')
    vendor_id = data.get('vendor_id')
    conn = get_db()
    # Auto set default if first price for this alkes
    existing = conn.execute("SELECT COUNT(*) FROM calibration_prices WHERE alkes_id=?",
                            (alkes_id,)).fetchone()[0]
    is_default = 1 if existing == 0 else int(data.get('is_default', 0))
    if is_default:
        conn.execute("UPDATE calibration_prices SET is_default=0 WHERE alkes_id=?", (alkes_id,))
    conn.execute("""
        INSERT INTO calibration_prices (id, alkes_id, vendor_id, price, is_default)
        VALUES (?,?,?,?,?)
    """, (pid, alkes_id, vendor_id, int(data.get('price', 0)), is_default))
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': pid})


@bp.route('/api/cal/prices/<pid>', methods=['PUT'])
@safe_db
def update_price(pid):
    data = request.json or {}
    conn = get_db()
    conn.execute("UPDATE calibration_prices SET price=? WHERE id=?",
                 (int(data.get('price', 0)), pid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/prices/<pid>/set-default', methods=['POST'])
@safe_db
def set_default_price(pid):
    conn = get_db()
    row = conn.execute("SELECT alkes_id FROM calibration_prices WHERE id=?", (pid,)).fetchone()
    if not row:
        conn.close()
        return jsonify({'ok': False, 'error': 'Tidak ditemukan'}), 404
    conn.execute("UPDATE calibration_prices SET is_default=0 WHERE alkes_id=?", (row['alkes_id'],))
    conn.execute("UPDATE calibration_prices SET is_default=1 WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/prices/<pid>', methods=['DELETE'])
@safe_db
def delete_price(pid):
    conn = get_db()
    conn.execute("DELETE FROM calibration_prices WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== CALIBRATIONS (HISTORY) =====================

@bp.route('/api/cal/calibrations')
@safe_db
def list_calibrations():
    alkes_id = request.args.get('alkes_id')
    conn = get_db()
    if alkes_id:
        rows = conn.execute("""
            SELECT c.*, a.name as alkes_name, v.name as vendor_name
            FROM calibrations c
            JOIN alkes a ON c.alkes_id = a.id
            LEFT JOIN calibration_vendors v ON c.vendor_id = v.id
            WHERE c.alkes_id = ? ORDER BY c.date DESC
        """, (alkes_id,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT c.*, a.name as alkes_name, v.name as vendor_name
            FROM calibrations c
            JOIN alkes a ON c.alkes_id = a.id
            LEFT JOIN calibration_vendors v ON c.vendor_id = v.id
            ORDER BY c.date DESC
        """).fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/cal/calibrations', methods=['POST'])
@safe_db
def create_calibration():
    data = request.json or {}
    cid = gid()
    alkes_id = data.get('alkes_id')
    cal_date = data.get('date', date.today().isoformat())
    conn = get_db()
    alkes = conn.execute("SELECT * FROM alkes WHERE id=?", (alkes_id,)).fetchone()
    if not alkes:
        conn.close()
        return jsonify({'ok': False, 'error': 'Alkes tidak ditemukan'}), 404
    interval = alkes['calibration_interval']
    cd = parse_date(cal_date)
    next_due = add_months(cd, interval).isoformat() if cd else ''
    conn.execute("""
        INSERT INTO calibrations (id, alkes_id, vendor_id, date, result, certificate_no,
            certificate_file, cost, technician, notes, next_due)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    """, (cid, alkes_id, data.get('vendor_id'), cal_date,
          data.get('result', 'Laik Pakai'), data.get('certificate_no', ''),
          '', int(data.get('cost', 0)), data.get('technician', ''),
          data.get('notes', ''), next_due))
    # Update alkes last/next calibration
    conn.execute("""
        UPDATE alkes SET last_calibration=?, next_calibration=? WHERE id=?
    """, (cal_date, next_due, alkes_id))
    # Mark matching schedule as completed (within 30 day window)
    if cd:
        window_start = (cd - timedelta(days=15)).isoformat()
        window_end = (cd + timedelta(days=15)).isoformat()
        conn.execute("""
            UPDATE calibration_schedules SET status='completed'
            WHERE alkes_id=? AND status='scheduled' AND due_date BETWEEN ? AND ?
        """, (alkes_id, window_start, window_end))
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': cid})


@bp.route('/api/cal/calibrations/<cid>', methods=['PUT'])
@safe_db
def update_calibration(cid):
    data = request.json or {}
    conn = get_db()
    existing = conn.execute("SELECT * FROM calibrations WHERE id=?", (cid,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({'ok': False, 'error': 'Tidak ditemukan'}), 404
    alkes_id = data.get('alkes_id', existing['alkes_id'])
    cal_date = data.get('date', existing['date'])
    conn.execute("""
        UPDATE calibrations SET alkes_id=?, vendor_id=?, date=?, result=?, certificate_no=?,
            cost=?, technician=?, notes=? WHERE id=?
    """, (alkes_id,
          data.get('vendor_id', existing['vendor_id']),
          cal_date,
          data.get('result', existing['result']),
          data.get('certificate_no', existing['certificate_no']),
          int(data.get('cost', existing['cost'])),
          data.get('technician', existing['technician']),
          data.get('notes', existing['notes']),
          cid))
    # Recalculate next_calibration for the alkes
    alkes = conn.execute("SELECT * FROM alkes WHERE id=?", (alkes_id,)).fetchone()
    if alkes:
        interval = alkes['calibration_interval']
        cd = parse_date(cal_date)
        if cd:
            next_due = add_months(cd, interval).isoformat()
            conn.execute("UPDATE calibrations SET next_due=? WHERE id=?", (next_due, cid))
            conn.execute("UPDATE alkes SET last_calibration=?, next_calibration=? WHERE id=?",
                         (cal_date, next_due, alkes_id))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/calibrations/<cid>', methods=['DELETE'])
@safe_db
def delete_calibration(cid):
    conn = get_db()
    conn.execute("DELETE FROM calibrations WHERE id=?", (cid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== CERTIFICATE UPLOAD =====================

@bp.route('/api/cal/upload-cert/<cal_id>', methods=['POST'])
@safe_db
def upload_cert(cal_id):
    if 'file' not in request.files:
        return jsonify({'ok': False, 'error': 'File tidak ditemukan'}), 400
    f = request.files['file']
    if not f.filename.lower().endswith(('.pdf', '.jpg', '.jpeg', '.png')):
        return jsonify({'ok': False, 'error': 'Hanya file PDF/JPG/PNG yang diizinkan'}), 400
    os.makedirs(CERT_DIR, exist_ok=True)
    ext = os.path.splitext(f.filename)[1].lower()
    path = os.path.join(CERT_DIR, f'{cal_id}{ext}')
    f.save(path)
    conn = get_db()
    conn.execute("UPDATE calibrations SET certificate_file=? WHERE id=?", (path, cal_id))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/cert/<cal_id>')
@safe_db
def serve_cert(cal_id):
    # Try multiple extensions
    for ext in ('.pdf', '.jpg', '.jpeg', '.png'):
        path = os.path.join(CERT_DIR, f'{cal_id}{ext}')
        if os.path.exists(path):
            mimetypes = {'.pdf': 'application/pdf', '.jpg': 'image/jpeg',
                         '.jpeg': 'image/jpeg', '.png': 'image/png'}
            return send_file(path, mimetype=mimetypes.get(ext, 'application/octet-stream'))
    return jsonify({'ok': False, 'error': 'Sertifikat tidak ditemukan'}), 404


# ===================== SCHEDULES =====================

@bp.route('/api/cal/schedules')
@safe_db
def list_schedules():
    status = request.args.get('status')
    conn = get_db()
    today_iso = date.today().isoformat()
    # Auto-mark overdue
    conn.execute("""
        UPDATE calibration_schedules SET status='overdue'
        WHERE status='scheduled' AND due_date < ?
    """, (today_iso,))
    conn.commit()
    if status:
        rows = conn.execute("""
            SELECT s.*, a.name as alkes_name, v.name as vendor_name
            FROM calibration_schedules s
            JOIN alkes a ON s.alkes_id = a.id
            LEFT JOIN calibration_vendors v ON s.assigned_vendor = v.id
            WHERE s.status = ? ORDER BY s.due_date
        """, (status,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT s.*, a.name as alkes_name, v.name as vendor_name
            FROM calibration_schedules s
            JOIN alkes a ON s.alkes_id = a.id
            LEFT JOIN calibration_vendors v ON s.assigned_vendor = v.id
            ORDER BY s.due_date
        """).fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/cal/schedules', methods=['POST'])
@safe_db
def create_schedule():
    data = request.json or {}
    sid = gid()
    conn = get_db()
    conn.execute("""
        INSERT INTO calibration_schedules (id, alkes_id, due_date, status, assigned_vendor, notes)
        VALUES (?,?,?,?,?,?)
    """, (sid, data.get('alkes_id'), data.get('due_date', ''),
          data.get('status', 'scheduled'), data.get('assigned_vendor'), data.get('notes', '')))
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': sid})


@bp.route('/api/cal/schedules/<sid>', methods=['PUT'])
@safe_db
def update_schedule(sid):
    data = request.json or {}
    conn = get_db()
    existing = conn.execute("SELECT * FROM calibration_schedules WHERE id=?", (sid,)).fetchone()
    if not existing:
        conn.close()
        return jsonify({'ok': False, 'error': 'Not found'}), 404
    conn.execute("""
        UPDATE calibration_schedules SET due_date=?, status=?, assigned_vendor=?, notes=?
        WHERE id=?
    """, (data.get('due_date', existing['due_date']),
          data.get('status', existing['status']),
          data.get('assigned_vendor', existing['assigned_vendor']),
          data.get('notes', existing['notes']), sid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/cal/schedules/<sid>', methods=['DELETE'])
@safe_db
def delete_schedule(sid):
    conn = get_db()
    conn.execute("DELETE FROM calibration_schedules WHERE id=?", (sid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== DASHBOARD =====================

@bp.route('/api/cal/dashboard')
@safe_db
def dashboard():
    conn = get_db()
    today_iso = date.today().isoformat()
    in_30d = (date.today() + timedelta(days=30)).isoformat()
    year_start = f"{date.today().year}-01-01"

    total_alkes = conn.execute("SELECT COUNT(*) FROM alkes").fetchone()[0]

    # For laik/tidak laik, get the latest calibration result per alkes
    total_laik = conn.execute("""
        SELECT COUNT(*) FROM alkes a WHERE EXISTS (
            SELECT 1 FROM calibrations c WHERE c.alkes_id = a.id
            AND c.date = (SELECT MAX(c2.date) FROM calibrations c2 WHERE c2.alkes_id = a.id)
            AND c.result = 'Laik Pakai'
        )
    """).fetchone()[0]

    total_tidak_laik = conn.execute("""
        SELECT COUNT(*) FROM alkes a WHERE EXISTS (
            SELECT 1 FROM calibrations c WHERE c.alkes_id = a.id
            AND c.date = (SELECT MAX(c2.date) FROM calibrations c2 WHERE c2.alkes_id = a.id)
            AND c.result = 'Tidak Laik'
        )
    """).fetchone()[0]

    total_overdue = conn.execute("""
        SELECT COUNT(*) FROM alkes WHERE next_calibration != '' AND next_calibration < ?
    """, (today_iso,)).fetchone()[0]

    total_upcoming = conn.execute("""
        SELECT COUNT(*) FROM alkes
        WHERE next_calibration != '' AND next_calibration >= ? AND next_calibration <= ?
    """, (today_iso, in_30d)).fetchone()[0]

    cost_ytd = conn.execute("""
        SELECT COALESCE(SUM(cost), 0) FROM calibrations WHERE date >= ?
    """, (year_start,)).fetchone()[0]

    alkes_per_unit = dict_rows(conn.execute("""
        SELECT u.name as unit_name, COUNT(*) as count
        FROM alkes a LEFT JOIN units u ON a.unit_id = u.id
        GROUP BY a.unit_id ORDER BY count DESC
    """).fetchall())

    alkes_per_category = dict_rows(conn.execute("""
        SELECT category, COUNT(*) as count FROM alkes GROUP BY category ORDER BY count DESC
    """).fetchall())

    overdue_list = dict_rows(conn.execute("""
        SELECT a.id, a.name, a.next_calibration, a.category, u.name as unit_name,
               v.name as vendor_name, cp.price as cost
        FROM alkes a
        LEFT JOIN units u ON a.unit_id = u.id
        LEFT JOIN calibration_prices cp ON cp.alkes_id = a.id AND cp.is_default = 1
        LEFT JOIN calibration_vendors v ON cp.vendor_id = v.id
        WHERE a.next_calibration != '' AND a.next_calibration < ?
        ORDER BY a.next_calibration LIMIT 10
    """, (today_iso,)).fetchall())

    upcoming_list = dict_rows(conn.execute("""
        SELECT a.id, a.name, a.next_calibration, a.category, u.name as unit_name,
               v.name as vendor_name, cp.price as cost
        FROM alkes a
        LEFT JOIN units u ON a.unit_id = u.id
        LEFT JOIN calibration_prices cp ON cp.alkes_id = a.id AND cp.is_default = 1
        LEFT JOIN calibration_vendors v ON cp.vendor_id = v.id
        WHERE a.next_calibration != '' AND a.next_calibration >= ?
        ORDER BY a.next_calibration LIMIT 10
    """, (today_iso,)).fetchall())

    recent_calibrations = dict_rows(conn.execute("""
        SELECT c.*, a.name as alkes_name, v.name as vendor_name
        FROM calibrations c
        JOIN alkes a ON c.alkes_id = a.id
        LEFT JOIN calibration_vendors v ON c.vendor_id = v.id
        ORDER BY c.date DESC LIMIT 10
    """).fetchall())

    conn.close()
    return jsonify({
        'total_alkes': total_alkes,
        'total_laik': total_laik,
        'total_tidak_laik': total_tidak_laik,
        'total_overdue': total_overdue,
        'total_upcoming_30d': total_upcoming,
        'total_cost_ytd': cost_ytd,
        'alkes_per_unit': alkes_per_unit,
        'alkes_per_category': alkes_per_category,
        'overdue_list': overdue_list,
        'upcoming_list': upcoming_list,
        'recent_calibrations': recent_calibrations,
    })


# ===================== REPORTS =====================

@bp.route('/api/cal/report/monthly')
@safe_db
def report_monthly():
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    conn = get_db()
    calibrations = dict_rows(conn.execute("""
        SELECT c.*, a.name as alkes_name, a.category, u.name as unit_name, v.name as vendor_name
        FROM calibrations c
        JOIN alkes a ON c.alkes_id = a.id
        LEFT JOIN units u ON a.unit_id = u.id
        LEFT JOIN calibration_vendors v ON c.vendor_id = v.id
        WHERE c.date LIKE ? ORDER BY c.date
    """, (month + '%',)).fetchall())

    total_cost = sum(c['cost'] for c in calibrations)

    per_vendor = dict_rows(conn.execute("""
        SELECT v.name as vendor_name, COUNT(*) as count, SUM(c.cost) as total_cost
        FROM calibrations c
        LEFT JOIN calibration_vendors v ON c.vendor_id = v.id
        WHERE c.date LIKE ?
        GROUP BY c.vendor_id ORDER BY total_cost DESC
    """, (month + '%',)).fetchall())

    per_unit = dict_rows(conn.execute("""
        SELECT u.name as unit_name, COUNT(*) as count, SUM(c.cost) as total_cost
        FROM calibrations c
        JOIN alkes a ON c.alkes_id = a.id
        LEFT JOIN units u ON a.unit_id = u.id
        WHERE c.date LIKE ?
        GROUP BY a.unit_id ORDER BY total_cost DESC
    """, (month + '%',)).fetchall())

    conn.close()
    return jsonify({
        'month': month,
        'calibrations': calibrations,
        'total_cost': total_cost,
        'total_count': len(calibrations),
        'per_vendor': per_vendor,
        'per_unit': per_unit,
    })


@bp.route('/api/cal/report/yearly')
@safe_db
def report_yearly():
    year = request.args.get('year', str(date.today().year))
    year_int = int(year)
    conn = get_db()
    all_alkes = dict_rows(conn.execute("""
        SELECT a.*, u.name as unit_name,
               cp.price as default_price, v.name as vendor_name
        FROM alkes a
        LEFT JOIN units u ON a.unit_id = u.id
        LEFT JOIN calibration_prices cp ON cp.alkes_id = a.id AND cp.is_default = 1
        LEFT JOIN calibration_vendors v ON cp.vendor_id = v.id
        ORDER BY a.name
    """).fetchall())
    conn.close()

    projections = []
    grand_total = 0
    per_category = {}
    per_unit = {}

    for alkes in all_alkes:
        interval = alkes['calibration_interval'] or 12
        price = alkes['default_price'] or 0

        # Calculate which months this alkes needs calibration in the target year
        months_due = []
        # Start from last_calibration or purchase_date
        base_str = alkes['last_calibration'] or alkes['next_calibration'] or alkes['purchase_date']
        base_date = parse_date(base_str)
        if not base_date:
            # No date info, assume needs calibration at start of year
            months_due = [1]
        else:
            # Walk forward from base_date by interval until past target year
            d = base_date
            # Walk forward until we're in or past the target year
            while d.year < year_int:
                d = add_months(d, interval)
            # Collect all due dates within target year
            while d.year == year_int:
                months_due.append(d.month)
                d = add_months(d, interval)

        cal_count = len(months_due)
        total_cost = cal_count * price

        projections.append({
            'alkes_id': alkes['id'],
            'alkes_name': alkes['name'],
            'category': alkes['category'],
            'unit_name': alkes['unit_name'],
            'interval': interval,
            'vendor_name': alkes['vendor_name'],
            'price_per_cal': price,
            'months_due': months_due,
            'cal_count': cal_count,
            'total_cost': total_cost,
        })

        grand_total += total_cost

        cat = alkes['category'] or 'Lainnya'
        per_category[cat] = per_category.get(cat, 0) + total_cost

        unit = alkes['unit_name'] or 'Tanpa Unit'
        per_unit[unit] = per_unit.get(unit, 0) + total_cost

    return jsonify({
        'year': year,
        'grand_total': grand_total,
        'per_category': [{'category': k, 'total': v} for k, v in per_category.items()],
        'per_unit': [{'unit_name': k, 'total': v} for k, v in per_unit.items()],
        'projections': projections,
    })


# ===================== EXCEL DOWNLOADS =====================

@bp.route('/api/cal/report/yearly/download')
@safe_db
def download_yearly_report():
    year = request.args.get('year', str(date.today().year))
    year_int = int(year)
    conn = get_db()
    all_alkes = dict_rows(conn.execute("""
        SELECT a.*, u.name as unit_name,
               cp.price as default_price, v.name as vendor_name
        FROM alkes a
        LEFT JOIN units u ON a.unit_id = u.id
        LEFT JOIN calibration_prices cp ON cp.alkes_id = a.id AND cp.is_default = 1
        LEFT JOIN calibration_vendors v ON cp.vendor_id = v.id
        ORDER BY a.name
    """).fetchall())
    conn.close()

    # Build projections
    projections = []
    per_category = {}
    per_unit = {}
    grand_total = 0

    for alkes in all_alkes:
        interval = alkes['calibration_interval'] or 12
        price = alkes['default_price'] or 0
        months_due = []
        base_str = alkes['last_calibration'] or alkes['next_calibration'] or alkes['purchase_date']
        base_date = parse_date(base_str)
        if not base_date:
            months_due = [1]
        else:
            d = base_date
            while d.year < year_int:
                d = add_months(d, interval)
            while d.year == year_int:
                months_due.append(d.month)
                d = add_months(d, interval)

        cal_count = len(months_due)
        total_cost = cal_count * price
        grand_total += total_cost

        cat = alkes['category'] or 'Lainnya'
        per_category[cat] = per_category.get(cat, 0) + total_cost
        unit = alkes['unit_name'] or 'Tanpa Unit'
        per_unit[unit] = per_unit.get(unit, 0) + total_cost

        projections.append({
            'name': alkes['name'],
            'category': alkes['category'],
            'unit_name': alkes['unit_name'] or '-',
            'interval': interval,
            'vendor_name': alkes['vendor_name'] or '-',
            'price': price,
            'months_due': months_due,
            'cal_count': cal_count,
            'total_cost': total_cost,
        })

    # Excel
    wb = Workbook()
    bold = Font(bold=True)
    center = Alignment(horizontal='center', vertical='center')
    wrap = Alignment(horizontal='center', vertical='center', wrap_text=True)
    border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    header_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')

    clinic = get_clinic_name()

    # --- Sheet 1: Ringkasan ---
    ws1 = wb.active
    ws1.title = 'Ringkasan'
    ws1.merge_cells('A1:D1')
    ws1['A1'] = clinic
    ws1['A1'].font = Font(bold=True, size=14)
    ws1['A1'].alignment = center
    ws1.merge_cells('A2:D2')
    ws1['A2'] = f'RENCANA ANGGARAN TAHUNAN KALIBRASI {year}'
    ws1['A2'].font = Font(bold=True, size=11)
    ws1['A2'].alignment = center

    ws1['A4'] = 'Total Anggaran:'
    ws1['A4'].font = bold
    ws1['B4'] = grand_total
    ws1['B4'].number_format = '#,##0'
    ws1['B4'].font = Font(bold=True, size=12)

    # Per category
    ws1['A6'] = 'Per Kategori'
    ws1['A6'].font = Font(bold=True, size=11)
    for col, h in enumerate(['Kategori', 'Total'], 1):
        cell = ws1.cell(row=7, column=col, value=h)
        cell.font = bold
        cell.fill = header_fill
        cell.border = border
        cell.alignment = center
    row = 8
    for cat, total in per_category.items():
        ws1.cell(row=row, column=1, value=cat).border = border
        c = ws1.cell(row=row, column=2, value=total)
        c.border = border
        c.number_format = '#,##0'
        row += 1

    # Per unit
    row += 1
    ws1.cell(row=row, column=1, value='Per Unit').font = Font(bold=True, size=11)
    row += 1
    for col, h in enumerate(['Unit', 'Total'], 1):
        cell = ws1.cell(row=row, column=col, value=h)
        cell.font = bold
        cell.fill = header_fill
        cell.border = border
        cell.alignment = center
    row += 1
    for unit, total in per_unit.items():
        ws1.cell(row=row, column=1, value=unit).border = border
        c = ws1.cell(row=row, column=2, value=total)
        c.border = border
        c.number_format = '#,##0'
        row += 1

    ws1.column_dimensions['A'].width = 25
    ws1.column_dimensions['B'].width = 20
    ws1.column_dimensions['C'].width = 20
    ws1.column_dimensions['D'].width = 20

    # --- Sheet 2: Detail ---
    ws2 = wb.create_sheet('Detail Per Alat')
    ws2.merge_cells('A1:R1')
    ws2['A1'] = clinic
    ws2['A1'].font = Font(bold=True, size=14)
    ws2['A1'].alignment = center
    ws2.merge_cells('A2:R2')
    ws2['A2'] = f'DETAIL RAT KALIBRASI {year}'
    ws2['A2'].font = Font(bold=True, size=11)
    ws2['A2'].alignment = center

    month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
                   'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des']
    headers = ['No', 'Nama Alat', 'Unit', 'Interval (bln)', 'Vendor', 'Harga/Kal']
    headers += month_names
    headers += ['Jml Kal', 'Total Biaya']

    ws2.column_dimensions['A'].width = 5
    ws2.column_dimensions['B'].width = 30
    ws2.column_dimensions['C'].width = 16
    ws2.column_dimensions['D'].width = 13
    ws2.column_dimensions['E'].width = 22
    ws2.column_dimensions['F'].width = 14
    for i in range(12):
        ws2.column_dimensions[chr(ord('G') + i)].width = 5
    ws2.column_dimensions['S'].width = 9
    ws2.column_dimensions['T'].width = 14

    for col, h in enumerate(headers, 1):
        cell = ws2.cell(row=4, column=col, value=h)
        cell.font = bold
        cell.fill = header_fill
        cell.border = border
        cell.alignment = wrap

    for i, p in enumerate(projections, 1):
        row = 4 + i
        vals = [i, p['name'], p['unit_name'], p['interval'], p['vendor_name'], p['price']]
        for col, v in enumerate(vals, 1):
            cell = ws2.cell(row=row, column=col, value=v)
            cell.border = border
            if col == 6:
                cell.number_format = '#,##0'
        # Month marks
        for m in range(1, 13):
            cell = ws2.cell(row=row, column=6 + m)
            cell.border = border
            cell.alignment = center
            if m in p['months_due']:
                cell.value = 'V'
                cell.font = Font(bold=True, color='0000AA')
        # Totals
        ws2.cell(row=row, column=19, value=p['cal_count']).border = border
        c = ws2.cell(row=row, column=20, value=p['total_cost'])
        c.border = border
        c.number_format = '#,##0'

    # Grand total row
    total_row = 5 + len(projections)
    ws2.merge_cells(f'A{total_row}:F{total_row}')
    ws2.cell(row=total_row, column=1, value='TOTAL').font = Font(bold=True, size=12)
    ws2.cell(row=total_row, column=1).alignment = Alignment(horizontal='right')
    for col in range(1, 21):
        ws2.cell(row=total_row, column=col).border = border
    c = ws2.cell(row=total_row, column=20, value=grand_total)
    c.font = Font(bold=True, size=12)
    c.number_format = '#,##0'

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f'RAT_Kalibrasi_{year}.xlsx'
    return send_file(buf, download_name=fname,
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ===================== EXCEL UPLOAD =====================

@bp.route('/api/cal/upload/alkes', methods=['POST'])
@safe_db
def upload_alkes():
    if 'file' not in request.files:
        return jsonify({'ok': False, 'error': 'File tidak ditemukan'}), 400
    f = request.files['file']
    if not f.filename.lower().endswith(('.xlsx', '.xls')):
        return jsonify({'ok': False, 'error': 'Hanya file Excel yang diizinkan'}), 400

    from openpyxl import load_workbook
    wb = load_workbook(f)
    ws = wb.active

    conn = get_db()
    # Cache units by name
    units = {}
    for u in conn.execute("SELECT id, name FROM units").fetchall():
        units[u['name'].lower().strip()] = u['id']

    inserted = 0
    errors = []
    for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        if not row or not row[0]:
            continue
        try:
            name = str(row[0]).strip()
            category = str(row[1] or 'Lainnya').strip()
            brand = str(row[2] or '').strip()
            model = str(row[3] or '').strip()
            serial = str(row[4] or '').strip()
            unit_name = str(row[5] or '').strip().lower()
            purchase_date_raw = row[6]
            condition = str(row[7] or 'Baik').strip()
            interval = int(row[8] or 12)
            purchase_price = 0

            # Parse purchase date
            if isinstance(purchase_date_raw, datetime):
                purchase_date = purchase_date_raw.strftime('%Y-%m-%d')
            elif isinstance(purchase_date_raw, date):
                purchase_date = purchase_date_raw.isoformat()
            else:
                purchase_date = str(purchase_date_raw or '').strip()

            # Match unit
            unit_id = units.get(unit_name)
            if unit_name and not unit_id:
                # Create unit
                unit_id = gid()
                conn.execute("INSERT OR IGNORE INTO units (id, name) VALUES (?,?)",
                             (unit_id, str(row[5] or '').strip()))
                units[unit_name] = unit_id

            # Calculate next_calibration
            next_cal = ''
            pd = parse_date(purchase_date)
            if pd:
                next_cal = add_months(pd, interval).isoformat()

            aid = gid()
            conn.execute("""
                INSERT INTO alkes (id, name, category, brand, model, serial_number, unit_id,
                    purchase_date, purchase_price, condition, calibration_interval,
                    last_calibration, next_calibration, notes)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (aid, name, category, brand, model, serial, unit_id,
                  purchase_date, purchase_price, condition, interval, '', next_cal, ''))
            inserted += 1
        except Exception as e:
            errors.append(f'Baris {i}: {str(e)}')

    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'inserted': inserted, 'errors': errors})


@bp.route('/api/cal/template/alkes')
@safe_db
def download_alkes_template():
    wb = Workbook()
    ws = wb.active
    ws.title = 'Template Alkes'
    headers = ['Nama Alat', 'Kategori', 'Merk', 'Model', 'Serial Number',
               'Unit', 'Tanggal Beli', 'Kondisi', 'Interval Kalibrasi (bulan)']
    bold = Font(bold=True)
    header_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
    border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = bold
        cell.fill = header_fill
        cell.border = border

    # Example row
    example = ['Tensimeter Digital', 'Diagnostik', 'Omron', 'HEM-7156', 'SN-001',
               'Poli Umum', '2024-01-15', 'Baik', 12]
    for col, v in enumerate(example, 1):
        ws.cell(row=2, column=col, value=v).border = border

    ws.column_dimensions['A'].width = 25
    ws.column_dimensions['B'].width = 15
    ws.column_dimensions['C'].width = 15
    ws.column_dimensions['D'].width = 15
    ws.column_dimensions['E'].width = 18
    ws.column_dimensions['F'].width = 15
    ws.column_dimensions['G'].width = 15
    ws.column_dimensions['H'].width = 12
    ws.column_dimensions['I'].width = 25

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, download_name='Template_Import_Alkes.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
