"""Minimal master routes for Kalibrasi Pro — units only.

Unlike MedOps Pro, Kalibrasi doesn't need products/vendors_master — the
calibration blueprint owns its own vendors table (calibration_vendors).
We only expose units here because `alkes.unit_id` references them.
"""
from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash
from db_manager import get_db, log_audit
from helpers import dict_rows, gid, safe_db, get_json, ok, err

bp = Blueprint('master', __name__)


@bp.route('/api/units')
@safe_db
def get_units():
    conn = get_db()
    rows = conn.execute("SELECT * FROM units ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/units', methods=['POST'])
@safe_db
def add_unit():
    data = get_json()
    name = data.get('name', '').strip()
    if not name:
        return err('Nama unit wajib diisi')
    uid = gid()
    conn = get_db()
    if conn.execute("SELECT id FROM units WHERE name=?", (name,)).fetchone():
        conn.close()
        return err(f'Unit "{name}" sudah ada')
    conn.execute("INSERT INTO units (id, name) VALUES (?,?)", (uid, name))
    # Auto-create a per-unit user so that unit's staff can log in.
    user_id = f'usr_{uid}'
    username = name.lower().replace(' ', '')
    conn.execute(
        "INSERT INTO users (id, username, password_hash, role, unit_id, display_name) "
        "VALUES (?,?,?,?,?,?)",
        (user_id, username, generate_password_hash('1234'), 'unit', uid, name),
    )
    log_audit('', '', 'ADD_UNIT', 'units', uid, f'Name: {name}')
    conn.commit()
    conn.close()
    return ok(id=uid, username=username)


@bp.route('/api/units/<uid>', methods=['DELETE'])
@safe_db
def delete_unit(uid):
    conn = get_db()
    row = conn.execute("SELECT name FROM units WHERE id=?", (uid,)).fetchone()
    if not row:
        conn.close()
        return err('Unit tidak ditemukan')
    # Refuse if alkes is still attached — force user to reassign first.
    attached = conn.execute("SELECT COUNT(*) FROM alkes WHERE unit_id=?", (uid,)).fetchone()[0]
    if attached:
        conn.close()
        return err(f'Tidak bisa hapus: ada {attached} alkes terdaftar di unit ini')
    conn.execute("DELETE FROM users WHERE unit_id=?", (uid,))
    conn.execute("DELETE FROM units WHERE id=?", (uid,))
    log_audit('', '', 'DELETE_UNIT', 'units', uid, f'Name: {row["name"]}')
    conn.commit()
    conn.close()
    return ok()
