@echo off
echo ==========================================
echo   Kalibrasi Pro - Starting...
echo ==========================================
python app.py
pause
