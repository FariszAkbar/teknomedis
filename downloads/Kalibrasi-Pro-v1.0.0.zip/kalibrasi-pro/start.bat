@echo off
cd /d "%~dp0"
echo ==========================================
echo   Kalibrasi Pro - Starting...
echo ==========================================
python app.py
pause
