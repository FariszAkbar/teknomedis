@echo off
echo ==========================================
echo   MedOps Pro - Setup Auto-Start
echo ==========================================
echo.

set SCRIPT_DIR=%~dp0
set VBS_PATH=%SCRIPT_DIR%start_hidden.vbs
set STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

:: Copy shortcut to Windows Startup folder
echo Membuat shortcut di Startup folder...
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%TEMP%\create_shortcut.vbs"
echo sLinkFile = "%STARTUP_DIR%\MedOps Pro.lnk" >> "%TEMP%\create_shortcut.vbs"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%TEMP%\create_shortcut.vbs"
echo oLink.TargetPath = "%VBS_PATH%" >> "%TEMP%\create_shortcut.vbs"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%" >> "%TEMP%\create_shortcut.vbs"
echo oLink.Description = "MedOps Pro Server" >> "%TEMP%\create_shortcut.vbs"
echo oLink.Save >> "%TEMP%\create_shortcut.vbs"
cscript //nologo "%TEMP%\create_shortcut.vbs"
del "%TEMP%\create_shortcut.vbs"

echo.
echo ==========================================
echo   Auto-start berhasil diaktifkan!
echo ==========================================
echo.
echo   MedOps Pro akan otomatis jalan saat
echo   komputer dinyalakan.
echo.
echo   Untuk menonaktifkan:
echo   Hapus "MedOps Pro" dari folder Startup
echo   (%STARTUP_DIR%)
echo.
pause
