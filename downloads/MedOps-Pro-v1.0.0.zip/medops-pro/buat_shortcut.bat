@echo off
echo Membuat shortcut MedOps Pro di Desktop...

:: Get folder path without trailing backslash
set "MYDIR=%~dp0"
set "MYDIR=%MYDIR:~0,-1%"
set "DESKTOP=%USERPROFILE%\Desktop"
set "ICO=%MYDIR%\static\logo-medops.ico"

:: Create browser shortcut (.url)
(
echo [InternetShortcut]
echo URL=http://localhost:8060
echo IconIndex=0
if exist "%ICO%" (echo IconFile=%ICO%) else (echo IconFile=%SystemRoot%\system32\shell32.dll)
) > "%DESKTOP%\MedOps Pro.url"

:: Create server shortcut (.lnk)
set "VBS=%TEMP%\mksc.vbs"
> "%VBS%" echo Set s=WScript.CreateObject("WScript.Shell")
>> "%VBS%" echo Set l=s.CreateShortcut("%DESKTOP%\MedOps Pro Server.lnk")
>> "%VBS%" echo l.TargetPath="%MYDIR%\start_hidden.vbs"
>> "%VBS%" echo l.WorkingDirectory="%MYDIR%"
>> "%VBS%" echo l.Description="Start MedOps Pro Server"
if exist "%ICO%" >> "%VBS%" echo l.IconLocation="%ICO%"
>> "%VBS%" echo l.Save
cscript //nologo "%VBS%"
del "%VBS%" 2>nul

echo.
echo ==========================================
echo   Shortcut berhasil dibuat di Desktop!
echo ==========================================
echo.
echo   "MedOps Pro"        - Buka aplikasi di browser
echo   "MedOps Pro Server" - Start server (background)
echo.
pause
