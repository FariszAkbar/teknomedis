@echo off
echo Membuat shortcut MedOps Pro di Desktop...

set "APPDIR=%~dp0"
if "%APPDIR:~-1%"=="\" set "APPDIR=%APPDIR:~0,-1%"

:: 1. Browser shortcut (simple .url file)
> "%USERPROFILE%\Desktop\MedOps Pro.url" (
  echo [InternetShortcut]
  echo URL=http://localhost:8060
)

:: 2. Server shortcut (VBS creates .lnk)
> "%TEMP%\_mk.vbs" (
  echo Set w = CreateObject^("WScript.Shell"^)
  echo Set s = w.CreateShortcut^(w.SpecialFolders^("Desktop"^) ^& "\MedOps Pro Server.lnk"^)
  echo s.TargetPath = "%APPDIR%\start_hidden.vbs"
  echo s.WorkingDirectory = "%APPDIR%"
  echo s.Description = "Start MedOps Pro Server"
  echo s.Save
)
cscript //nologo "%TEMP%\_mk.vbs"
del "%TEMP%\_mk.vbs" 2>nul

echo.
echo ==========================================
echo   Shortcut berhasil dibuat di Desktop!
echo ==========================================
echo.
echo   "MedOps Pro"        - Buka aplikasi di browser
echo   "MedOps Pro Server" - Start server (background)
echo.
pause
