@echo off
echo Membuat shortcut MedOps Pro di Desktop...

set SCRIPT_DIR=%~dp0
set DESKTOP=%USERPROFILE%\Desktop

set ICO_PATH=%SCRIPT_DIR%static\logo-medops.ico

:: Create .url shortcut to open browser (with custom icon)
echo [InternetShortcut] > "%DESKTOP%\MedOps Pro.url"
echo URL=http://localhost:8060 >> "%DESKTOP%\MedOps Pro.url"
echo IconIndex=0 >> "%DESKTOP%\MedOps Pro.url"
if exist "%ICO_PATH%" (
    echo IconFile=%ICO_PATH% >> "%DESKTOP%\MedOps Pro.url"
) else (
    echo IconFile=%SystemRoot%\system32\shell32.dll >> "%DESKTOP%\MedOps Pro.url"
)

:: Create server start shortcut (with custom icon)
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%TEMP%\mkshortcut.vbs"
echo sLinkFile = "%DESKTOP%\MedOps Pro Server.lnk" >> "%TEMP%\mkshortcut.vbs"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%TEMP%\mkshortcut.vbs"
echo oLink.TargetPath = "%SCRIPT_DIR%start_hidden.vbs" >> "%TEMP%\mkshortcut.vbs"
echo oLink.WorkingDirectory = "%SCRIPT_DIR%" >> "%TEMP%\mkshortcut.vbs"
echo oLink.Description = "Start MedOps Pro Server" >> "%TEMP%\mkshortcut.vbs"
if exist "%ICO_PATH%" echo oLink.IconLocation = "%ICO_PATH%" >> "%TEMP%\mkshortcut.vbs"
echo oLink.Save >> "%TEMP%\mkshortcut.vbs"
cscript //nologo "%TEMP%\mkshortcut.vbs"
del "%TEMP%\mkshortcut.vbs"

echo.
echo ==========================================
echo   Shortcut berhasil dibuat di Desktop!
echo ==========================================
echo.
echo   "MedOps Pro"        - Buka aplikasi di browser
echo   "MedOps Pro Server" - Start server (background)
echo.
pause
