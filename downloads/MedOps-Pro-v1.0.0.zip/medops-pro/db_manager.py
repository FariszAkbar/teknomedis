"""Database manager: schema, migrations, seed data."""
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'data', 'medops.db')


def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    c.executescript("""
    -- ==================== MASTER DATA ====================
    CREATE TABLE IF NOT EXISTS units (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Lainnya',
        type TEXT NOT NULL DEFAULT 'ATK' CHECK(type IN ('ATK','RTK')),
        uom TEXT NOT NULL DEFAULT 'Pcs'
    );

    CREATE TABLE IF NOT EXISTS vendors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        contact TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS vendor_prices (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        vendor_id TEXT NOT NULL,
        price INTEGER NOT NULL DEFAULT 0 CHECK(price >= 0),
        is_default INTEGER NOT NULL DEFAULT 0,
        UNIQUE(product_id, vendor_id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES vendors(id) ON DELETE CASCADE
    );

    -- ==================== USERS & AUTH ====================
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'unit' CHECK(role IN ('admin','direktur','unit')),
        unit_id TEXT,
        display_name TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (unit_id) REFERENCES units(id)
    );

    -- ==================== INVENTORY ====================
    CREATE TABLE IF NOT EXISTS warehouse_stock (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL UNIQUE,
        qty INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS stock (
        id TEXT PRIMARY KEY,
        unit_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0 CHECK(qty >= 0),
        UNIQUE(unit_id, product_id),
        FOREIGN KEY (unit_id) REFERENCES units(id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    -- ==================== REQUESTS ====================
    CREATE TABLE IF NOT EXISTS requests (
        id TEXT PRIMARY KEY,
        unit_id TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','fulfilled','rejected')),
        date TEXT NOT NULL,
        notes TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (unit_id) REFERENCES units(id)
    );

    CREATE TABLE IF NOT EXISTS request_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0 CHECK(qty > 0),
        status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','rejected')),
        FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    -- ==================== PURCHASES ====================
    CREATE TABLE IF NOT EXISTS purchases (
        id TEXT PRIMARY KEY,
        date TEXT NOT NULL,
        vendor_id TEXT,
        notes TEXT NOT NULL DEFAULT '',
        total INTEGER NOT NULL DEFAULT 0 CHECK(total >= 0),
        status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','submitted','approved','ordered','rejected')),
        admin_name TEXT NOT NULL DEFAULT '',
        director_name TEXT NOT NULL DEFAULT '',
        created_by TEXT NOT NULL DEFAULT '',
        submitted_at TEXT NOT NULL DEFAULT '',
        approved_by TEXT NOT NULL DEFAULT '',
        approved_at TEXT NOT NULL DEFAULT '',
        ordered_at TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (vendor_id) REFERENCES vendors(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchase_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        qty INTEGER NOT NULL DEFAULT 0 CHECK(qty > 0),
        price INTEGER NOT NULL DEFAULT 0 CHECK(price >= 0),
        vendor_id TEXT,
        FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES vendors(id)
    );

    -- ==================== MONTHLY PLANS ====================
    CREATE TABLE IF NOT EXISTS monthly_plans (
        id TEXT PRIMARY KEY,
        month TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','submitted','approved','rejected')),
        admin_name TEXT NOT NULL DEFAULT '',
        director_name TEXT NOT NULL DEFAULT '',
        total_estimated INTEGER NOT NULL DEFAULT 0 CHECK(total_estimated >= 0),
        created_date TEXT NOT NULL,
        notes TEXT NOT NULL DEFAULT '',
        created_by TEXT NOT NULL DEFAULT '',
        submitted_at TEXT NOT NULL DEFAULT '',
        approved_by TEXT NOT NULL DEFAULT '',
        approved_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS monthly_plan_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        estimated_qty INTEGER NOT NULL DEFAULT 0 CHECK(estimated_qty >= 0),
        estimated_price INTEGER NOT NULL DEFAULT 0 CHECK(estimated_price >= 0),
        vendor_id TEXT,
        FOREIGN KEY (plan_id) REFERENCES monthly_plans(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES vendors(id)
    );

    -- ==================== USAGE LOG ====================
    CREATE TABLE IF NOT EXISTS usage_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        unit_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        qty_used INTEGER NOT NULL CHECK(qty_used > 0),
        date TEXT NOT NULL,
        FOREIGN KEY (unit_id) REFERENCES units(id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    );

    -- ==================== AUDIT LOG ====================
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        user_id TEXT NOT NULL DEFAULT '',
        user_name TEXT NOT NULL DEFAULT '',
        action TEXT NOT NULL,
        entity TEXT NOT NULL,
        entity_id TEXT NOT NULL DEFAULT '',
        detail TEXT NOT NULL DEFAULT ''
    );

    -- ==================== INDEXES ====================
    CREATE INDEX IF NOT EXISTS idx_stock_unit ON stock(unit_id);
    CREATE INDEX IF NOT EXISTS idx_stock_product ON stock(product_id);
    CREATE INDEX IF NOT EXISTS idx_warehouse_product ON warehouse_stock(product_id);
    CREATE INDEX IF NOT EXISTS idx_vp_product ON vendor_prices(product_id);
    CREATE INDEX IF NOT EXISTS idx_vp_vendor ON vendor_prices(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_req_unit ON requests(unit_id);
    CREATE INDEX IF NOT EXISTS idx_req_status ON requests(status);
    CREATE INDEX IF NOT EXISTS idx_ri_request ON request_items(request_id);
    CREATE INDEX IF NOT EXISTS idx_purchase_date ON purchases(date);
    CREATE INDEX IF NOT EXISTS idx_purchase_status ON purchases(status);
    CREATE INDEX IF NOT EXISTS idx_pi_purchase ON purchase_items(purchase_id);
    CREATE INDEX IF NOT EXISTS idx_plan_month ON monthly_plans(month);
    CREATE INDEX IF NOT EXISTS idx_plan_items ON monthly_plan_items(plan_id);
    CREATE INDEX IF NOT EXISTS idx_usage_unit ON usage_log(unit_id);
    CREATE INDEX IF NOT EXISTS idx_usage_date ON usage_log(date);
    CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity, entity_id);
    CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_log(timestamp);

    -- ==================== KALIBRASI: ALAT KESEHATAN ====================
    CREATE TABLE IF NOT EXISTS alkes (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'Lainnya',
        brand TEXT NOT NULL DEFAULT '',
        model TEXT NOT NULL DEFAULT '',
        serial_number TEXT NOT NULL DEFAULT '',
        unit_id TEXT,
        purchase_date TEXT NOT NULL DEFAULT '',
        purchase_price INTEGER NOT NULL DEFAULT 0,
        condition TEXT NOT NULL DEFAULT 'Baik' CHECK(condition IN ('Baik','Rusak Ringan','Rusak Berat','Tidak Aktif')),
        calibration_interval INTEGER NOT NULL DEFAULT 12,
        last_calibration TEXT NOT NULL DEFAULT '',
        next_calibration TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (unit_id) REFERENCES units(id)
    );

    CREATE TABLE IF NOT EXISTS calibration_vendors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        accreditation TEXT NOT NULL DEFAULT '',
        contact TEXT NOT NULL DEFAULT '',
        address TEXT NOT NULL DEFAULT '',
        specialization TEXT NOT NULL DEFAULT 'Umum'
    );

    CREATE TABLE IF NOT EXISTS calibration_prices (
        id TEXT PRIMARY KEY,
        alkes_id TEXT NOT NULL,
        vendor_id TEXT NOT NULL,
        price INTEGER NOT NULL DEFAULT 0,
        is_default INTEGER NOT NULL DEFAULT 0,
        UNIQUE(alkes_id, vendor_id),
        FOREIGN KEY (alkes_id) REFERENCES alkes(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES calibration_vendors(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS calibrations (
        id TEXT PRIMARY KEY,
        alkes_id TEXT NOT NULL,
        vendor_id TEXT,
        date TEXT NOT NULL,
        result TEXT NOT NULL DEFAULT 'Laik Pakai' CHECK(result IN ('Laik Pakai','Tidak Laik','Kalibrasi Ulang')),
        certificate_no TEXT NOT NULL DEFAULT '',
        certificate_file TEXT NOT NULL DEFAULT '',
        cost INTEGER NOT NULL DEFAULT 0,
        technician TEXT NOT NULL DEFAULT '',
        notes TEXT NOT NULL DEFAULT '',
        next_due TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (alkes_id) REFERENCES alkes(id) ON DELETE CASCADE,
        FOREIGN KEY (vendor_id) REFERENCES calibration_vendors(id)
    );

    CREATE TABLE IF NOT EXISTS calibration_schedules (
        id TEXT PRIMARY KEY,
        alkes_id TEXT NOT NULL,
        due_date TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled','completed','overdue','cancelled')),
        assigned_vendor TEXT,
        notes TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (alkes_id) REFERENCES alkes(id) ON DELETE CASCADE,
        FOREIGN KEY (assigned_vendor) REFERENCES calibration_vendors(id)
    );

    -- ==================== KALIBRASI INDEXES ====================
    CREATE INDEX IF NOT EXISTS idx_alkes_unit ON alkes(unit_id);
    CREATE INDEX IF NOT EXISTS idx_alkes_category ON alkes(category);
    CREATE INDEX IF NOT EXISTS idx_alkes_next_cal ON alkes(next_calibration);
    CREATE INDEX IF NOT EXISTS idx_cal_alkes ON calibrations(alkes_id);
    CREATE INDEX IF NOT EXISTS idx_cal_date ON calibrations(date);
    CREATE INDEX IF NOT EXISTS idx_cal_vendor ON calibrations(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_calp_alkes ON calibration_prices(alkes_id);
    CREATE INDEX IF NOT EXISTS idx_calp_vendor ON calibration_prices(vendor_id);
    CREATE INDEX IF NOT EXISTS idx_cals_alkes ON calibration_schedules(alkes_id);
    CREATE INDEX IF NOT EXISTS idx_cals_due ON calibration_schedules(due_date);
    CREATE INDEX IF NOT EXISTS idx_cals_status ON calibration_schedules(status);
    """)

    # Migrations for existing databases
    try:
        c.execute("ALTER TABLE request_items ADD COLUMN status TEXT NOT NULL DEFAULT 'active'")
        conn.commit()
    except Exception:
        pass  # Column already exists

    conn.commit()
    conn.close()


def log_audit(conn, user_name, action, entity, entity_id='', detail=''):
    """Write an audit log entry."""
    from datetime import datetime
    conn.execute(
        "INSERT INTO audit_log (timestamp, user_name, action, entity, entity_id, detail) VALUES (?,?,?,?,?,?)",
        (datetime.now().isoformat(timespec='seconds'), user_name, action, entity, entity_id, detail)
    )


def seed_data(demo=False):
    """Seed initial users. If demo=True, also inserts sample products/vendors/stock."""
    conn = get_db()
    c = conn.cursor()

    # Always ensure admin + direktur exist
    if c.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0:
        conn.close()
        return

    from werkzeug.security import generate_password_hash
    c.executemany("INSERT INTO users VALUES (?,?,?,?,?,?)", [
        ('usr_admin', 'admin', generate_password_hash('admin123'), 'admin', None, 'Administrator'),
        ('usr_direktur', 'direktur', generate_password_hash('direktur123'), 'direktur', None, 'Direktur Klinik'),
    ])

    if not demo:
        conn.commit()
        conn.close()
        print("[DB] Production seed: admin + direktur users created")
        return

    # ==================== DEMO DATA ====================
    units = [
        ('u1', 'Rawat Jalan'), ('u2', 'UGD'), ('u3', 'Rawat Inap'),
        ('u4', 'Farmasi'), ('u5', 'Admisi'), ('u6', 'Radiologi'),
        ('u7', 'Laboratorium'), ('u8', 'ICU'),
    ]
    c.executemany("INSERT INTO units VALUES (?,?)", units)

    products = [
        ('p1', 'Pulpen hitam', 'Tulis menulis', 'ATK', 'Pcs'),
        ('p2', 'Pulpen merah', 'Tulis menulis', 'ATK', 'Pcs'),
        ('p3', 'Kertas A4 80gr', 'Kertas', 'ATK', 'Rim'),
        ('p4', 'Amplop coklat besar', 'Kertas', 'ATK', 'Pcs'),
        ('p5', 'Spidol whiteboard', 'Tulis menulis', 'ATK', 'Pcs'),
        ('p6', 'Buku folio 100 lembar', 'Buku', 'ATK', 'Buah'),
        ('p7', 'Staples no.10', 'Alat kantor', 'ATK', 'Buah'),
        ('p8', 'Map plastik transparan', 'Arsip', 'ATK', 'Pcs'),
        ('p9', 'Tinta printer hitam', 'Printer', 'ATK', 'Botol'),
        ('p10', 'Tissu box', 'Kebersihan', 'RTK', 'Box'),
        ('p11', 'Sabun cuci tangan', 'Kebersihan', 'RTK', 'Botol'),
        ('p12', 'Hand sanitizer 500ml', 'Kebersihan', 'RTK', 'Botol'),
        ('p13', 'Kantong plastik sampah', 'Kebersihan', 'RTK', 'Pack'),
        ('p14', 'Refill staples', 'Alat kantor', 'ATK', 'Box'),
    ]
    c.executemany("INSERT INTO products VALUES (?,?,?,?,?)", products)

    vendors = [
        ('v1', 'CV. Sumber Makmur', '081234567890', 'Serang, Banten'),
        ('v2', 'UD. Berkah Jaya', '089876543210', 'Cilegon, Banten'),
        ('v3', 'PT. Indo Supply', '087654321098', 'Jakarta Barat'),
    ]
    c.executemany("INSERT INTO vendors VALUES (?,?,?,?)", vendors)

    vprices = [
        ('vp1', 'p1', 'v1', 2500, 0), ('vp2', 'p1', 'v2', 2000, 1), ('vp3', 'p1', 'v3', 2200, 0),
        ('vp4', 'p3', 'v1', 55000, 1), ('vp5', 'p3', 'v2', 57000, 0),
        ('vp6', 'p10', 'v1', 18000, 0), ('vp7', 'p10', 'v3', 15000, 1),
        ('vp8', 'p11', 'v1', 22000, 1), ('vp9', 'p12', 'v2', 35000, 1),
        ('vp10', 'p12', 'v3', 38000, 0), ('vp11', 'p5', 'v1', 12000, 1),
        ('vp12', 'p5', 'v2', 11500, 0), ('vp13', 'p2', 'v1', 2800, 1),
        ('vp14', 'p13', 'v2', 15000, 1),
        ('vp15', 'p4', 'v1', 1500, 1),
        ('vp16', 'p6', 'v2', 15000, 1),
        ('vp17', 'p7', 'v1', 25000, 1),
        ('vp18', 'p8', 'v1', 3500, 1),
        ('vp19', 'p9', 'v3', 85000, 1),
        ('vp20', 'p14', 'v1', 12000, 1),
    ]
    c.executemany("INSERT INTO vendor_prices VALUES (?,?,?,?,?)", vprices)

    stocks = [
        ('s1', 'u1', 'p1', 20), ('s2', 'u1', 'p3', 5), ('s3', 'u1', 'p10', 4),
        ('s4', 'u2', 'p1', 15), ('s5', 'u2', 'p10', 3), ('s6', 'u2', 'p12', 2),
        ('s7', 'u3', 'p1', 10), ('s8', 'u3', 'p12', 6),
        ('s9', 'u4', 'p11', 8), ('s10', 'u4', 'p12', 5),
        ('s11', 'u5', 'p1', 12), ('s12', 'u5', 'p3', 3),
        ('s13', 'u6', 'p1', 7), ('s14', 'u6', 'p10', 2),
    ]
    c.executemany("INSERT INTO stock VALUES (?,?,?,?)", stocks)

    for u in units:
        uid = f'usr_{u[0]}'
        uname = u[1].lower().replace(' ', '')
        c.execute("INSERT INTO users VALUES (?,?,?,?,?,?)",
                  (uid, uname, generate_password_hash('1234'), 'unit', u[0], u[1]))

    for p in products:
        c.execute("INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                  (f'ws_{p[0]}', p[0], 50))

    conn.commit()
    conn.close()
    print("[DB] Seed data inserted successfully")


if __name__ == '__main__':
    init_db()
    seed_data()
    print("[DB] Database initialized at:", DB_PATH)
