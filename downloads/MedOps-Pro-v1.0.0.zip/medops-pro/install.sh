#!/bin/bash
echo "=========================================="
echo "  MedOps Pro — Installer"
echo "=========================================="

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "[!] Python3 belum terinstall"
    echo "    sudo apt install python3 python3-pip"
    exit 1
fi

echo "[1/2] Installing dependencies..."
pip3 install flask flask-cors openpyxl cryptography werkzeug --quiet

echo "[2/2] Initializing database..."
python3 -c "from db_manager import init_db, seed_data; init_db(); seed_data(demo=False)"

echo ""
echo "=========================================="
echo "  Install selesai!"
echo "=========================================="
echo ""
echo "  Jalankan: bash start.sh"
echo "  Buka browser: http://localhost:8060"
echo ""
echo "  Login pertama kali:"
echo "    Admin    : admin / admin123"
echo "    Direktur : direktur / direktur123"
echo ""
