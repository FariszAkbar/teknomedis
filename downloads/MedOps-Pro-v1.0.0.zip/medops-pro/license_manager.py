"""MedOps Pro — License Management System.

Hardware-bound license with encrypted key + digital signature.
Supports online validation and grace period.
"""
import hashlib
import json
import os
import platform
import uuid
import base64
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding

# ==================== CONFIG ====================
LICENSE_DIR = os.path.join(os.path.dirname(__file__), 'data')
LICENSE_FILE = os.path.join(LICENSE_DIR, '.license')
GRACE_DAYS = 30  # days without online check before lockout
CHECK_INTERVAL_DAYS = 7  # phone home every N days

# Symmetric key for license encryption (shared between generator and validator)
# In production, this would be embedded in compiled binary
LICENSE_SECRET = b'MediStokPro2026SecureKey!@#$%^&*()'
FERNET_KEY = base64.urlsafe_b64encode(hashlib.sha256(LICENSE_SECRET).digest())


# ==================== HARDWARE ID ====================
def get_hardware_id():
    """Generate unique hardware fingerprint from MAC + platform."""
    mac = uuid.getnode()
    system = platform.system()
    node = platform.node()
    raw = f"{mac}-{system}-{node}-MediStokPro"
    return hashlib.sha256(raw.encode()).hexdigest()[:16].upper()


def format_hwid(hwid):
    """Format HWID as XXXX-XXXX-XXXX-XXXX."""
    return '-'.join(hwid[i:i+4] for i in range(0, 16, 4))


# ==================== LICENSE GENERATION ====================
def generate_license(hwid, clinic_name, days, plan='pro', max_users=10):
    """Generate an encrypted license key.

    Args:
        hwid: Hardware ID of target machine
        clinic_name: Name of the clinic/hospital
        days: License duration in days
        plan: License plan (basic/pro/enterprise)
        max_users: Maximum concurrent users

    Returns:
        str: Base64-encoded encrypted license key
    """
    now = datetime.now()
    license_data = {
        'hwid': hwid,
        'clinic': clinic_name,
        'plan': plan,
        'max_users': max_users,
        'issued': now.isoformat(),
        'expires': (now + timedelta(days=days)).isoformat(),
        'days': days,
        'version': '1.0',
        'product': 'MedOps Pro',
    }
    # Sign the data
    data_str = json.dumps(license_data, sort_keys=True)
    signature = hashlib.sha256((data_str + LICENSE_SECRET.decode()).encode()).hexdigest()
    license_data['signature'] = signature

    # Encrypt
    f = Fernet(FERNET_KEY)
    encrypted = f.encrypt(json.dumps(license_data).encode())
    return encrypted.decode()


# ==================== LICENSE VALIDATION ====================
def decrypt_license(license_key):
    """Decrypt and validate a license key.

    Returns:
        dict or None: License data if valid, None if invalid
    """
    try:
        f = Fernet(FERNET_KEY)
        decrypted = f.decrypt(license_key.encode())
        data = json.loads(decrypted)

        # Verify signature
        sig = data.pop('signature', '')
        data_str = json.dumps(data, sort_keys=True)
        expected_sig = hashlib.sha256((data_str + LICENSE_SECRET.decode()).encode()).hexdigest()
        if sig != expected_sig:
            return None

        data['signature'] = sig
        return data
    except Exception:
        return None


def validate_license():
    """Validate the installed license.

    Returns:
        dict: {
            'valid': bool,
            'status': str ('active'|'expired'|'invalid'|'no_license'|'hwid_mismatch'),
            'data': dict or None,
            'days_left': int,
            'message': str
        }
    """
    os.makedirs(LICENSE_DIR, exist_ok=True)

    if not os.path.exists(LICENSE_FILE):
        return {
            'valid': False, 'status': 'no_license', 'data': None,
            'days_left': 0, 'message': 'Belum ada lisensi. Masukkan license key untuk aktivasi.'
        }

    try:
        with open(LICENSE_FILE, 'r') as f:
            stored = json.load(f)
    except Exception:
        return {
            'valid': False, 'status': 'invalid', 'data': None,
            'days_left': 0, 'message': 'File lisensi rusak.'
        }

    license_key = stored.get('key', '')
    data = decrypt_license(license_key)

    if not data:
        return {
            'valid': False, 'status': 'invalid', 'data': None,
            'days_left': 0, 'message': 'License key tidak valid.'
        }

    # Check hardware ID
    current_hwid = get_hardware_id()
    if data.get('hwid') != current_hwid:
        return {
            'valid': False, 'status': 'hwid_mismatch', 'data': data,
            'days_left': 0,
            'message': f'Lisensi terdaftar untuk perangkat lain. HWID: {format_hwid(current_hwid)}'
        }

    # Check expiry
    expires = datetime.fromisoformat(data['expires'])
    now = datetime.now()
    days_left = (expires - now).days

    if days_left < 0:
        return {
            'valid': False, 'status': 'expired', 'data': data,
            'days_left': 0,
            'message': f'Lisensi expired sejak {abs(days_left)} hari lalu. Hubungi admin untuk perpanjangan.'
        }

    # Check online validation timestamp
    last_check = stored.get('last_online_check', '')
    grace_warning = ''
    if last_check:
        last_dt = datetime.fromisoformat(last_check)
        days_since_check = (now - last_dt).days
        if days_since_check > GRACE_DAYS:
            return {
                'valid': False, 'status': 'grace_expired', 'data': data,
                'days_left': days_left,
                'message': f'Validasi online diperlukan. Terakhir validasi {days_since_check} hari lalu.'
            }
        if days_since_check > CHECK_INTERVAL_DAYS:
            grace_warning = f' (validasi online terakhir {days_since_check} hari lalu)'

    return {
        'valid': True, 'status': 'active', 'data': data,
        'days_left': days_left,
        'message': f'Lisensi aktif. Sisa {days_left} hari.{grace_warning}'
    }


# ==================== LICENSE ACTIVATION ====================
def activate_license(license_key):
    """Activate a license key on this machine.

    Returns:
        dict: {'ok': bool, 'message': str, 'data': dict or None}
    """
    os.makedirs(LICENSE_DIR, exist_ok=True)
    data = decrypt_license(license_key.strip())

    if not data:
        return {'ok': False, 'message': 'License key tidak valid.', 'data': None}

    # Check hardware ID
    current_hwid = get_hardware_id()
    if data.get('hwid') != current_hwid:
        return {
            'ok': False, 'data': None,
            'message': f'License key ini untuk perangkat lain. HWID Anda: {format_hwid(current_hwid)}'
        }

    # Check if expired
    expires = datetime.fromisoformat(data['expires'])
    if datetime.now() > expires:
        return {'ok': False, 'message': 'License key sudah expired.', 'data': None}

    # Save license
    stored = {
        'key': license_key.strip(),
        'activated_at': datetime.now().isoformat(),
        'last_online_check': datetime.now().isoformat(),
    }
    with open(LICENSE_FILE, 'w') as f:
        json.dump(stored, f)

    return {
        'ok': True,
        'message': f'Lisensi aktif untuk {data["clinic"]}. Berlaku {data["days"]} hari.',
        'data': data
    }


def update_online_check():
    """Update the last online check timestamp."""
    if not os.path.exists(LICENSE_FILE):
        return
    try:
        with open(LICENSE_FILE, 'r') as f:
            stored = json.load(f)
        stored['last_online_check'] = datetime.now().isoformat()
        with open(LICENSE_FILE, 'w') as f:
            json.dump(stored, f)
    except Exception:
        pass


def get_license_info():
    """Get current license info for display."""
    result = validate_license()
    hwid = get_hardware_id()
    return {
        **result,
        'hwid': format_hwid(hwid),
        'hwid_raw': hwid,
    }


# ==================== CLI ====================
if __name__ == '__main__':
    import sys

    if len(sys.argv) < 2:
        print("MedOps Pro — License Manager")
        print("=" * 40)
        info = get_license_info()
        print(f"Hardware ID: {info['hwid']}")
        print(f"Status: {info['status']}")
        print(f"Message: {info['message']}")
        if info['data']:
            print(f"Clinic: {info['data'].get('clinic', '-')}")
            print(f"Plan: {info['data'].get('plan', '-')}")
            print(f"Expires: {info['data'].get('expires', '-')}")
        print()
        print("Usage:")
        print("  python license_manager.py generate <HWID> <clinic_name> <days>")
        print("  python license_manager.py activate <license_key>")
        print("  python license_manager.py hwid")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == 'hwid':
        hwid = get_hardware_id()
        print(f"Hardware ID: {format_hwid(hwid)}")

    elif cmd == 'generate':
        if len(sys.argv) < 5:
            print("Usage: generate <HWID> <clinic_name> <days>")
            sys.exit(1)
        hwid = sys.argv[2].replace('-', '')
        clinic = sys.argv[3]
        days = int(sys.argv[4])
        key = generate_license(hwid, clinic, days)
        print(f"License generated for: {clinic}")
        print(f"HWID: {format_hwid(hwid)}")
        print(f"Duration: {days} days")
        print(f"\nLicense Key:\n{key}")

    elif cmd == 'activate':
        if len(sys.argv) < 3:
            print("Usage: activate <license_key>")
            sys.exit(1)
        key = sys.argv[2]
        result = activate_license(key)
        print(f"{'OK' if result['ok'] else 'FAILED'}: {result['message']}")
