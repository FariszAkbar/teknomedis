"""Auth routes: login, users, password management."""
from flask import Blueprint, request, jsonify
from werkzeug.security import check_password_hash, generate_password_hash
from db_manager import get_db, log_audit
from helpers import dict_rows, safe_db

bp = Blueprint('auth', __name__)


@bp.route('/api/login', methods=['POST'])
@safe_db
def login():
    data = request.json
    username = data.get('username', '').strip()
    password = data.get('password', '')

    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()

    if not user or not check_password_hash(user['password_hash'], password):
        return jsonify({'ok': False, 'error': 'Username atau password salah'}), 401

    return jsonify({
        'ok': True,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'role': user['role'],
            'unit_id': user['unit_id'],
            'display_name': user['display_name'],
        }
    })


@bp.route('/api/users', methods=['GET'])
@safe_db
def get_users():
    conn = get_db()
    rows = conn.execute("SELECT id, username, role, unit_id, display_name FROM users").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/users/<uid>/password', methods=['PUT'])
@safe_db
def change_password(uid):
    data = request.json
    new_pw = data.get('password', '')
    if len(new_pw) < 4:
        return jsonify({'ok': False, 'error': 'Password minimal 4 karakter'}), 400
    conn = get_db()
    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_pw), uid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/users/<username>/password-by-username', methods=['PUT'])
@safe_db
def change_password_by_username(username):
    data = request.json
    new_pw = data.get('password', '')
    if len(new_pw) < 4:
        return jsonify({'ok': False, 'error': 'Password minimal 4 karakter'}), 400
    conn = get_db()
    user = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
    if not user:
        conn.close()
        return jsonify({'ok': False, 'error': 'User tidak ditemukan'}), 404
    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_pw), user['id']))
    log_audit(conn, '', 'CHANGE_PASSWORD', 'users', user['id'], f'Username: {username}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
