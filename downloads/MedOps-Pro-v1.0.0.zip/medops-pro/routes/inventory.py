"""Inventory routes: stock, warehouse_stock, usage."""
from flask import Blueprint, request, jsonify
from datetime import date
from db_manager import get_db
from helpers import dict_rows, safe_db

bp = Blueprint('inventory', __name__)


# ===================== STOCK =====================
@bp.route('/api/stock')
@safe_db
def get_stock():
    unit_id = request.args.get('unit_id')
    conn = get_db()
    if unit_id:
        rows = conn.execute("SELECT * FROM stock WHERE unit_id=?", (unit_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM stock").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/stock/<sid>', methods=['PUT'])
@safe_db
def update_stock(sid):
    data = request.json
    conn = get_db()
    conn.execute("UPDATE stock SET qty=? WHERE id=?", (data['qty'], sid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== USAGE =====================
@bp.route('/api/usage', methods=['POST'])
@safe_db
def record_usage():
    data = request.json
    items = [i for i in data.get('items', []) if i.get('qty', 0) > 0]
    if not items:
        return jsonify({'ok': False, 'error': 'Tidak ada pemakaian dicatat'}), 400
    uid = data.get('unit_id', '')
    conn = get_db()
    for item in items:
        pid = item['product_id']
        qty = int(item['qty'])
        # Check current stock
        cur = conn.execute("SELECT qty FROM stock WHERE unit_id=? AND product_id=?", (uid, pid)).fetchone()
        if not cur or cur['qty'] < qty:
            prod = conn.execute("SELECT name FROM products WHERE id=?", (pid,)).fetchone()
            conn.close()
            return jsonify({'ok': False, 'error': f'Stok {prod["name"] if prod else pid} tidak cukup (sisa: {cur["qty"] if cur else 0})'}), 400
        conn.execute("UPDATE stock SET qty=qty-? WHERE unit_id=? AND product_id=?", (qty, uid, pid))
        conn.execute("INSERT INTO usage_log (unit_id, product_id, qty_used, date) VALUES (?,?,?,?)",
                     (uid, pid, qty, date.today().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/usage')
@safe_db
def get_usage():
    unit_id = request.args.get('unit_id')
    conn = get_db()
    if unit_id:
        rows = conn.execute(
            "SELECT * FROM usage_log WHERE unit_id=? ORDER BY date DESC LIMIT 100",
            (unit_id,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM usage_log ORDER BY date DESC LIMIT 100").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


# ===================== WAREHOUSE STOCK =====================
@bp.route('/api/warehouse')
@safe_db
def get_warehouse():
    conn = get_db()
    rows = conn.execute("""
        SELECT ws.id, ws.product_id, ws.qty, p.name, p.category, p.type, p.uom
        FROM warehouse_stock ws JOIN products p ON ws.product_id = p.id
        ORDER BY p.name
    """).fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/warehouse/<wid>', methods=['PUT'])
@safe_db
def update_warehouse(wid):
    data = request.json
    conn = get_db()
    conn.execute("UPDATE warehouse_stock SET qty=? WHERE id=?", (data['qty'], wid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
