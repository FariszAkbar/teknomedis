"""Master data routes: units, products, vendors, vendor_prices."""
from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash
from db_manager import get_db, log_audit
from helpers import gid, get_json, dict_rows, ok, err, safe_db

bp = Blueprint('master', __name__)


# ===================== UNITS =====================
@bp.route('/api/units')
@safe_db
def get_units():
    conn = get_db()
    rows = conn.execute("SELECT * FROM units").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/units', methods=['POST'])
@safe_db
def add_unit():
    data = get_json()
    name = data.get('name', '').strip()
    if not name:
        return err('Nama unit wajib diisi')
    uid = gid()
    username = name.lower().replace(' ', '')
    conn = get_db()
    # Check duplicate
    if conn.execute("SELECT id FROM units WHERE name=?", (name,)).fetchone():
        conn.close()
        return err(f'Unit "{name}" sudah ada')
    conn.execute("INSERT INTO units (id, name) VALUES (?,?)", (uid, name))
    # Auto-create user for this unit
    user_id = f'usr_{uid}'
    conn.execute(
        "INSERT INTO users (id, username, password_hash, role, unit_id, display_name) VALUES (?,?,?,?,?,?)",
        (user_id, username, generate_password_hash('1234'), 'unit', uid, name)
    )
    log_audit(conn, '', 'ADD_UNIT', 'units', uid, f'Name: {name}, User: {username}')
    conn.commit()
    conn.close()
    return ok(id=uid, username=username)


# ===================== PRODUCTS =====================
@bp.route('/api/products')
@safe_db
def get_products():
    conn = get_db()
    rows = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/products', methods=['POST'])
@safe_db
def add_product():
    data = request.json
    pid = gid()
    conn = get_db()
    conn.execute(
        "INSERT INTO products (id, name, category, type, uom) VALUES (?,?,?,?,?)",
        (pid, data['name'], data.get('category', 'Lainnya'), data.get('type', 'ATK'), data.get('uom', 'Pcs'))
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': pid})


@bp.route('/api/products/<pid>', methods=['PUT'])
@safe_db
def update_product(pid):
    data = request.json
    conn = get_db()
    conn.execute(
        "UPDATE products SET name=?, category=?, type=?, uom=? WHERE id=?",
        (data['name'], data.get('category', 'Lainnya'), data.get('type', 'ATK'), data.get('uom', 'Pcs'), pid)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/products/<pid>', methods=['DELETE'])
@safe_db
def delete_product(pid):
    conn = get_db()
    conn.execute("DELETE FROM products WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== VENDORS =====================
@bp.route('/api/vendors')
@safe_db
def get_vendors():
    conn = get_db()
    rows = conn.execute("SELECT * FROM vendors ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/vendors', methods=['POST'])
@safe_db
def add_vendor():
    data = request.json
    vid = gid()
    conn = get_db()
    conn.execute(
        "INSERT INTO vendors (id, name, contact, address) VALUES (?,?,?,?)",
        (vid, data['name'], data.get('contact', ''), data.get('address', ''))
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': vid})


@bp.route('/api/vendors/<vid>', methods=['PUT'])
@safe_db
def update_vendor(vid):
    data = request.json
    conn = get_db()
    conn.execute(
        "UPDATE vendors SET name=?, contact=?, address=? WHERE id=?",
        (data['name'], data.get('contact', ''), data.get('address', ''), vid)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/vendors/<vid>', methods=['DELETE'])
@safe_db
def delete_vendor(vid):
    conn = get_db()
    conn.execute("DELETE FROM vendors WHERE id=?", (vid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== VENDOR PRICES =====================
@bp.route('/api/vendor-prices')
@safe_db
def get_vendor_prices():
    conn = get_db()
    rows = conn.execute("SELECT * FROM vendor_prices").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/vendor-prices', methods=['POST'])
@safe_db
def add_vendor_price():
    data = request.json
    vpid = gid()
    conn = get_db()
    has_default = conn.execute(
        "SELECT COUNT(*) FROM vendor_prices WHERE product_id=? AND is_default=1",
        (data['product_id'],)
    ).fetchone()[0]
    is_def = 1 if has_default == 0 else (1 if data.get('is_default') else 0)
    if is_def:
        conn.execute("UPDATE vendor_prices SET is_default=0 WHERE product_id=?", (data['product_id'],))
    conn.execute(
        "INSERT INTO vendor_prices (id, product_id, vendor_id, price, is_default) VALUES (?,?,?,?,?)",
        (vpid, data['product_id'], data['vendor_id'], data['price'], is_def)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': vpid})


@bp.route('/api/vendor-prices/<vpid>', methods=['PUT'])
@safe_db
def update_vendor_price(vpid):
    data = request.json
    conn = get_db()
    conn.execute("UPDATE vendor_prices SET price=? WHERE id=?", (data['price'], vpid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/vendor-prices/<vpid>/set-default', methods=['POST'])
@safe_db
def set_default_price(vpid):
    conn = get_db()
    row = conn.execute("SELECT product_id FROM vendor_prices WHERE id=?", (vpid,)).fetchone()
    if row:
        conn.execute("UPDATE vendor_prices SET is_default=0 WHERE product_id=?", (row['product_id'],))
        conn.execute("UPDATE vendor_prices SET is_default=1 WHERE id=?", (vpid,))
        conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/vendor-prices/<vpid>', methods=['DELETE'])
@safe_db
def delete_vendor_price(vpid):
    conn = get_db()
    conn.execute("DELETE FROM vendor_prices WHERE id=?", (vpid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
