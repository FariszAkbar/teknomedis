"""Request routes: unit requests, approve/reject/fulfill."""
from flask import Blueprint, request, jsonify
from datetime import date
from db_manager import get_db, log_audit
from helpers import gid, safe_db

bp = Blueprint('requests', __name__)


@bp.route('/api/requests')
@safe_db
def get_requests():
    unit_id = request.args.get('unit_id')
    conn = get_db()
    if unit_id:
        rows = conn.execute("SELECT * FROM requests WHERE unit_id=? ORDER BY date DESC", (unit_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM requests ORDER BY date DESC").fetchall()
    result = []
    for r in rows:
        rd = dict(r)
        items = conn.execute(
            "SELECT id, product_id, qty, COALESCE(status,'active') as status FROM request_items WHERE request_id=?", (r['id'],)
        ).fetchall()
        rd['items'] = [{'id': i['id'], 'product_id': i['product_id'], 'qty': i['qty'], 'status': i['status']} for i in items]
        result.append(rd)
    conn.close()
    return jsonify(result)


@bp.route('/api/requests', methods=['POST'])
@safe_db
def create_request():
    data = request.json
    conn = get_db()
    today = date.today()
    prefix = f"REQ-{today.strftime('%Y-%m')}"
    count = conn.execute("SELECT COUNT(*) FROM requests WHERE id LIKE ?", (prefix + '%',)).fetchone()[0]
    rid = f"{prefix}-{count+1:03d}"
    conn.execute(
        "INSERT INTO requests (id, unit_id, status, date, notes) VALUES (?,?,?,?,?)",
        (rid, data['unit_id'], 'pending', date.today().isoformat(), data.get('notes', ''))
    )
    for item in data.get('items', []):
        conn.execute(
            "INSERT INTO request_items (request_id, product_id, qty) VALUES (?,?,?)",
            (rid, item['product_id'], item['qty'])
        )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': rid})


@bp.route('/api/requests/<rid>/approve', methods=['POST'])
@safe_db
def approve_request(rid):
    conn = get_db()
    # Only approve items that are not rejected
    active_items = conn.execute(
        "SELECT COUNT(*) FROM request_items WHERE request_id=? AND COALESCE(status,'active') != 'rejected'",
        (rid,)
    ).fetchone()[0]
    if active_items == 0:
        conn.close()
        return jsonify({'ok': False, 'error': 'Semua item ditolak, tidak bisa disetujui'}), 400
    conn.execute("UPDATE requests SET status='approved' WHERE id=?", (rid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/<rid>/reject', methods=['POST'])
@safe_db
def reject_request(rid):
    conn = get_db()
    conn.execute("UPDATE requests SET status='rejected' WHERE id=?", (rid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/item/<int:item_id>/reject', methods=['POST'])
@safe_db
def reject_request_item(item_id):
    """Reject a single item in a request."""
    conn = get_db()
    item = conn.execute("SELECT * FROM request_items WHERE id=?", (item_id,)).fetchone()
    if not item:
        conn.close()
        return jsonify({'ok': False, 'error': 'Item tidak ditemukan'}), 404

    conn.execute("UPDATE request_items SET status='rejected' WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/item/<int:item_id>/restore', methods=['POST'])
@safe_db
def restore_request_item(item_id):
    """Restore a rejected item."""
    conn = get_db()
    conn.execute("UPDATE request_items SET status='active' WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/<rid>/fulfill', methods=['POST'])
@safe_db
def fulfill_request(rid):
    conn = get_db()
    req = conn.execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone()
    if not req:
        conn.close()
        return jsonify({'ok': False, 'error': 'Not found'}), 404

    # Only fulfill active (non-rejected) items
    items = conn.execute(
        "SELECT * FROM request_items WHERE request_id=? AND COALESCE(status,'active') != 'rejected'",
        (rid,)
    ).fetchall()
    if not items:
        conn.close()
        return jsonify({'ok': False, 'error': 'Tidak ada item aktif untuk dipenuhi'}), 400

    for it in items:
        # Deduct from warehouse (can go negative — restock via purchase order)
        conn.execute("UPDATE warehouse_stock SET qty=qty-? WHERE product_id=?",
                     (it['qty'], it['product_id']))
        # Add to unit stock
        existing = conn.execute(
            "SELECT * FROM stock WHERE unit_id=? AND product_id=?",
            (req['unit_id'], it['product_id'])
        ).fetchone()
        if existing:
            conn.execute("UPDATE stock SET qty=qty+? WHERE id=?", (it['qty'], existing['id']))
        else:
            conn.execute(
                "INSERT INTO stock (id, unit_id, product_id, qty) VALUES (?,?,?,?)",
                (gid(), req['unit_id'], it['product_id'], it['qty'])
            )

    conn.execute("UPDATE requests SET status='fulfilled' WHERE id=?", (rid,))
    log_audit(conn, '', 'FULFILL', 'requests', rid, f'Unit: {req["unit_id"]}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
