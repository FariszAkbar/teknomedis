"""Upload routes: excel upload/download templates."""
import io
from flask import Blueprint, request, jsonify, send_file
from datetime import date
from openpyxl import Workbook, load_workbook
from db_manager import get_db
from helpers import gid, safe_db

bp = Blueprint('upload', __name__)


@bp.route('/api/template/<ttype>')
@safe_db
def download_template(ttype):
    wb = Workbook()
    ws = wb.active
    if ttype == 'products':
        ws.title = 'Produk'
        ws.append(['Nama Produk', 'Kategori', 'Jenis (ATK/RTK)', 'Satuan'])
        ws.append(['Contoh: Pulpen Hitam', 'Tulis menulis', 'ATK', 'Pcs'])
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 20
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 12
    elif ttype == 'purchase':
        ws.title = 'Pembelian'
        ws.append(['Nama Produk (harus sudah terdaftar)', 'Qty', 'Harga Satuan (Rp)'])
        ws.append(['Pulpen hitam', 100, 2000])
        ws.column_dimensions['A'].width = 35
        ws.column_dimensions['B'].width = 10
        ws.column_dimensions['C'].width = 20
    elif ttype == 'warehouse':
        ws.title = 'Stok Gudang'
        ws.append(['Nama Produk (harus sudah terdaftar)', 'Qty'])
        ws.append(['Pulpen hitam', 50])
        ws.column_dimensions['A'].width = 35
        ws.column_dimensions['B'].width = 10
    else:
        return jsonify({'ok': False, 'error': 'Unknown template'}), 400

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, download_name=f'template_{ttype}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@bp.route('/api/upload/<utype>', methods=['POST'])
@safe_db
def upload_excel(utype):
    if 'file' not in request.files:
        return jsonify({'ok': False, 'error': 'No file uploaded'}), 400
    f = request.files['file']
    if not f.filename.endswith(('.xlsx', '.xls')):
        return jsonify({'ok': False, 'error': 'File harus format Excel (.xlsx)'}), 400

    wb = load_workbook(f)
    ws = wb.active
    conn = get_db()
    count = 0
    errors = []

    if utype == 'products':
        for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
            if not row[0] or str(row[0]).startswith('Contoh'):
                continue
            name = str(row[0]).strip()
            cat = str(row[1]).strip() if row[1] else 'Lainnya'
            ptype = str(row[2]).strip().upper() if row[2] else 'ATK'
            uom = str(row[3]).strip() if row[3] else 'Pcs'
            if ptype not in ('ATK', 'RTK'):
                ptype = 'ATK'
            existing = conn.execute("SELECT id FROM products WHERE name=?", (name,)).fetchone()
            if existing:
                conn.execute("UPDATE products SET category=?, type=?, uom=? WHERE id=?",
                             (cat, ptype, uom, existing['id']))
            else:
                conn.execute("INSERT INTO products (id, name, category, type, uom) VALUES (?,?,?,?,?)",
                             (gid(), name, cat, ptype, uom))
            count += 1

    elif utype == 'purchase':
        vendor_id = request.form.get('vendor_id')
        purchase_id = gid()
        total = 0
        items_added = 0
        for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
            if not row[0] or str(row[0]).startswith('Contoh'):
                continue
            name = str(row[0]).strip()
            qty = int(row[1]) if row[1] else 0
            price = int(row[2]) if row[2] else 0
            if qty <= 0:
                errors.append(f'Baris {i}: qty harus > 0')
                continue
            prod = conn.execute("SELECT id FROM products WHERE name=?", (name,)).fetchone()
            if not prod:
                errors.append(f'Baris {i}: produk "{name}" tidak ditemukan')
                continue
            total += qty * price
            conn.execute("INSERT INTO purchase_items (purchase_id, product_id, qty, price) VALUES (?,?,?,?)",
                         (purchase_id, prod['id'], qty, price))
            # Update warehouse
            ws_row = conn.execute("SELECT id, qty FROM warehouse_stock WHERE product_id=?",
                                 (prod['id'],)).fetchone()
            if ws_row:
                conn.execute("UPDATE warehouse_stock SET qty=qty+? WHERE id=?", (qty, ws_row['id']))
            else:
                conn.execute("INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                             (gid(), prod['id'], qty))
            items_added += 1
        if items_added > 0:
            conn.execute("INSERT INTO purchases (id, date, vendor_id, notes, total) VALUES (?,?,?,?,?)",
                         (purchase_id, date.today().isoformat(), vendor_id, 'Upload Excel', total))
        count = items_added

    elif utype == 'warehouse':
        for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
            if not row[0] or str(row[0]).startswith('Contoh'):
                continue
            name = str(row[0]).strip()
            qty = int(row[1]) if row[1] else 0
            prod = conn.execute("SELECT id FROM products WHERE name=?", (name,)).fetchone()
            if not prod:
                errors.append(f'Baris {i}: produk "{name}" tidak ditemukan')
                continue
            ws_row = conn.execute("SELECT id FROM warehouse_stock WHERE product_id=?",
                                 (prod['id'],)).fetchone()
            if ws_row:
                conn.execute("UPDATE warehouse_stock SET qty=? WHERE id=?", (qty, ws_row['id']))
            else:
                conn.execute("INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                             (gid(), prod['id'], qty))
            count += 1

    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'count': count, 'errors': errors})
