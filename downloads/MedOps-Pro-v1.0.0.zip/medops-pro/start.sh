#!/bin/bash
cd "$(dirname "$0")"
echo "=========================================="
echo "  MedOps Pro — Server Running"
echo "=========================================="
LAN_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo "  Local: http://localhost:8060"
[ -n "$LAN_IP" ] && echo "  LAN:   http://${LAN_IP}:8060"
echo "  Tekan Ctrl+C untuk stop"
echo "=========================================="
python3 app.py
