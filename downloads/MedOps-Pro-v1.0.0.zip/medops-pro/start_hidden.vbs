' MedOps Pro — Start server tanpa window
' Double-click file ini untuk jalankan server di background
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
WshShell.Run "pythonw app.py", 0, False

' Tunggu 2 detik lalu buka browser
WScript.Sleep 2000
WshShell.Run "http://localhost:8060", 1, False
