@echo off
echo Menghentikan MedOps Pro...
taskkill /F /IM pythonw.exe /T 2>nul
taskkill /F /IM python.exe /FI "WINDOWTITLE eq MedOps Pro*" /T 2>nul
echo Server dihentikan.
pause
