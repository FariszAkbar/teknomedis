"""Shared helpers: validation, formatting, auth decorator."""
import uuid
import re
import logging
from datetime import date, datetime
from functools import wraps
from flask import request, jsonify, session

logger = logging.getLogger(__name__)


def safe_db(fn):
    """Decorator: wraps route in try/except with proper DB cleanup."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            logger.exception(f"Error in {fn.__name__}: {e}")
            return jsonify({'ok': False, 'error': 'Terjadi kesalahan internal'}), 500
    return wrapper


# ===================== AUTH / SESSION =====================

def login_user(user_row):
    """Persist authenticated user in Flask session cookie."""
    session['user_id'] = user_row['id']
    session['username'] = user_row['username']
    session['role'] = user_row['role']
    session['unit_id'] = user_row['unit_id']
    session['display_name'] = user_row['display_name'] or user_row['username']
    session.permanent = True


def logout_user():
    session.clear()


def current_user():
    """Return a dict of the logged-in user, or None."""
    if not session.get('user_id'):
        return None
    return {
        'id': session['user_id'],
        'username': session.get('username', ''),
        'role': session.get('role', ''),
        'unit_id': session.get('unit_id'),
        'display_name': session.get('display_name', ''),
    }


def role_required(*roles):
    """Decorator: 401 kalau belum login, 403 kalau role tidak match.

    Contoh pakai:
        @role_required('admin')                — cuma admin
        @role_required('admin', 'direktur')    — admin atau direktur
        @role_required('*')                    — cukup login (any role)
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_user()
            if not user:
                return jsonify({'ok': False, 'error': 'Belum login'}), 401
            if '*' not in roles and user['role'] not in roles:
                return jsonify({'ok': False,
                                'error': f'Akses ditolak — butuh role: {", ".join(roles)}'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def gid():
    return uuid.uuid4().hex[:8]


def now_ts():
    return f"{date.today().isoformat()} {datetime.now().strftime('%H:%M')}"


def validate_date(s):
    """Validate and return ISO date string, or None."""
    if not s:
        return None
    try:
        datetime.strptime(s, '%Y-%m-%d')
        return s
    except ValueError:
        return None


def validate_int(val, min_val=0, max_val=999999999, default=0):
    """Safely convert to int within range."""
    try:
        v = int(val)
        return max(min_val, min(v, max_val))
    except (TypeError, ValueError):
        return default


def validate_month(s):
    """Validate YYYY-MM format."""
    if not s or not re.match(r'^\d{4}-\d{2}$', s):
        return None
    return s


def get_json():
    """Get request JSON with fallback to empty dict.

    Uses silent=True so missing/invalid Content-Type returns {} instead
    of raising 415 — some frontend code posts empty bodies without headers.
    """
    return request.get_json(silent=True) or {}


def dict_row(row):
    if row is None:
        return None
    return dict(row)


def dict_rows(rows):
    return [dict(r) for r in rows]


def ok(data=None, **kwargs):
    """Standard success response."""
    resp = {'ok': True}
    if data is not None:
        resp['data'] = data
    resp.update(kwargs)
    return jsonify(resp)


def err(message, status=400):
    """Standard error response."""
    return jsonify({'ok': False, 'error': message}), status


def require_json(*fields):
    """Validate required fields in request JSON."""
    data = get_json()
    missing = [f for f in fields if not data.get(f)]
    if missing:
        return None, err(f"Field wajib: {', '.join(missing)}")
    return data, None


def get_clinic_name():
    """Get clinic name from license data for Excel headers etc."""
    try:
        from license_manager import get_license_info
        info = get_license_info()
        if info.get('data') and info['data'].get('clinic'):
            return info['data']['clinic'].upper()
    except Exception:
        pass
    return 'MedOps Pro'
