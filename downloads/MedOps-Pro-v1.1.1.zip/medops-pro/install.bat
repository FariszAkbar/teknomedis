@echo off
cd /d "%~dp0"
echo ==========================================
echo   MedOps Pro - Installer
echo ==========================================
echo.

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python belum terinstall!
    echo Download di: https://www.python.org/downloads/
    echo PENTING: Centang "Add Python to PATH" saat install!
    echo.
    pause
    exit /b 1
)

echo [1/2] Installing dependencies...
pip install flask flask-cors openpyxl cryptography werkzeug --quiet
if %errorlevel% neq 0 (
    echo [ERROR] Gagal install dependencies
    pause
    exit /b 1
)

echo [2/2] Initializing database...
python -c "from db_manager import init_db, seed_data; init_db(); seed_data(demo=False)"

echo.
echo ==========================================
echo   Install selesai!
echo ==========================================
echo.
echo   Jalankan: start.bat
echo   Buka browser: http://localhost:8060
echo.
echo   Login pertama kali:
echo     Admin    : admin / admin123
echo     Direktur : direktur / direktur123
echo.
pause
