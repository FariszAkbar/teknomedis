"""Inventory routes: stock, warehouse_stock, usage.

Auth model:
- Stock adjust per-unit → admin only (audit trail untuk opname).
- Warehouse adjust → admin only.
- Record usage → admin atau unit sendiri (for own unit_id).
- GET endpoints open untuk any logged-in (unit butuh lihat stok sendiri).
"""
from flask import Blueprint, request, jsonify
from datetime import date
from db_manager import get_db, log_audit
from helpers import (dict_rows, safe_db, get_json, role_required,
                     current_user, validate_int, err, ok)

bp = Blueprint('inventory', __name__)


# ===================== STOCK =====================
@bp.route('/api/stock')
@safe_db
def get_stock():
    unit_id = request.args.get('unit_id')
    conn = get_db()
    if unit_id:
        rows = conn.execute("SELECT * FROM stock WHERE unit_id=?", (unit_id,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM stock").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/stock/<sid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_stock(sid):
    """Admin manual adjustment stok unit — untuk stok opname atau koreksi.
    Log via audit_log supaya direktur bisa review siapa ubah apa kapan."""
    data = get_json()
    qty = validate_int(data.get('qty', 0), min_val=0, max_val=10**6)
    conn = get_db()
    prev = conn.execute("SELECT qty, unit_id, product_id FROM stock WHERE id=?", (sid,)).fetchone()
    if not prev:
        conn.close(); return err('Stock entry tidak ditemukan', 404)
    conn.execute("UPDATE stock SET qty=? WHERE id=?", (qty, sid))
    log_audit(conn, (current_user() or {}).get('display_name', ''),
              'ADJUST_STOCK', 'stock', sid,
              f'qty {prev["qty"]}→{qty} unit={prev["unit_id"]} product={prev["product_id"]}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== USAGE =====================
@bp.route('/api/usage', methods=['POST'])
@safe_db
@role_required('admin', 'unit')
def record_usage():
    """Unit catat pemakaian dari stok mereka. Unit hanya boleh record
    untuk unit_id miliknya (cek session). Admin bisa untuk unit manapun.

    Atomic: satu transaction. Kalau salah satu item fail (stok kurang),
    seluruh batch rolled back — tidak ada partial deduction yang bisa
    bikin counter tidak sinkron.
    """
    data = get_json()
    items = [i for i in data.get('items', []) if validate_int(i.get('qty', 0), min_val=1) > 0]
    if not items:
        return err('Tidak ada pemakaian dicatat')
    uid = data.get('unit_id', '')

    # Unit role: force unit_id = miliknya supaya tidak bisa catat usage unit lain
    user = current_user() or {}
    if user.get('role') == 'unit':
        if not user.get('unit_id'):
            return err('User unit belum terasosiasi dengan unit — hubungi admin', 403)
        uid = user['unit_id']

    if not uid:
        return err('unit_id wajib diisi')

    conn = get_db()
    try:
        # Atomic: lock baris stok dengan IMMEDIATE transaction supaya
        # concurrent record_usage tidak sama-sama lulus check lalu
        # deduct lebih dari stock.
        conn.execute('BEGIN IMMEDIATE')
        for item in items:
            pid = item['product_id']
            qty = validate_int(item['qty'], min_val=1, max_val=10**6)
            cur = conn.execute(
                "SELECT qty FROM stock WHERE unit_id=? AND product_id=?",
                (uid, pid)
            ).fetchone()
            if not cur or cur['qty'] < qty:
                prod = conn.execute("SELECT name FROM products WHERE id=?", (pid,)).fetchone()
                conn.rollback()
                conn.close()
                return err(f'Stok {prod["name"] if prod else pid} tidak cukup '
                           f'(sisa: {cur["qty"] if cur else 0}, diminta: {qty})')
            conn.execute(
                "UPDATE stock SET qty=qty-? WHERE unit_id=? AND product_id=?",
                (qty, uid, pid)
            )
            conn.execute(
                "INSERT INTO usage_log (unit_id, product_id, qty_used, date) VALUES (?,?,?,?)",
                (uid, pid, qty, date.today().isoformat())
            )
        conn.commit()
    except Exception as e:
        conn.rollback()
        conn.close()
        raise
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/usage')
@safe_db
def get_usage():
    unit_id = request.args.get('unit_id')
    conn = get_db()
    if unit_id:
        rows = conn.execute(
            "SELECT * FROM usage_log WHERE unit_id=? ORDER BY date DESC LIMIT 100",
            (unit_id,)
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM usage_log ORDER BY date DESC LIMIT 100").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


# ===================== WAREHOUSE STOCK =====================
@bp.route('/api/warehouse')
@safe_db
def get_warehouse():
    conn = get_db()
    rows = conn.execute("""
        SELECT ws.id, ws.product_id, ws.qty, p.name, p.category, p.type, p.uom
        FROM warehouse_stock ws JOIN products p ON ws.product_id = p.id
        ORDER BY p.name
    """).fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/warehouse/<wid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_warehouse(wid):
    data = get_json()
    qty = validate_int(data.get('qty', 0), min_val=0, max_val=10**7)
    conn = get_db()
    prev = conn.execute("SELECT qty, product_id FROM warehouse_stock WHERE id=?", (wid,)).fetchone()
    if not prev:
        conn.close(); return err('Warehouse entry tidak ditemukan', 404)
    conn.execute("UPDATE warehouse_stock SET qty=? WHERE id=?", (qty, wid))
    log_audit(conn, (current_user() or {}).get('display_name', ''),
              'ADJUST_WAREHOUSE', 'warehouse_stock', wid,
              f'qty {prev["qty"]}→{qty} product={prev["product_id"]}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
