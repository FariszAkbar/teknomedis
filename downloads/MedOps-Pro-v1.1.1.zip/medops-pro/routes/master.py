"""Master data routes: units, products, vendors, vendor_prices.

Write endpoints = admin-only (match session-2 auth policy). Read endpoints
tetap any-logged-in karena dipakai oleh unit UI untuk buat permintaan.
"""
import secrets
import string
from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash
from db_manager import get_db, log_audit
from helpers import gid, get_json, dict_rows, ok, err, safe_db, role_required, current_user, validate_int

bp = Blueprint('master', __name__)


def _gen_unit_password():
    """Random 8-char alphanumeric password untuk unit baru. Admin catat
    saat bikin, bisa diganti user setelah first login. Lebih aman daripada
    default '1234' (audit finding)."""
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(8))


# ===================== UNITS =====================
@bp.route('/api/units')
@safe_db
def get_units():
    conn = get_db()
    rows = conn.execute("SELECT * FROM units ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/units', methods=['POST'])
@safe_db
@role_required('admin')
def add_unit():
    data = get_json()
    name = (data.get('name') or '').strip()
    if not name or len(name) > 100:
        return err('Nama unit wajib diisi (max 100 karakter)')
    uid = gid()
    username = name.lower().replace(' ', '')
    # Generate strong random password, return it once to admin
    unit_password = _gen_unit_password()
    conn = get_db()
    # Check duplicate name or username
    if conn.execute("SELECT id FROM units WHERE name=?", (name,)).fetchone():
        conn.close()
        return err(f'Unit "{name}" sudah ada')
    if conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone():
        conn.close()
        return err(f'Username "{username}" sudah terpakai — pilih nama unit yang berbeda')
    conn.execute("INSERT INTO units (id, name) VALUES (?,?)", (uid, name))
    user_id = f'usr_{uid}'
    conn.execute(
        "INSERT INTO users (id, username, password_hash, role, unit_id, display_name) VALUES (?,?,?,?,?,?)",
        (user_id, username, generate_password_hash(unit_password), 'unit', uid, name)
    )
    actor = (current_user() or {}).get('display_name', 'admin')
    log_audit(conn, actor, 'ADD_UNIT', 'units', uid, f'Name: {name}, User: {username}')
    conn.commit()
    conn.close()
    return ok(id=uid, username=username, password=unit_password,
              message=f'Simpan password ini — tidak bisa diambil ulang: {unit_password}')


# ===================== PRODUCTS =====================
@bp.route('/api/products')
@safe_db
def get_products():
    conn = get_db()
    rows = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


def _validate_product(data):
    name = (data.get('name') or '').strip()
    if not name or len(name) > 200:
        return None, err('Nama produk wajib (max 200 karakter)')
    ptype = data.get('type', 'ATK')
    if ptype not in ('ATK', 'RTK'):
        return None, err('Jenis produk harus ATK atau RTK')
    category = (data.get('category') or 'Lainnya').strip()[:50]
    uom = (data.get('uom') or 'Pcs').strip()[:20]
    return {'name': name[:200], 'category': category, 'type': ptype, 'uom': uom}, None


@bp.route('/api/products', methods=['POST'])
@safe_db
@role_required('admin')
def add_product():
    data = get_json()
    clean, e = _validate_product(data)
    if e:
        return e
    pid = gid()
    conn = get_db()
    conn.execute(
        "INSERT INTO products (id, name, category, type, uom) VALUES (?,?,?,?,?)",
        (pid, clean['name'], clean['category'], clean['type'], clean['uom'])
    )
    log_audit(conn, (current_user() or {}).get('display_name',''), 'ADD_PRODUCT', 'products', pid, clean['name'])
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': pid})


@bp.route('/api/products/<pid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_product(pid):
    data = get_json()
    clean, e = _validate_product(data)
    if e:
        return e
    conn = get_db()
    conn.execute(
        "UPDATE products SET name=?, category=?, type=?, uom=? WHERE id=?",
        (clean['name'], clean['category'], clean['type'], clean['uom'], pid)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/products/<pid>', methods=['DELETE'])
@safe_db
@role_required('admin')
def delete_product(pid):
    conn = get_db()
    # Guard: produk yang dipakai di purchase_items / request_items / stock
    # tidak boleh dihapus — CASCADE di schema akan rusakin history.
    used_purch = conn.execute("SELECT COUNT(*) FROM purchase_items WHERE product_id=?", (pid,)).fetchone()[0]
    used_req = conn.execute("SELECT COUNT(*) FROM request_items WHERE product_id=?", (pid,)).fetchone()[0]
    used_stock = conn.execute("SELECT COUNT(*) FROM stock WHERE product_id=? AND qty>0", (pid,)).fetchone()[0]
    if used_purch or used_req or used_stock:
        conn.close()
        return err(
            f'Produk dipakai di {used_purch} pembelian, {used_req} permintaan, {used_stock} unit dengan stok. '
            f'Hapus/selesaikan dulu data terkait, atau rename produk untuk menonaktifkan.',
            409
        )
    conn.execute("DELETE FROM products WHERE id=?", (pid,))
    log_audit(conn, (current_user() or {}).get('display_name',''), 'DELETE_PRODUCT', 'products', pid, '')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== VENDORS =====================
@bp.route('/api/vendors')
@safe_db
def get_vendors():
    conn = get_db()
    rows = conn.execute("SELECT * FROM vendors ORDER BY name").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/vendors', methods=['POST'])
@safe_db
@role_required('admin')
def add_vendor():
    data = get_json()
    name = (data.get('name') or '').strip()
    if not name or len(name) > 150:
        return err('Nama vendor wajib (max 150 karakter)')
    vid = gid()
    conn = get_db()
    conn.execute(
        "INSERT INTO vendors (id, name, contact, address) VALUES (?,?,?,?)",
        (vid, name[:150], (data.get('contact') or '')[:100], (data.get('address') or '')[:300])
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': vid})


@bp.route('/api/vendors/<vid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_vendor(vid):
    data = get_json()
    name = (data.get('name') or '').strip()
    if not name or len(name) > 150:
        return err('Nama vendor wajib (max 150 karakter)')
    conn = get_db()
    conn.execute(
        "UPDATE vendors SET name=?, contact=?, address=? WHERE id=?",
        (name[:150], (data.get('contact') or '')[:100], (data.get('address') or '')[:300], vid)
    )
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/vendors/<vid>', methods=['DELETE'])
@safe_db
@role_required('admin')
def delete_vendor(vid):
    conn = get_db()
    # Vendor yang punya price entry atau history tidak boleh dihapus
    vp_count = conn.execute("SELECT COUNT(*) FROM vendor_prices WHERE vendor_id=?", (vid,)).fetchone()[0]
    purch_count = conn.execute("SELECT COUNT(*) FROM purchases WHERE vendor_id=?", (vid,)).fetchone()[0]
    if vp_count or purch_count:
        conn.close()
        return err(
            f'Vendor punya {vp_count} harga produk & {purch_count} riwayat pembelian. '
            f'Hapus dulu data terkait atau biarkan vendor tetap ada untuk arsip.',
            409
        )
    conn.execute("DELETE FROM vendors WHERE id=?", (vid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ===================== VENDOR PRICES =====================
@bp.route('/api/vendor-prices')
@safe_db
def get_vendor_prices():
    conn = get_db()
    rows = conn.execute("SELECT * FROM vendor_prices").fetchall()
    conn.close()
    return jsonify(dict_rows(rows))


@bp.route('/api/vendor-prices', methods=['POST'])
@safe_db
@role_required('admin')
def add_vendor_price():
    data = get_json()
    product_id = data.get('product_id')
    vendor_id = data.get('vendor_id')
    price = validate_int(data.get('price', 0), min_val=0, max_val=10**9)
    if not product_id or not vendor_id:
        return err('product_id & vendor_id wajib')
    vpid = gid()
    conn = get_db()
    # Validate FK existence — error lebih jelas daripada IntegrityError generic
    if not conn.execute("SELECT 1 FROM products WHERE id=?", (product_id,)).fetchone():
        conn.close(); return err('Produk tidak ditemukan', 404)
    if not conn.execute("SELECT 1 FROM vendors WHERE id=?", (vendor_id,)).fetchone():
        conn.close(); return err('Vendor tidak ditemukan', 404)
    has_default = conn.execute(
        "SELECT COUNT(*) FROM vendor_prices WHERE product_id=? AND is_default=1",
        (product_id,)
    ).fetchone()[0]
    is_def = 1 if has_default == 0 else (1 if data.get('is_default') else 0)
    if is_def:
        conn.execute("UPDATE vendor_prices SET is_default=0 WHERE product_id=?", (product_id,))
    try:
        conn.execute(
            "INSERT INTO vendor_prices (id, product_id, vendor_id, price, is_default) VALUES (?,?,?,?,?)",
            (vpid, product_id, vendor_id, price, is_def)
        )
    except Exception as e:
        conn.close()
        return err('Harga vendor sudah ada untuk produk ini', 409)
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': vpid})


@bp.route('/api/vendor-prices/<vpid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_vendor_price(vpid):
    data = get_json()
    price = validate_int(data.get('price', 0), min_val=0, max_val=10**9)
    conn = get_db()
    conn.execute("UPDATE vendor_prices SET price=? WHERE id=?", (price, vpid))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/vendor-prices/<vpid>/set-default', methods=['POST'])
@safe_db
@role_required('admin')
def set_default_price(vpid):
    conn = get_db()
    row = conn.execute("SELECT product_id FROM vendor_prices WHERE id=?", (vpid,)).fetchone()
    if row:
        conn.execute("UPDATE vendor_prices SET is_default=0 WHERE product_id=?", (row['product_id'],))
        conn.execute("UPDATE vendor_prices SET is_default=1 WHERE id=?", (vpid,))
        conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/vendor-prices/<vpid>', methods=['DELETE'])
@safe_db
@role_required('admin')
def delete_vendor_price(vpid):
    conn = get_db()
    conn.execute("DELETE FROM vendor_prices WHERE id=?", (vpid,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})
