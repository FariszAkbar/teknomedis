"""Planning routes: monthly plans, report, yearly forecast, realization, downloads."""
import io
import re
import json as json_mod
from flask import Blueprint, request, jsonify, send_file, current_app
from datetime import date, datetime
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from db_manager import get_db, log_audit
from helpers import (gid, now_ts, dict_rows, safe_db, get_clinic_name,
                     role_required, current_user, get_json, ok, err)

bp = Blueprint('planning', __name__)


# ===================== MONTHLY PLANS =====================
@bp.route('/api/plans')
@safe_db
def get_plans():
    month = request.args.get('month')
    conn = get_db()
    if month:
        rows = conn.execute("SELECT * FROM monthly_plans WHERE month=? ORDER BY created_date DESC", (month,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM monthly_plans ORDER BY month DESC, created_date DESC").fetchall()
    result = []
    for r in rows:
        rd = dict(r)
        items = conn.execute("""
            SELECT mpi.*, pr.name as product_name, pr.uom, pr.category, pr.type,
                   v.name as vendor_name
            FROM monthly_plan_items mpi
            JOIN products pr ON mpi.product_id = pr.id
            LEFT JOIN vendors v ON mpi.vendor_id = v.id
            WHERE mpi.plan_id=?
        """, (r['id'],)).fetchall()
        rd['items'] = [dict(i) for i in items]
        result.append(rd)
    conn.close()
    return jsonify(result)


@bp.route('/api/plans/generate', methods=['POST'])
@safe_db
@role_required('admin')
def generate_plan():
    """Generate a plan from forecasting data for a given month."""
    data = request.json
    target_month = data.get('month', '')
    if not target_month:
        return jsonify({'ok': False, 'error': 'Month required'}), 400

    conn = get_db()
    # Check if plan exists for this month
    existing = conn.execute("SELECT id FROM monthly_plans WHERE month=? AND status IN ('draft','submitted','approved')",
                            (target_month,)).fetchone()
    if existing:
        conn.close()
        return jsonify({'ok': False, 'error': f'Rencana untuk bulan {target_month} sudah ada'}), 400

    # Calculate forecast: avg of last 3 months usage + distribution
    year, mon = map(int, target_month.split('-'))
    plan_id = f"PLN-{target_month}"
    total = 0
    items_added = 0
    pending_items = []

    for prod in conn.execute("SELECT * FROM products ORDER BY name").fetchall():
        total_consumption = 0
        months_with_data = 0
        for offset in range(1, 4):  # last 3 months
            m = mon - offset
            y = year
            if m <= 0:
                m += 12
                y -= 1
            mkey = f'{y:04d}-{m:02d}'
            used = conn.execute(
                "SELECT COALESCE(SUM(qty_used),0) as qty FROM usage_log WHERE product_id=? AND date LIKE ?",
                (prod['id'], mkey+'%')
            ).fetchone()['qty']
            distributed = conn.execute(
                "SELECT COALESCE(SUM(ri.qty),0) as qty FROM request_items ri JOIN requests r ON ri.request_id=r.id WHERE ri.product_id=? AND r.date LIKE ? AND r.status='fulfilled'",
                (prod['id'], mkey+'%')
            ).fetchone()['qty']
            consumption = used + distributed
            if consumption > 0:
                months_with_data += 1
            total_consumption += consumption

        avg_usage = total_consumption / max(months_with_data, 1) if months_with_data > 0 else 0
        ws_row = conn.execute("SELECT qty FROM warehouse_stock WHERE product_id=?", (prod['id'],)).fetchone()
        current_stock = ws_row['qty'] if ws_row else 0
        recommended = max(0, round(avg_usage * 1.2) - current_stock)

        if recommended > 0 or avg_usage > 0:
            defvp = conn.execute(
                "SELECT vendor_id, price FROM vendor_prices WHERE product_id=? AND is_default=1",
                (prod['id'],)
            ).fetchone()
            price = defvp['price'] if defvp else 0
            vid = defvp['vendor_id'] if defvp else None
            sub = recommended * price
            total += sub
            pending_items.append((plan_id, prod['id'], recommended, price, vid))
            items_added += 1

    # Insert plan first (parent), then items (children)
    conn.execute(
        "INSERT INTO monthly_plans (id, month, status, admin_name, director_name, total_estimated, created_date, notes) VALUES (?,?,?,?,?,?,?,?)",
        (plan_id, target_month, 'draft', data.get('admin_name', ''), data.get('director_name', ''),
         total, date.today().isoformat(), 'Auto-generated dari forecasting')
    )
    for item in pending_items:
        conn.execute(
            "INSERT INTO monthly_plan_items (plan_id, product_id, estimated_qty, estimated_price, vendor_id) VALUES (?,?,?,?,?)",
            item
        )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': plan_id, 'items_count': items_added, 'total': total})


@bp.route('/api/plans/generate-from-rat', methods=['POST'])
@safe_db
@role_required('admin')
def generate_plan_from_rat():
    """Generate monthly_plan from approved RATs for the given month.

    Workflow:
      1. Parse target month (YYYY-MM)
      2. Find all approved RATs for that year
      3. Aggregate annual_projection_items WHERE month=mm across all RATs,
         summing qty per product_id (keeping the max unit_price seen —
         konservatif secara anggaran)
      4. Create draft monthly_plan (source='rat') with aggregated items
      5. Admin can then edit/submit as usual

    Body: { month: 'YYYY-MM' }
    """
    data = get_json()
    target_month = (data.get('month') or '').strip()
    if not target_month or len(target_month) != 7:
        return err('Parameter month (YYYY-MM) wajib')
    try:
        year, mon = map(int, target_month.split('-'))
    except ValueError:
        return err('Format month tidak valid, pakai YYYY-MM')

    conn = get_db()
    existing = conn.execute(
        "SELECT id FROM monthly_plans WHERE month=? AND status IN ('draft','submitted','approved')",
        (target_month,)
    ).fetchone()
    if existing:
        conn.close()
        return err(f'Rencana untuk bulan {target_month} sudah ada', 400)

    # Semua RAT approved untuk year ini
    rats = conn.execute(
        "SELECT id, unit_id FROM annual_projections WHERE year=? AND status='approved'",
        (year,)
    ).fetchall()
    if not rats:
        conn.close()
        return err(f'Belum ada RAT yang disetujui untuk tahun {year}. '
                   f'Admin atau unit harus buat RAT dulu dan di-approve direktur.', 400)

    rat_ids = [r['id'] for r in rats]
    placeholders = ','.join(['?'] * len(rat_ids))
    rows = conn.execute(f"""
        SELECT product_id,
               SUM(qty) AS total_qty,
               MAX(unit_price) AS unit_price,
               -- vendor paling sering dipakai di RATs (fallback NULL)
               (SELECT vendor_id FROM annual_projection_items ai2
                WHERE ai2.product_id = ai.product_id
                  AND ai2.month = ? AND ai2.projection_id IN ({placeholders})
                  AND ai2.vendor_id IS NOT NULL
                LIMIT 1) AS vendor_id
        FROM annual_projection_items ai
        WHERE month=? AND projection_id IN ({placeholders})
        GROUP BY product_id
        HAVING total_qty > 0
    """, [mon] + rat_ids + [mon] + rat_ids).fetchall()

    if not rows:
        conn.close()
        return err(f'Semua RAT approved untuk tahun {year} tidak memiliki proyeksi '
                   f'untuk bulan {mon}. Mungkin belum diisi — cek RAT tiap unit.', 400)

    plan_id = f"PLN-{target_month}"
    # Avoid collision: pakai suffix timestamp kalau id sudah ada (unlikely karena existing check di atas)
    if conn.execute("SELECT 1 FROM monthly_plans WHERE id=?", (plan_id,)).fetchone():
        plan_id = f"PLN-{target_month}-{datetime.now().strftime('%H%M%S')}"

    total = 0
    items = []
    for r in rows:
        sub = (r['total_qty'] or 0) * (r['unit_price'] or 0)
        total += sub
        items.append((plan_id, r['product_id'], r['total_qty'] or 0,
                      r['unit_price'] or 0, r['vendor_id']))

    admin_name = (current_user() or {}).get('display_name', '')
    note = (f'Auto-generated dari {len(rats)} RAT approved tahun {year} '
            f'(bulan ke-{mon}).')
    conn.execute("""
        INSERT INTO monthly_plans
            (id, month, status, admin_name, director_name, total_estimated,
             created_date, notes, created_by, source)
        VALUES (?, ?, 'draft', ?, '', ?, ?, ?, ?, 'rat')
    """, (plan_id, target_month, admin_name, total, date.today().isoformat(),
          note, admin_name))
    conn.executemany("""
        INSERT INTO monthly_plan_items
            (plan_id, product_id, estimated_qty, estimated_price, vendor_id)
        VALUES (?, ?, ?, ?, ?)
    """, items)
    log_audit(conn, admin_name, 'GENERATE_PLAN_FROM_RAT', 'monthly_plans', plan_id,
              f'month={target_month} rats={len(rats)} items={len(items)}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': plan_id,
                    'items_count': len(items), 'total': total,
                    'rats_used': len(rats), 'source': 'rat'})


@bp.route('/api/plans/rat-availability')
@safe_db
def rat_availability():
    """Check if there's an approved RAT for a given month.

    Query: ?month=YYYY-MM
    Response: { available, year, approved_rats, units }
    """
    target_month = request.args.get('month', '').strip()
    if not target_month or len(target_month) != 7:
        return err('month query param (YYYY-MM) wajib')
    try:
        year = int(target_month.split('-')[0])
    except ValueError:
        return err('Format month tidak valid')
    conn = get_db()
    rows = conn.execute("""
        SELECT ap.id, ap.unit_id, u.name AS unit_name
        FROM annual_projections ap
        LEFT JOIN units u ON u.id = ap.unit_id
        WHERE ap.year=? AND ap.status='approved'
        ORDER BY u.name
    """, (year,)).fetchall()
    conn.close()
    return jsonify({
        'ok': True,
        'available': len(rows) > 0,
        'year': year,
        'approved_rats': len(rows),
        'units': [r['unit_name'] for r in rows if r['unit_name']],
    })


@bp.route('/api/plans/<pid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_plan(pid):
    """Update a draft/rejected plan. Rejected plans are editable so admin
    bisa revise dan resubmit — match RAT pattern."""
    data = request.json
    conn = get_db()
    plan = conn.execute("SELECT status FROM monthly_plans WHERE id=?", (pid,)).fetchone()
    if not plan or plan['status'] not in ('draft', 'rejected'):
        conn.close()
        return jsonify({'ok': False, 'error': 'Hanya draft/rejected yang bisa diedit'}), 400

    total = 0
    for item in data.get('items', []):
        total += item['estimated_qty'] * item['estimated_price']

    conn.execute(
        "UPDATE monthly_plans SET notes=?, total_estimated=?, admin_name=?, director_name=? WHERE id=?",
        (data.get('notes', ''), total, data.get('admin_name', ''), data.get('director_name', ''), pid)
    )
    conn.execute("DELETE FROM monthly_plan_items WHERE plan_id=?", (pid,))
    for item in data.get('items', []):
        conn.execute(
            "INSERT INTO monthly_plan_items (plan_id, product_id, estimated_qty, estimated_price, vendor_id) VALUES (?,?,?,?,?)",
            (pid, item['product_id'], item['estimated_qty'], item['estimated_price'], item.get('vendor_id'))
        )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'total': total})


@bp.route('/api/plans/<pid>/submit', methods=['POST'])
@safe_db
@role_required('admin')
def submit_plan(pid):
    """Admin ajukan draft/rejected ke direktur. TTD digital pakai admin_name
    dari body (match purchases pattern)."""
    data = request.json or {}
    conn = get_db()
    plan = conn.execute("SELECT status FROM monthly_plans WHERE id=?", (pid,)).fetchone()
    if not plan or plan['status'] not in ('draft', 'rejected'):
        conn.close()
        return jsonify({'ok': False, 'error': 'Hanya draft/rejected yang bisa diajukan'}), 400

    admin_name = (data.get('admin_name')
                  or (current_user() or {}).get('display_name')
                  or '').strip()
    now = now_ts()
    # Reset rejection trail on resubmit so direktur sees fresh submission
    conn.execute("""
        UPDATE monthly_plans
        SET status='submitted', submitted_at=?, admin_name=?,
            rejected_by='', rejected_at='', reject_reason=''
        WHERE id=?
    """, (now, admin_name, pid))
    log_audit(conn, admin_name, 'PLAN_SUBMIT', 'monthly_plans', pid, '')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/plans/<pid>/approve', methods=['POST'])
@safe_db
@role_required('direktur')
def approve_plan(pid):
    data = request.json or {}
    director_name = (data.get('approved_by')
                     or data.get('director_name')
                     or (current_user() or {}).get('display_name')
                     or '').strip()
    conn = get_db()
    now = now_ts()
    conn.execute("""
        UPDATE monthly_plans
        SET status='approved', approved_by=?, approved_at=?, director_name=?
        WHERE id=? AND status='submitted'
    """, (director_name, now, director_name, pid))
    log_audit(conn, director_name, 'PLAN_APPROVE', 'monthly_plans', pid, '')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/plans/<pid>/reject', methods=['POST'])
@safe_db
@role_required('direktur')
def reject_plan(pid):
    data = request.json or {}
    reason = (data.get('reason') or '').strip()
    if not reason:
        return jsonify({'ok': False, 'error': 'Alasan penolakan wajib diisi'}), 400
    actor = (data.get('actor')
             or (current_user() or {}).get('display_name')
             or 'direktur').strip()
    conn = get_db()
    plan = conn.execute("SELECT status FROM monthly_plans WHERE id=?", (pid,)).fetchone()
    if not plan or plan['status'] != 'submitted':
        conn.close()
        return jsonify({'ok': False, 'error': 'Hanya pengajuan yang bisa ditolak'}), 400
    conn.execute("""
        UPDATE monthly_plans
        SET status='rejected', rejected_by=?, rejected_at=?, reject_reason=?
        WHERE id=?
    """, (actor, now_ts(), reason, pid))
    log_audit(conn, actor, 'PLAN_REJECT', 'monthly_plans', pid, reason)
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/plans/<pid>', methods=['DELETE'])
@safe_db
@role_required('admin')
def delete_plan(pid):
    conn = get_db()
    plan = conn.execute("SELECT status FROM monthly_plans WHERE id=?", (pid,)).fetchone()
    if plan and plan['status'] in ('draft', 'rejected'):
        conn.execute("DELETE FROM monthly_plans WHERE id=?", (pid,))
        conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/plans/<pid>/download')
@safe_db
def download_plan(pid):
    """Download monthly plan as Excel document with signatures."""
    conn = get_db()
    plan = conn.execute("SELECT * FROM monthly_plans WHERE id=?", (pid,)).fetchone()
    if not plan:
        conn.close()
        return jsonify({'ok': False}), 404

    items = conn.execute("""
        SELECT mpi.*, pr.name as product_name, pr.uom, pr.category, pr.type,
               v.name as vendor_name
        FROM monthly_plan_items mpi
        JOIN products pr ON mpi.product_id = pr.id
        LEFT JOIN vendors v ON mpi.vendor_id = v.id
        WHERE mpi.plan_id=? ORDER BY pr.name
    """, (pid,)).fetchall()

    # Get current warehouse stock for each item
    ws_data = {}
    for it in items:
        ws = conn.execute("SELECT qty FROM warehouse_stock WHERE product_id=?", (it['product_id'],)).fetchone()
        ws_data[it['product_id']] = ws['qty'] if ws else 0
    conn.close()

    wb = Workbook()
    ws = wb.active
    ws.title = 'Rencana Bulanan'
    bold = Font(bold=True)
    center = Alignment(horizontal='center', vertical='center')
    border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    hfill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')

    ws.merge_cells('A1:H1')
    ws['A1'] = get_clinic_name()
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = center
    ws.merge_cells('A2:H2')
    ws['A2'] = f'RENCANA PEMBELIAN ATK & RTK — {plan["month"]}'
    ws['A2'].font = Font(bold=True, size=11)
    ws['A2'].alignment = center
    ws.merge_cells('A3:H3')
    status_label = {'draft':'DRAFT','submitted':'DIAJUKAN','approved':'DISETUJUI'}.get(plan['status'],'')
    ws['A3'] = f'Status: {status_label}'
    ws['A3'].alignment = center

    ws['A5'] = 'Tanggal dibuat:'
    ws['B5'] = plan['created_date']
    ws['A5'].font = bold
    ws['D5'] = 'Periode:'
    ws['E5'] = plan['month']
    ws['D5'].font = bold
    if plan['notes']:
        ws['A6'] = 'Catatan:'
        ws['B6'] = plan['notes']
        ws['A6'].font = bold

    headers = ['No', 'Nama Produk', 'Kategori', 'Vendor', 'Stok Gudang', 'Rencana Beli', 'Harga Satuan', 'Est. Total']
    widths = [5, 30, 16, 22, 14, 13, 16, 18]
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        ws.column_dimensions[chr(64+i)].width = w
        cell = ws.cell(row=8, column=i, value=h)
        cell.font = bold
        cell.alignment = center
        cell.border = border
        cell.fill = hfill

    grand = 0
    for idx, it in enumerate(items, 1):
        row = 8 + idx
        sub = it['estimated_qty'] * it['estimated_price']
        grand += sub
        vals = [idx, it['product_name'], it['category'], it['vendor_name'] or '-',
                ws_data.get(it['product_id'], 0), it['estimated_qty'], it['estimated_price'], sub]
        for col, v in enumerate(vals, 1):
            cell = ws.cell(row=row, column=col, value=v)
            cell.border = border
            if col in (5, 6, 7, 8):
                cell.number_format = '#,##0'

    tr = 9 + len(items)
    ws.merge_cells(f'A{tr}:F{tr}')
    ws.cell(row=tr, column=1, value='TOTAL ESTIMASI ANGGARAN').font = Font(bold=True, size=12)
    ws.cell(row=tr, column=1).alignment = Alignment(horizontal='right')
    for c in range(1, 8):
        ws.cell(row=tr, column=c).border = border
    ws.cell(row=tr, column=8, value=grand).font = Font(bold=True, size=12)
    ws.cell(row=tr, column=8).number_format = '#,##0'
    ws.cell(row=tr, column=8).border = border

    # Signatures
    sr = tr + 3
    ws.merge_cells(f'B{sr}:C{sr}')
    ws.cell(row=sr, column=2, value='Mengetahui,').font = bold
    ws.cell(row=sr, column=2).alignment = center
    ws.merge_cells(f'F{sr}:H{sr}')
    ws.cell(row=sr, column=6, value='Menyetujui,').font = bold
    ws.cell(row=sr, column=6).alignment = center
    ws.merge_cells(f'B{sr+1}:C{sr+1}')
    ws.cell(row=sr+1, column=2, value='Admin Pengadaan').alignment = center
    ws.merge_cells(f'F{sr+1}:H{sr+1}')
    ws.cell(row=sr+1, column=6, value='Direktur Klinik').alignment = center
    ws.merge_cells(f'B{sr+5}:C{sr+5}')
    an = plan['admin_name'] or '____________________'
    ws.cell(row=sr+5, column=2, value=an).alignment = center
    ws.cell(row=sr+5, column=2).font = Font(bold=True, underline='single')
    ws.merge_cells(f'F{sr+5}:H{sr+5}')
    dn = plan['director_name'] or '____________________'
    ws.cell(row=sr+5, column=6, value=dn).alignment = center
    ws.cell(row=sr+5, column=6).font = Font(bold=True, underline='single')

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, download_name=f'Rencana_{plan["month"]}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ===================== REPORT =====================
@bp.route('/api/report/monthly')
@safe_db
def monthly_report():
    """Monthly report: purchase history, distribution, forecasting."""
    month = request.args.get('month')  # format: YYYY-MM
    if not month:
        month = date.today().strftime('%Y-%m')

    conn = get_db()

    # Purchase summary for the month
    purchases_data = conn.execute("""
        SELECT p.id, p.date, p.total, p.status, v.name as vendor_name
        FROM purchases p LEFT JOIN vendors v ON p.vendor_id = v.id
        WHERE p.date LIKE ? AND p.status='ordered'
        ORDER BY p.date
    """, (month + '%',)).fetchall()
    total_spent = sum(r['total'] for r in purchases_data)

    # Items purchased this month (aggregated)
    items_purchased = conn.execute("""
        SELECT pr.id, pr.name, pr.uom, pr.type,
               SUM(pi.qty) as total_qty, SUM(pi.qty * pi.price) as total_cost
        FROM purchase_items pi
        JOIN products pr ON pi.product_id = pr.id
        JOIN purchases p ON pi.purchase_id = p.id
        WHERE p.date LIKE ? AND p.status='ordered'
        GROUP BY pr.id, pr.name, pr.uom, pr.type
        ORDER BY total_cost DESC
    """, (month + '%',)).fetchall()

    # Distribution to units this month
    distributions = conn.execute("""
        SELECT u.name as unit_name, pr.name as product_name, pr.uom,
               ri.qty, r.date
        FROM requests r
        JOIN request_items ri ON ri.request_id = r.id
        JOIN products pr ON ri.product_id = pr.id
        JOIN units u ON r.unit_id = u.id
        WHERE r.date LIKE ? AND r.status='fulfilled'
        ORDER BY r.date DESC
    """, (month + '%',)).fetchall()

    # Distribution aggregated per unit + estimated biaya distribusi
    # (qty × default vendor_price per produk — proxy nilai inventory yang keluar)
    dist_per_unit = conn.execute("""
        SELECT u.id, u.name as unit_name, COUNT(DISTINCT r.id) as request_count,
               SUM(ri.qty) as total_items,
               COALESCE(SUM(ri.qty *
                 COALESCE((SELECT price FROM vendor_prices vp
                           WHERE vp.product_id=ri.product_id
                           ORDER BY is_default DESC LIMIT 1), 0)), 0) AS total_cost
        FROM requests r
        JOIN request_items ri ON ri.request_id = r.id
        JOIN units u ON r.unit_id = u.id
        WHERE r.date LIKE ? AND r.status='fulfilled'
          AND COALESCE(ri.status,'active')='active'
        GROUP BY u.id, u.name
        ORDER BY total_cost DESC
    """, (month + '%',)).fetchall()

    # Usage per product this month (for forecasting)
    usage_data = conn.execute("""
        SELECT pr.id, pr.name, pr.uom, pr.type,
               SUM(ul.qty_used) as total_used
        FROM usage_log ul
        JOIN products pr ON ul.product_id = pr.id
        WHERE ul.date LIKE ?
        GROUP BY pr.id, pr.name, pr.uom, pr.type
        ORDER BY total_used DESC
    """, (month + '%',)).fetchall()

    # Last 3 months purchase data for forecasting
    year, mon = map(int, month.split('-'))
    forecast = []
    for prod in conn.execute("SELECT * FROM products ORDER BY name").fetchall():
        months_data = []
        for offset in range(3):
            m = mon - offset
            y = year
            if m <= 0:
                m += 12
                y -= 1
            mkey = f'{y:04d}-{m:02d}'
            bought = conn.execute("""
                SELECT COALESCE(SUM(pi.qty),0) as qty
                FROM purchase_items pi JOIN purchases p ON pi.purchase_id=p.id
                WHERE pi.product_id=? AND p.date LIKE ? AND p.status='ordered'
            """, (prod['id'], mkey+'%')).fetchone()['qty']
            used = conn.execute("""
                SELECT COALESCE(SUM(qty_used),0) as qty
                FROM usage_log WHERE product_id=? AND date LIKE ?
            """, (prod['id'], mkey+'%')).fetchone()['qty']
            distributed = conn.execute("""
                SELECT COALESCE(SUM(ri.qty),0) as qty
                FROM request_items ri JOIN requests r ON ri.request_id=r.id
                WHERE ri.product_id=? AND r.date LIKE ? AND r.status='fulfilled'
            """, (prod['id'], mkey+'%')).fetchone()['qty']
            months_data.append({'month': mkey, 'bought': bought, 'used': used, 'distributed': distributed})

        avg_usage = sum(m['used'] + m['distributed'] for m in months_data) / max(len(months_data), 1)
        ws_row = conn.execute("SELECT qty FROM warehouse_stock WHERE product_id=?",
                              (prod['id'],)).fetchone()
        current_stock = ws_row['qty'] if ws_row else 0
        forecast.append({
            'product_id': prod['id'], 'name': prod['name'], 'uom': prod['uom'], 'type': prod['type'],
            'current_stock': current_stock,
            'avg_monthly_usage': round(avg_usage),
            'recommended_buy': max(0, round(avg_usage * 1.2) - current_stock),
            'months_data': months_data,
        })

    conn.close()
    return jsonify({
        'month': month,
        'total_spent': total_spent,
        'purchase_count': len(purchases_data),
        'purchases': dict_rows(purchases_data),
        'items_purchased': dict_rows(items_purchased),
        'distributions': dict_rows(distributions),
        'dist_per_unit': dict_rows(dist_per_unit),
        'usage': dict_rows(usage_data),
        'forecast': forecast,
    })


# ===================== YEARLY FORECAST (RAT) =====================
@bp.route('/api/report/yearly')
@safe_db
def yearly_forecast():
    """Rencana Anggaran Tahunan — 12 month projection based on historical data."""
    target_year = request.args.get('year')
    if not target_year:
        target_year = str(date.today().year + 1)
    target_year = int(target_year)

    conn = get_db()
    products_list = conn.execute("SELECT * FROM products ORDER BY name").fetchall()
    units_list = conn.execute("SELECT * FROM units ORDER BY name").fetchall()

    # Calculate average monthly consumption from last 6 months of data
    now = datetime.now()
    monthly_data = {}  # {product_id: {month_key: {bought, used, distributed}}}

    for prod in products_list:
        pid = prod['id']
        monthly_data[pid] = {}
        for offset in range(1, 7):  # last 6 months
            m = now.month - offset
            y = now.year
            while m <= 0:
                m += 12
                y -= 1
            mkey = f'{y:04d}-{m:02d}'

            used = conn.execute(
                "SELECT COALESCE(SUM(qty_used),0) as qty FROM usage_log WHERE product_id=? AND date LIKE ?",
                (pid, mkey + '%')
            ).fetchone()['qty']

            distributed = conn.execute(
                "SELECT COALESCE(SUM(ri.qty),0) as qty FROM request_items ri JOIN requests r ON ri.request_id=r.id WHERE ri.product_id=? AND r.date LIKE ? AND r.status='fulfilled'",
                (pid, mkey + '%')
            ).fetchone()['qty']

            bought = conn.execute(
                "SELECT COALESCE(SUM(pi.qty),0) as qty FROM purchase_items pi JOIN purchases p ON pi.purchase_id=p.id WHERE pi.product_id=? AND p.date LIKE ? AND p.status='ordered'",
                (pid, mkey + '%')
            ).fetchone()['qty']

            monthly_data[pid][mkey] = {'used': used, 'distributed': distributed, 'bought': bought}

    # Build projections
    projections = []  # per product, 12 months
    category_totals = {}  # {category: total_cost}
    type_totals = {'ATK': {'cost': 0, 'qty': 0}, 'RTK': {'cost': 0, 'qty': 0}}
    unit_consumption = {}  # {unit_id: {product_id: avg_qty}}
    grand_total = 0

    # Calculate per-unit consumption averages
    for unit in units_list:
        unit_consumption[unit['id']] = {}
        for prod in products_list:
            total_dist = 0
            months_with_data = 0
            for offset in range(1, 7):
                m = now.month - offset
                y = now.year
                while m <= 0:
                    m += 12
                    y -= 1
                mkey = f'{y:04d}-{m:02d}'
                qty = conn.execute(
                    "SELECT COALESCE(SUM(ri.qty),0) as qty FROM request_items ri JOIN requests r ON ri.request_id=r.id WHERE ri.product_id=? AND r.unit_id=? AND r.date LIKE ? AND r.status='fulfilled'",
                    (prod['id'], unit['id'], mkey + '%')
                ).fetchone()['qty']
                if qty > 0:
                    months_with_data += 1
                total_dist += qty
            avg = total_dist / max(months_with_data, 1) if months_with_data > 0 else 0
            if avg > 0:
                unit_consumption[unit['id']][prod['id']] = round(avg, 1)

    for prod in products_list:
        pid = prod['id']
        # Calculate average consumption
        total_consumption = 0
        months_with_data = 0
        for mdata in monthly_data[pid].values():
            consumption = mdata['used'] + mdata['distributed']
            if consumption > 0:
                months_with_data += 1
            total_consumption += consumption

        avg_monthly = total_consumption / max(months_with_data, 1) if months_with_data > 0 else 0

        # Get default price
        defvp = conn.execute(
            "SELECT price FROM vendor_prices WHERE product_id=? AND is_default=1", (pid,)
        ).fetchone()
        price = defvp['price'] if defvp else 0

        # Current warehouse stock
        ws = conn.execute("SELECT qty FROM warehouse_stock WHERE product_id=?", (pid,)).fetchone()
        current_stock = ws['qty'] if ws else 0

        # Project 12 months with growth factor 1.1 (10% growth buffer)
        months = []
        remaining_stock = current_stock
        for m in range(1, 13):
            # Apply slight growth: base * (1 + 0.01 * month_index) for gradual increase
            projected_qty = round(avg_monthly * (1 + 0.005 * m))
            need_to_buy = max(0, projected_qty - max(0, remaining_stock))
            remaining_stock = max(0, remaining_stock - projected_qty)
            cost = need_to_buy * price
            months.append({
                'month': m,
                'month_label': f'{target_year}-{m:02d}',
                'projected_usage': projected_qty,
                'need_to_buy': need_to_buy,
                'cost': cost,
            })

        total_cost = sum(m['cost'] for m in months)
        total_qty = sum(m['need_to_buy'] for m in months)
        grand_total += total_cost

        # Category totals (cost + qty)
        cat = prod['category']
        if cat not in category_totals:
            category_totals[cat] = {'cost': 0, 'qty': 0}
        category_totals[cat]['cost'] += total_cost
        category_totals[cat]['qty'] += total_qty
        if prod['type'] not in type_totals:
            type_totals[prod['type']] = {'cost': 0, 'qty': 0}
        type_totals[prod['type']]['cost'] += total_cost
        type_totals[prod['type']]['qty'] += total_qty

        if avg_monthly > 0 or total_qty > 0:
            projections.append({
                'product_id': pid,
                'name': prod['name'],
                'category': prod['category'],
                'type': prod['type'],
                'uom': prod['uom'],
                'avg_monthly': round(avg_monthly, 1),
                'price': price,
                'current_stock': current_stock,
                'total_qty': total_qty,
                'total_cost': total_cost,
                'months': months,
            })

    # Unit summary
    unit_summary = []
    for unit in units_list:
        uc = unit_consumption.get(unit['id'], {})
        if uc:
            total_unit_cost = 0
            total_unit_qty = 0
            prod_detail = []
            for pid, avg in uc.items():
                pr = conn.execute("SELECT name, uom, category, type FROM products WHERE id=?", (pid,)).fetchone()
                defvp = conn.execute("SELECT price FROM vendor_prices WHERE product_id=? AND is_default=1", (pid,)).fetchone()
                p = defvp['price'] if defvp else 0
                # Monthly projection with growth
                months = []
                for m in range(1, 13):
                    mq = round(avg * (1 + 0.005 * m))
                    mc = mq * p
                    months.append({'qty': mq, 'cost': mc})
                yearly = sum(mo['qty'] for mo in months)
                cost = sum(mo['cost'] for mo in months)
                total_unit_cost += cost
                total_unit_qty += yearly
                prod_detail.append({
                    'name': pr['name'], 'uom': pr['uom'], 'category': pr['category'], 'type': pr['type'],
                    'price': p, 'avg_monthly': round(avg, 1), 'yearly_qty': yearly, 'cost': cost, 'months': months
                })
            unit_summary.append({
                'unit_id': unit['id'],
                'unit_name': unit['name'],
                'total_cost': total_unit_cost,
                'total_qty': total_unit_qty,
                'products': prod_detail,
            })

    conn.close()
    return jsonify({
        'year': target_year,
        'grand_total': grand_total,
        'projections': projections,
        'category_totals': category_totals,
        'type_totals': type_totals,
        'unit_summary': unit_summary,
    })


@bp.route('/api/report/yearly/download')
@safe_db
def download_yearly_forecast():
    """Download RAT as Excel with full breakdown."""
    target_year = request.args.get('year', str(date.today().year + 1))
    admin_name = request.args.get('admin', '')
    director_name = request.args.get('director', '')

    # Get data from the yearly forecast endpoint internally
    with current_app.test_request_context(f'/api/report/yearly?year={target_year}'):
        resp = yearly_forecast()
        data = json_mod.loads(resp.get_data())

    wb = Workbook()

    bold = Font(bold=True)
    center = Alignment(horizontal='center', vertical='center')
    border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    hfill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
    catfill = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')

    # ---- SHEET 1: Summary ----
    ws = wb.active
    ws.title = 'Ringkasan'

    ws.merge_cells('A1:F1')
    ws['A1'] = 'RENCANA ANGGARAN TAHUNAN (RAT)'
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = center
    ws.merge_cells('A2:F2')
    ws['A2'] = f'PENGADAAN ATK & RTK — TAHUN {target_year}'
    ws['A2'].font = Font(bold=True, size=11)
    ws['A2'].alignment = center

    # Type summary
    ws['A4'] = 'Ringkasan per Jenis'
    ws['A4'].font = bold
    ws.cell(row=4, column=2, value='Qty').font = bold
    ws.cell(row=4, column=3, value='Biaya').font = bold
    ws['A5'] = 'ATK'
    atk = data['type_totals'].get('ATK', {})
    ws['B5'] = atk.get('qty', 0) if isinstance(atk, dict) else 0
    ws['C5'] = atk.get('cost', 0) if isinstance(atk, dict) else atk
    ws['C5'].number_format = '#,##0'
    ws['A6'] = 'RTK'
    rtk = data['type_totals'].get('RTK', {})
    ws['B6'] = rtk.get('qty', 0) if isinstance(rtk, dict) else 0
    ws['C6'] = rtk.get('cost', 0) if isinstance(rtk, dict) else rtk
    ws['C6'].number_format = '#,##0'
    ws['A7'] = 'TOTAL'
    ws['A7'].font = bold
    ws['B7'] = data['grand_total']
    ws['B7'].font = Font(bold=True, size=12)
    ws['B7'].number_format = '#,##0'

    # Category summary
    ws['A9'] = 'Ringkasan per Kategori'
    ws['A9'].font = bold
    ws.cell(row=9, column=2, value='Qty').font = bold
    ws.cell(row=9, column=3, value='Biaya').font = bold
    row = 10
    for cat, v in sorted(data['category_totals'].items()):
        ws.cell(row=row, column=1, value=cat)
        ws.cell(row=row, column=2, value=v.get('qty', 0) if isinstance(v, dict) else 0)
        c = ws.cell(row=row, column=3, value=v.get('cost', 0) if isinstance(v, dict) else v)
        c.number_format = '#,##0'
        row += 1

    # Unit summary
    row += 1
    ws.cell(row=row, column=1, value='Ringkasan per Unit').font = bold
    ws.cell(row=row, column=2, value='Qty').font = bold
    ws.cell(row=row, column=3, value='Biaya').font = bold
    row += 1
    for us in data.get('unit_summary', []):
        ws.cell(row=row, column=1, value=us['unit_name'])
        ws.cell(row=row, column=2, value=us.get('total_qty', 0))
        c = ws.cell(row=row, column=3, value=us['total_cost'])
        c.number_format = '#,##0'
        row += 1

    summary_last_row = row

    ws.column_dimensions['A'].width = 25
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 18

    # ---- SHEET 2: Detail per Produk ----
    ws2 = wb.create_sheet('Detail Produk')
    month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des']

    # Row 1: merged headers
    fixed_cols = ['No', 'Produk', 'Kategori', 'Jenis', 'Satuan', 'Harga']
    for i, h in enumerate(fixed_cols, 1):
        c = ws2.cell(row=1, column=i, value=h)
        c.font = bold; c.border = border; c.fill = hfill; c.alignment = center
        ws2.merge_cells(start_row=1, start_column=i, end_row=2, end_column=i)

    # Month headers (merged 2 cols each)
    col = 7
    for mi, mn in enumerate(month_names):
        ws2.merge_cells(start_row=1, start_column=col, end_row=1, end_column=col+1)
        c = ws2.cell(row=1, column=col, value=mn)
        c.font = bold; c.border = border; c.fill = hfill; c.alignment = center
        # Sub headers
        c1 = ws2.cell(row=2, column=col, value='Qty')
        c1.font = Font(bold=True, size=9); c1.border = border; c1.fill = hfill; c1.alignment = center
        c2 = ws2.cell(row=2, column=col+1, value='Biaya')
        c2.font = Font(bold=True, size=9); c2.border = border; c2.fill = hfill; c2.alignment = center
        col += 2

    # Total columns
    ws2.merge_cells(start_row=1, start_column=col, end_row=1, end_column=col+1)
    c = ws2.cell(row=1, column=col, value='TOTAL')
    c.font = Font(bold=True, size=11); c.border = border; c.fill = PatternFill(start_color='B4C6E7', end_color='B4C6E7', fill_type='solid'); c.alignment = center
    ws2.cell(row=2, column=col, value='Qty').font = Font(bold=True, size=9)
    ws2.cell(row=2, column=col, value='Qty').border = border
    ws2.cell(row=2, column=col+1, value='Biaya').font = Font(bold=True, size=9)
    ws2.cell(row=2, column=col+1, value='Biaya').border = border

    ws2.column_dimensions['A'].width = 4
    ws2.column_dimensions['B'].width = 25
    ws2.column_dimensions['C'].width = 14
    ws2.column_dimensions['D'].width = 6
    ws2.column_dimensions['E'].width = 7
    ws2.column_dimensions['F'].width = 12

    # Data rows
    for idx, p in enumerate(data['projections'], 1):
        row = idx + 2
        ws2.cell(row=row, column=1, value=idx).border = border
        ws2.cell(row=row, column=2, value=p['name']).border = border
        ws2.cell(row=row, column=2).font = Font(bold=True)
        ws2.cell(row=row, column=3, value=p['category']).border = border
        ws2.cell(row=row, column=4, value=p['type']).border = border
        ws2.cell(row=row, column=5, value=p['uom']).border = border
        c = ws2.cell(row=row, column=6, value=p['price'])
        c.border = border; c.number_format = '#,##0'

        col = 7
        for m in p['months']:
            c1 = ws2.cell(row=row, column=col, value=m['need_to_buy'] if m['need_to_buy'] > 0 else None)
            c1.border = border; c1.alignment = center
            c2 = ws2.cell(row=row, column=col+1, value=m['cost'] if m['cost'] > 0 else None)
            c2.border = border; c2.number_format = '#,##0'; c2.alignment = Alignment(horizontal='right')
            col += 2

        # Total columns
        c = ws2.cell(row=row, column=col, value=p['total_qty'])
        c.border = border; c.font = Font(bold=True); c.alignment = center
        c = ws2.cell(row=row, column=col+1, value=p['total_cost'])
        c.border = border; c.font = Font(bold=True); c.number_format = '#,##0'; c.alignment = Alignment(horizontal='right')

    # Total footer row
    tr = len(data['projections']) + 3
    ws2.merge_cells(start_row=tr, start_column=1, end_row=tr, end_column=6)
    c = ws2.cell(row=tr, column=1, value='TOTAL')
    c.font = Font(bold=True, size=11); c.border = border; c.alignment = Alignment(horizontal='right')
    for cc in range(2, 7):
        ws2.cell(row=tr, column=cc).border = border

    col = 7
    for mi in range(12):
        mQty = sum(p['months'][mi]['need_to_buy'] for p in data['projections'])
        mCost = sum(p['months'][mi]['cost'] for p in data['projections'])
        c1 = ws2.cell(row=tr, column=col, value=mQty if mQty > 0 else None)
        c1.border = border; c1.font = Font(bold=True); c1.alignment = center
        c2 = ws2.cell(row=tr, column=col+1, value=mCost if mCost > 0 else None)
        c2.border = border; c2.font = Font(bold=True); c2.number_format = '#,##0'; c2.alignment = Alignment(horizontal='right')
        col += 2

    totalQty = sum(p['total_qty'] for p in data['projections'])
    c = ws2.cell(row=tr, column=col, value=totalQty)
    c.border = border; c.font = Font(bold=True, size=12); c.alignment = center
    c = ws2.cell(row=tr, column=col+1, value=data['grand_total'])
    c.border = border; c.font = Font(bold=True, size=12); c.number_format = '#,##0'; c.alignment = Alignment(horizontal='right')

    # ---- SHEET 3: Per Unit (with monthly breakdown) ----
    month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des']
    unitfill = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')

    for us in data['unit_summary']:
        ws3 = wb.create_sheet(us['unit_name'][:20])

        # Title
        ws3.merge_cells('A1:F1')
        ws3['A1'] = f'KEBUTUHAN {us["unit_name"].upper()} — TAHUN {target_year}'
        ws3['A1'].font = Font(bold=True, size=12)
        ws3['A1'].alignment = center

        ws3['A2'] = f'Total: {us["total_qty"]} item'
        ws3['A2'].font = bold
        c = ws3.cell(row=2, column=4, value=us['total_cost'])
        c.font = Font(bold=True, size=12)
        c.number_format = '#,##0'

        # Headers row 1: fixed + months merged
        fixed = ['No', 'Produk', 'Satuan', 'Harga']
        for i, h in enumerate(fixed, 1):
            c = ws3.cell(row=4, column=i, value=h)
            c.font = bold; c.border = border; c.fill = hfill; c.alignment = center
            ws3.merge_cells(start_row=4, start_column=i, end_row=5, end_column=i)

        col = 5
        for mn in month_names:
            ws3.merge_cells(start_row=4, start_column=col, end_row=4, end_column=col+1)
            c = ws3.cell(row=4, column=col, value=mn)
            c.font = bold; c.border = border; c.fill = hfill; c.alignment = center
            c1 = ws3.cell(row=5, column=col, value='Qty')
            c1.font = Font(bold=True, size=9); c1.border = border; c1.fill = hfill; c1.alignment = center
            c2 = ws3.cell(row=5, column=col+1, value='Biaya')
            c2.font = Font(bold=True, size=9); c2.border = border; c2.fill = hfill; c2.alignment = center
            col += 2

        # Total header
        ws3.merge_cells(start_row=4, start_column=col, end_row=4, end_column=col+1)
        c = ws3.cell(row=4, column=col, value='TOTAL')
        c.font = Font(bold=True); c.border = border; c.fill = PatternFill(start_color='B4C6E7', end_color='B4C6E7', fill_type='solid'); c.alignment = center
        ws3.cell(row=5, column=col, value='Qty').font = Font(bold=True, size=9)
        ws3.cell(row=5, column=col).border = border
        ws3.cell(row=5, column=col+1, value='Biaya').font = Font(bold=True, size=9)
        ws3.cell(row=5, column=col+1).border = border

        ws3.column_dimensions['A'].width = 4
        ws3.column_dimensions['B'].width = 25
        ws3.column_dimensions['C'].width = 7
        ws3.column_dimensions['D'].width = 12

        # Data rows
        for idx, pd in enumerate(us['products'], 1):
            row = idx + 5
            ws3.cell(row=row, column=1, value=idx).border = border
            ws3.cell(row=row, column=2, value=pd['name']).border = border
            ws3.cell(row=row, column=2).font = Font(bold=True)
            ws3.cell(row=row, column=3, value=pd['uom']).border = border
            c = ws3.cell(row=row, column=4, value=pd.get('price', 0))
            c.border = border; c.number_format = '#,##0'

            col = 5
            for mo in pd.get('months', []):
                c1 = ws3.cell(row=row, column=col, value=mo['qty'] if mo['qty'] > 0 else None)
                c1.border = border; c1.alignment = center
                c2 = ws3.cell(row=row, column=col+1, value=mo['cost'] if mo['cost'] > 0 else None)
                c2.border = border; c2.number_format = '#,##0'; c2.alignment = Alignment(horizontal='right')
                col += 2

            c = ws3.cell(row=row, column=col, value=pd['yearly_qty'])
            c.border = border; c.font = Font(bold=True); c.alignment = center
            c = ws3.cell(row=row, column=col+1, value=pd['cost'])
            c.border = border; c.font = Font(bold=True); c.number_format = '#,##0'

        # Footer
        tr = len(us['products']) + 6
        ws3.merge_cells(start_row=tr, start_column=1, end_row=tr, end_column=4)
        ws3.cell(row=tr, column=1, value='TOTAL').font = Font(bold=True, size=11)
        ws3.cell(row=tr, column=1).border = border; ws3.cell(row=tr, column=1).alignment = Alignment(horizontal='right')
        for cc in range(2, 5):
            ws3.cell(row=tr, column=cc).border = border

        col = 5
        for mi in range(12):
            mq = sum(pd['months'][mi]['qty'] for pd in us['products'] if pd.get('months'))
            mc = sum(pd['months'][mi]['cost'] for pd in us['products'] if pd.get('months'))
            c1 = ws3.cell(row=tr, column=col, value=mq if mq > 0 else None)
            c1.border = border; c1.font = Font(bold=True); c1.alignment = center
            c2 = ws3.cell(row=tr, column=col+1, value=mc if mc > 0 else None)
            c2.border = border; c2.font = Font(bold=True); c2.number_format = '#,##0'
            col += 2

        c = ws3.cell(row=tr, column=col, value=us['total_qty'])
        c.border = border; c.font = Font(bold=True, size=12); c.alignment = center
        c = ws3.cell(row=tr, column=col+1, value=us['total_cost'])
        c.border = border; c.font = Font(bold=True, size=12); c.number_format = '#,##0'

    # ---- Signatures (on summary sheet) ----
    sr = summary_last_row + 2
    ws.merge_cells(f'A{sr}:B{sr}')
    ws.cell(row=sr, column=1, value='Mengetahui,').font = bold
    ws.cell(row=sr, column=1).alignment = center
    ws.merge_cells(f'D{sr}:F{sr}')
    ws.cell(row=sr, column=4, value='Menyetujui,').font = bold
    ws.cell(row=sr, column=4).alignment = center
    ws.merge_cells(f'A{sr+1}:B{sr+1}')
    ws.cell(row=sr+1, column=1, value='Admin Pengadaan').alignment = center
    ws.merge_cells(f'D{sr+1}:F{sr+1}')
    ws.cell(row=sr+1, column=4, value='Direktur').alignment = center
    ws.merge_cells(f'A{sr+5}:B{sr+5}')
    an = admin_name or '____________________'
    ws.cell(row=sr+5, column=1, value=an).alignment = center
    ws.cell(row=sr+5, column=1).font = Font(bold=True, underline='single')
    ws.merge_cells(f'D{sr+5}:F{sr+5}')
    dn = director_name or '____________________'
    ws.cell(row=sr+5, column=4, value=dn).alignment = center
    ws.cell(row=sr+5, column=4).font = Font(bold=True, underline='single')

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, download_name=f'RAT_{target_year}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ===================== REALIZATION =====================
@bp.route('/api/realization')
@safe_db
def get_realization():
    """Plan vs Actual for a given month — with RAT projection, trend, distribution."""
    month = request.args.get('month')
    if not month:
        month = date.today().strftime('%Y-%m')

    year, mon = map(int, month.split('-'))
    conn = get_db()

    # ---- 1. Monthly Plan (approved > submitted > draft) ----
    plan = conn.execute(
        "SELECT * FROM monthly_plans WHERE month=? ORDER BY CASE status WHEN 'approved' THEN 1 WHEN 'submitted' THEN 2 ELSE 3 END LIMIT 1",
        (month,)
    ).fetchone()

    plan_items = {}  # {product_id: {qty, cost}}
    if plan:
        for pi in conn.execute("""
            SELECT mpi.product_id, mpi.estimated_qty, mpi.estimated_price
            FROM monthly_plan_items mpi WHERE mpi.plan_id=?
        """, (plan['id'],)).fetchall():
            plan_items[pi['product_id']] = {
                'qty': pi['estimated_qty'],
                'cost': pi['estimated_qty'] * pi['estimated_price'],
                'price': pi['estimated_price'],
            }

    # ---- 2. RAT Projection for this month ----
    # Same formula as yearly_forecast: avg 6 months consumption * (1 + 0.005 * month_index)
    rat_items = {}  # {product_id: {qty, cost}}
    products_list = conn.execute("SELECT * FROM products").fetchall()
    now = datetime.now()

    for prod in products_list:
        pid = prod['id']
        total_consumption = 0
        months_with_data = 0
        for offset in range(1, 7):  # last 6 months
            m2 = now.month - offset
            y2 = now.year
            while m2 <= 0:
                m2 += 12
                y2 -= 1
            mkey = f'{y2:04d}-{m2:02d}'
            used = conn.execute(
                "SELECT COALESCE(SUM(qty_used),0) as qty FROM usage_log WHERE product_id=? AND date LIKE ?",
                (pid, mkey + '%')
            ).fetchone()['qty']
            distributed = conn.execute(
                "SELECT COALESCE(SUM(ri.qty),0) as qty FROM request_items ri JOIN requests r ON ri.request_id=r.id "
                "WHERE ri.product_id=? AND r.date LIKE ? AND r.status='fulfilled'",
                (pid, mkey + '%')
            ).fetchone()['qty']
            consumption = used + distributed
            if consumption > 0:
                months_with_data += 1
            total_consumption += consumption

        avg_monthly = total_consumption / max(months_with_data, 1) if months_with_data > 0 else 0
        if avg_monthly > 0:
            projected_qty = round(avg_monthly * (1 + 0.005 * mon))
            defvp = conn.execute(
                "SELECT price FROM vendor_prices WHERE product_id=? AND is_default=1", (pid,)
            ).fetchone()
            price = defvp['price'] if defvp else 0
            rat_items[pid] = {
                'qty': projected_qty,
                'cost': projected_qty * price,
                'price': price,
                'avg_monthly': round(avg_monthly, 1),
            }

    # ---- 3. Actual Purchased (ordered) ----
    actual_purchased = {}
    for row in conn.execute("""
        SELECT pi.product_id, SUM(pi.qty) as qty, SUM(pi.qty * pi.price) as cost
        FROM purchase_items pi JOIN purchases p ON pi.purchase_id = p.id
        WHERE p.date LIKE ? AND p.status='ordered'
        GROUP BY pi.product_id
    """, (month + '%',)).fetchall():
        actual_purchased[row['product_id']] = {'qty': row['qty'], 'cost': row['cost']}

    # ---- 4. Actual Distributed ----
    actual_distributed = {}
    for row in conn.execute("""
        SELECT ri.product_id, SUM(ri.qty) as qty
        FROM request_items ri JOIN requests r ON ri.request_id = r.id
        WHERE r.date LIKE ? AND r.status='fulfilled'
        GROUP BY ri.product_id
    """, (month + '%',)).fetchall():
        actual_distributed[row['product_id']] = row['qty']

    # ---- 5. Trend: compare avg last 3 months vs 3 months before that ----
    trend_data = {}  # {product_id: 'up'|'down'|'stable'|'new'}
    for prod in products_list:
        pid = prod['id']
        recent_total = 0  # last 3 months
        older_total = 0   # 3 months before that
        for offset in range(1, 4):
            m2 = now.month - offset
            y2 = now.year
            while m2 <= 0:
                m2 += 12
                y2 -= 1
            mkey = f'{y2:04d}-{m2:02d}'
            qty = conn.execute(
                "SELECT COALESCE(SUM(ri.qty),0) as qty FROM request_items ri JOIN requests r ON ri.request_id=r.id "
                "WHERE ri.product_id=? AND r.date LIKE ? AND r.status='fulfilled'",
                (pid, mkey + '%')
            ).fetchone()['qty']
            qty += conn.execute(
                "SELECT COALESCE(SUM(qty_used),0) as qty FROM usage_log WHERE product_id=? AND date LIKE ?",
                (pid, mkey + '%')
            ).fetchone()['qty']
            recent_total += qty
        for offset in range(4, 7):
            m2 = now.month - offset
            y2 = now.year
            while m2 <= 0:
                m2 += 12
                y2 -= 1
            mkey = f'{y2:04d}-{m2:02d}'
            qty = conn.execute(
                "SELECT COALESCE(SUM(ri.qty),0) as qty FROM request_items ri JOIN requests r ON ri.request_id=r.id "
                "WHERE ri.product_id=? AND r.date LIKE ? AND r.status='fulfilled'",
                (pid, mkey + '%')
            ).fetchone()['qty']
            qty += conn.execute(
                "SELECT COALESCE(SUM(qty_used),0) as qty FROM usage_log WHERE product_id=? AND date LIKE ?",
                (pid, mkey + '%')
            ).fetchone()['qty']
            older_total += qty
        if recent_total == 0 and older_total == 0:
            trend_data[pid] = 'none'
        elif older_total == 0:
            trend_data[pid] = 'new'
        else:
            ratio = recent_total / older_total
            if ratio > 1.15:
                trend_data[pid] = 'up'
            elif ratio < 0.85:
                trend_data[pid] = 'down'
            else:
                trend_data[pid] = 'stable'

    # ---- 6. Build comparison ----
    comparison = []
    seen = set()

    # All product IDs that have any data
    all_pids = set(plan_items.keys()) | set(rat_items.keys()) | set(actual_purchased.keys()) | set(actual_distributed.keys())

    for pid in all_pids:
        seen.add(pid)
        prod = conn.execute("SELECT name, uom, type, category FROM products WHERE id=?", (pid,)).fetchone()
        if not prod:
            continue

        pl = plan_items.get(pid, {'qty': 0, 'cost': 0, 'price': 0})
        rt = rat_items.get(pid, {'qty': 0, 'cost': 0, 'price': 0})
        ap = actual_purchased.get(pid, {'qty': 0, 'cost': 0})

        # Selisih is based on best available plan (monthly plan > RAT)
        ref_qty = pl['qty'] if pl['qty'] > 0 else rt['qty']
        ref_cost = pl['cost'] if pl['cost'] > 0 else rt['cost']

        comparison.append({
            'product_id': pid,
            'name': prod['name'],
            'uom': prod['uom'],
            'type': prod['type'],
            'category': prod['category'],
            # Projections
            'rat_qty': rt.get('qty', 0),
            'rat_cost': rt.get('cost', 0),
            'plan_qty': pl.get('qty', 0),
            'plan_cost': pl.get('cost', 0),
            # Actual
            'actual_qty': ap['qty'],
            'actual_cost': ap['cost'],
            # Variance (vs best available ref)
            'variance_qty': ap['qty'] - ref_qty,
            'variance_cost': ap['cost'] - ref_cost,
            # Distribution & trend
            'distributed': actual_distributed.get(pid, 0),
            'trend': trend_data.get(pid, 'none'),
        })

    # Sort: items with activity first, then by name
    comparison.sort(key=lambda c: (0 if (c['actual_qty'] > 0 or c['distributed'] > 0) else 1, c['name']))

    total_rat = sum(c['rat_cost'] for c in comparison)
    total_plan = sum(c['plan_cost'] for c in comparison)
    total_actual = sum(c['actual_cost'] for c in comparison)
    total_distributed = sum(c['distributed'] for c in comparison)

    conn.close()
    return jsonify({
        'month': month,
        'has_plan': plan is not None,
        'plan_status': plan['status'] if plan else None,
        'plan_id': plan['id'] if plan else None,
        'total_rat': total_rat,
        'total_plan': total_plan,
        'total_actual': total_actual,
        'total_distributed': total_distributed,
        'variance': total_actual - (total_plan if total_plan > 0 else total_rat),
        'comparison': comparison,
    })


@bp.route('/api/realization/download')
@safe_db
def download_realization():
    """Download realization report as Excel — matches upgraded UI columns."""
    month = request.args.get('month')
    if not month:
        month = date.today().strftime('%Y-%m')

    # Re-use the JSON endpoint to get all data consistently
    with current_app.test_request_context(f'/api/realization?month={month}'):
        resp = get_realization()
        data = json_mod.loads(resp.get_data())

    comp = data.get('comparison', [])

    wb = Workbook()
    ws = wb.active
    ws.title = 'Realisasi'
    bold = Font(bold=True)
    center = Alignment(horizontal='center', vertical='center')
    right = Alignment(horizontal='right', vertical='center')
    border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
    hfill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')
    green = PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid')
    red = PatternFill(start_color='FCE4EC', end_color='FCE4EC', fill_type='solid')

    ws.merge_cells('A1:K1')
    ws['A1'] = get_clinic_name()
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = center
    ws.merge_cells('A2:K2')
    ws['A2'] = f'LAPORAN REALISASI vs PROYEKSI — {month}'
    ws['A2'].font = Font(bold=True, size=11)
    ws['A2'].alignment = center

    headers = ['No', 'Produk', 'Satuan', 'Proyeksi RAT', 'Rencana Bulanan', 'Realisasi Qty',
               'Selisih Qty', 'Selisih Biaya', 'Total Belanja', 'Trend', 'Distribusi']
    widths = [5, 28, 8, 14, 16, 14, 12, 16, 16, 12, 12]
    col_letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K']
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        ws.column_dimensions[col_letters[i-1]].width = w
        cell = ws.cell(row=4, column=i, value=h)
        cell.font = bold
        cell.alignment = center
        cell.border = border
        cell.fill = hfill

    trend_label = {'up': '↑ Naik', 'down': '↓ Turun', 'stable': '→ Stabil', 'new': '★ Baru', 'none': '—'}
    t_rat = t_plan = t_actual = t_dist = 0

    for idx, c in enumerate(comp, 1):
        row = 4 + idx
        ref_qty = c['plan_qty'] if c['plan_qty'] > 0 else c['rat_qty']
        t_rat += c.get('rat_cost', 0)
        t_plan += c.get('plan_cost', 0)
        t_actual += c.get('actual_cost', 0)
        t_dist += c.get('distributed', 0)

        vals = [idx, c['name'], c['uom'], c['rat_qty'], c['plan_qty'], c['actual_qty'],
                c['variance_qty'], c['variance_cost'], c['actual_cost'],
                trend_label.get(c.get('trend', 'none'), '—'), c['distributed']]
        for col, v in enumerate(vals, 1):
            cell = ws.cell(row=row, column=col, value=v)
            cell.border = border
            if col in (4, 5, 6, 7, 8, 9, 11):
                cell.number_format = '#,##0'
            if col == 10:
                cell.alignment = center
            if col == 7 and isinstance(v, (int, float)) and v != 0:
                cell.fill = red if v > 0 else green
            if col == 8 and isinstance(v, (int, float)) and v != 0:
                cell.fill = red if v > 0 else green

    tr = 5 + len(comp)
    ws.merge_cells(f'A{tr}:C{tr}')
    ws.cell(row=tr, column=1, value='TOTAL').font = Font(bold=True, size=12)
    ws.cell(row=tr, column=1).alignment = Alignment(horizontal='right')
    for c in range(1, 12):
        ws.cell(row=tr, column=c).border = border

    for col, val in [(4, t_rat), (5, t_plan), (6, sum(c['actual_qty'] for c in comp)),
                     (9, t_actual), (11, t_dist)]:
        ws.cell(row=tr, column=col, value=val).font = bold
        ws.cell(row=tr, column=col).number_format = '#,##0'
    var_total = data.get('variance', 0)
    cell = ws.cell(row=tr, column=8, value=var_total)
    cell.font = bold
    cell.number_format = '#,##0'
    if var_total != 0:
        cell.fill = red if var_total > 0 else green

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, download_name=f'Realisasi_{month}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
