"""Purchasing routes: purchases CRUD, submit/approve/order, download, pending approvals."""
import io
from flask import Blueprint, request, jsonify, send_file
from datetime import date
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from db_manager import get_db, log_audit
from helpers import (gid, now_ts, dict_rows, safe_db, get_clinic_name,
                     role_required, current_user, validate_int, err)

bp = Blueprint('purchasing', __name__)


# ===================== PURCHASES =====================
@bp.route('/api/purchases')
@safe_db
def get_purchases():
    status = request.args.get('status')
    conn = get_db()
    if status:
        rows = conn.execute("""
            SELECT p.*, v.name as vendor_name
            FROM purchases p LEFT JOIN vendors v ON p.vendor_id = v.id
            WHERE p.status=? ORDER BY p.date DESC
        """, (status,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT p.*, v.name as vendor_name
            FROM purchases p LEFT JOIN vendors v ON p.vendor_id = v.id
            ORDER BY p.date DESC
        """).fetchall()
    result = []
    for r in rows:
        rd = dict(r)
        items = conn.execute("""
            SELECT pi.product_id, pi.qty, pi.price, pi.vendor_id,
                   pr.name as product_name, pr.uom, pr.category, pr.type,
                   v.name as vendor_name
            FROM purchase_items pi
            JOIN products pr ON pi.product_id = pr.id
            LEFT JOIN vendors v ON pi.vendor_id = v.id
            WHERE pi.purchase_id=?
        """, (r['id'],)).fetchall()
        rd['items'] = [dict(i) for i in items]
        result.append(rd)
    conn.close()
    return jsonify(result)


def _validate_purchase_payload(conn, data):
    """Shared validation untuk create + update purchase. Catch FK issues
    sebelum insert supaya error message jelas (audit finding: generic 500)."""
    vendor_id = data.get('vendor_id')
    if vendor_id and not conn.execute("SELECT 1 FROM vendors WHERE id=?", (vendor_id,)).fetchone():
        return None, err('Vendor tidak ditemukan', 404)
    items_in = data.get('items') or []
    if not items_in or len(items_in) > 500:
        return None, err('Minimal 1 item, maksimal 500')
    clean_items = []
    total = 0
    for idx, item in enumerate(items_in):
        pid = item.get('product_id')
        if not pid:
            return None, err(f'Item #{idx+1}: product_id wajib')
        if not conn.execute("SELECT 1 FROM products WHERE id=?", (pid,)).fetchone():
            return None, err(f'Item #{idx+1}: produk "{pid[:8]}" tidak ditemukan', 404)
        qty = validate_int(item.get('qty', 0), min_val=1, max_val=10**6)
        price = validate_int(item.get('price', 0), min_val=0, max_val=10**9)
        if qty <= 0:
            return None, err(f'Item #{idx+1}: qty harus > 0')
        v_override = item.get('vendor_id')
        if v_override and not conn.execute("SELECT 1 FROM vendors WHERE id=?", (v_override,)).fetchone():
            v_override = None  # silent fallback daripada bounce
        clean_items.append({'product_id': pid, 'qty': qty, 'price': price, 'vendor_id': v_override})
        total += qty * price
    return {'vendor_id': vendor_id, 'items': clean_items, 'total': total}, None


@bp.route('/api/purchases', methods=['POST'])
@safe_db
@role_required('admin')
def create_purchase():
    """Create a DRAFT purchase (does NOT affect warehouse yet)."""
    data = request.get_json(silent=True) or {}
    conn = get_db()
    clean, e = _validate_purchase_payload(conn, data)
    if e:
        conn.close(); return e
    today = date.today()
    prefix = f"PO-{today.strftime('%Y-%m')}"
    count = conn.execute("SELECT COUNT(*) FROM purchases WHERE id LIKE ?", (prefix + '%',)).fetchone()[0]
    pid = f"{prefix}-{count+1:03d}"
    actor = (current_user() or {}).get('display_name', '')
    conn.execute(
        "INSERT INTO purchases (id, date, vendor_id, notes, total, status, admin_name, director_name, created_by) VALUES (?,?,?,?,?,?,?,?,?)",
        (pid, (data.get('date') or date.today().isoformat())[:10],
         clean['vendor_id'], (data.get('notes') or '')[:500], clean['total'], 'draft',
         (data.get('admin_name') or actor)[:100],
         (data.get('director_name') or '')[:100],
         actor[:100])
    )
    for it in clean['items']:
        conn.execute(
            "INSERT INTO purchase_items (purchase_id, product_id, qty, price, vendor_id) VALUES (?,?,?,?,?)",
            (pid, it['product_id'], it['qty'], it['price'], it['vendor_id'])
        )
    log_audit(conn, actor, 'CREATE_PURCHASE', 'purchases', pid,
              f'{len(clean["items"])} items · total {clean["total"]}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': pid, 'total': clean['total']})


@bp.route('/api/purchases/<pid>', methods=['PUT'])
@safe_db
@role_required('admin')
def update_purchase(pid):
    """Update a draft purchase (items, notes, names)."""
    data = request.get_json(silent=True) or {}
    conn = get_db()
    pu = conn.execute("SELECT status FROM purchases WHERE id=?", (pid,)).fetchone()
    if not pu or pu['status'] != 'draft':
        conn.close()
        return err('Hanya draft yang bisa diedit')
    clean, e = _validate_purchase_payload(conn, data)
    if e:
        conn.close(); return e
    conn.execute(
        "UPDATE purchases SET date=?, vendor_id=?, notes=?, total=?, admin_name=?, director_name=? WHERE id=?",
        ((data.get('date') or date.today().isoformat())[:10], clean['vendor_id'],
         (data.get('notes') or '')[:500], clean['total'],
         (data.get('admin_name') or '')[:100], (data.get('director_name') or '')[:100], pid)
    )
    conn.execute("DELETE FROM purchase_items WHERE purchase_id=?", (pid,))
    for it in clean['items']:
        conn.execute(
            "INSERT INTO purchase_items (purchase_id, product_id, qty, price, vendor_id) VALUES (?,?,?,?,?)",
            (pid, it['product_id'], it['qty'], it['price'], it['vendor_id'])
        )
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'total': clean['total']})


@bp.route('/api/purchases/<pid>/submit', methods=['POST'])
@safe_db
@role_required('admin')
def submit_purchase(pid):
    """Admin submits draft for director approval.

    Body: { admin_name }  — nama admin sebagai TTD digital. Kalau ada,
    overwrite kolom admin_name. submitted_at = timestamp sekarang.
    """
    data = request.json or {}
    admin_name = (data.get('admin_name') or '').strip()
    conn = get_db()
    now = now_ts()
    # Atomic: UPDATE dengan status guard, cek rowcount
    if admin_name:
        r = conn.execute(
            "UPDATE purchases SET status='submitted', submitted_at=?, admin_name=? WHERE id=? AND status='draft'",
            (now, admin_name, pid),
        )
    else:
        r = conn.execute(
            "UPDATE purchases SET status='submitted', submitted_at=? WHERE id=? AND status='draft'",
            (now, pid),
        )
    if r.rowcount == 0:
        conn.close()
        return jsonify({'ok': False, 'error': 'Hanya draft yang bisa diajukan'}), 400
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/purchases/<pid>/approve', methods=['POST'])
@safe_db
@role_required('direktur')
def approve_purchase(pid):
    """Director approves a submitted purchase."""
    data = request.json or {}
    conn = get_db()
    now = now_ts()
    # Atomic transition: submitted → approved. Guard concurrent approve/reject.
    r = conn.execute(
        "UPDATE purchases SET status='approved', approved_by=?, approved_at=? WHERE id=? AND status='submitted'",
        (data.get('approved_by', '')[:100], now, pid)
    )
    if r.rowcount == 0:
        conn.close()
        return jsonify({'ok': False, 'error': 'Hanya pengajuan yang bisa disetujui (mungkin sudah approved/rejected)'}), 400
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/purchases/<pid>/order', methods=['POST'])
@safe_db
@role_required('admin')
def finalize_purchase(pid):
    """Order an approved purchase. This commits items to warehouse stock.

    Atomic: BEGIN IMMEDIATE + UPDATE dengan status guard mencegah
    double-order race yang bisa tambah stok 2x.
    """
    conn = get_db()
    try:
        conn.execute('BEGIN IMMEDIATE')
        pu = conn.execute("SELECT * FROM purchases WHERE id=?", (pid,)).fetchone()
        if not pu:
            conn.rollback(); conn.close()
            return jsonify({'ok': False, 'error': 'Not found'}), 404
        if pu['status'] != 'approved':
            conn.rollback(); conn.close()
            return jsonify({'ok': False, 'error': 'Pembelian harus disetujui direktur terlebih dahulu'}), 400

        items = conn.execute("SELECT * FROM purchase_items WHERE purchase_id=?", (pid,)).fetchall()
        for it in items:
            existing = conn.execute(
                "SELECT id FROM warehouse_stock WHERE product_id=?", (it['product_id'],)
            ).fetchone()
            if existing:
                conn.execute("UPDATE warehouse_stock SET qty=qty+? WHERE id=?",
                             (it['qty'], existing['id']))
            else:
                conn.execute("INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                             (gid(), it['product_id'], it['qty']))

        ts = now_ts()
        r = conn.execute(
            "UPDATE purchases SET status='ordered', ordered_at=? WHERE id=? AND status='approved'",
            (ts, pid)
        )
        if r.rowcount == 0:
            conn.rollback(); conn.close()
            return jsonify({'ok': False, 'error': 'Status berubah selama transaksi — coba lagi'}), 409
        actor = (current_user() or {}).get('display_name', '')
        log_audit(conn, actor, 'ORDER', 'purchases', pid, f'Total: {pu["total"]}')
        conn.commit()
    except Exception:
        conn.rollback(); conn.close()
        raise
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/purchases/<pid>/reject', methods=['POST'])
@safe_db
@role_required('direktur')
def reject_purchase(pid):
    conn = get_db()
    r = conn.execute("UPDATE purchases SET status='rejected' WHERE id=? AND status='submitted'", (pid,))
    if r.rowcount == 0:
        conn.close()
        return jsonify({'ok': False, 'error': 'Hanya pengajuan yang bisa ditolak'}), 400
    actor = (current_user() or {}).get('display_name', '')
    log_audit(conn, actor, 'REJECT_PURCHASE', 'purchases', pid, '')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/purchases/<pid>', methods=['DELETE'])
@safe_db
@role_required('admin')
def delete_purchase(pid):
    conn = get_db()
    pu = conn.execute("SELECT status FROM purchases WHERE id=?", (pid,)).fetchone()
    if pu and pu['status'] == 'draft':
        conn.execute("DELETE FROM purchases WHERE id=?", (pid,))
        conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/purchases/<pid>/download')
@safe_db
def download_purchase(pid):
    """Download purchase document as Excel with signature fields."""
    conn = get_db()
    pu = conn.execute("""
        SELECT p.*, v.name as vendor_name
        FROM purchases p LEFT JOIN vendors v ON p.vendor_id = v.id WHERE p.id=?
    """, (pid,)).fetchone()
    if not pu:
        conn.close()
        return jsonify({'ok': False, 'error': 'Not found'}), 404

    items = conn.execute("""
        SELECT pi.*, pr.name as product_name, pr.uom, pr.category,
               v.name as vendor_name
        FROM purchase_items pi
        JOIN products pr ON pi.product_id = pr.id
        LEFT JOIN vendors v ON pi.vendor_id = v.id
        WHERE pi.purchase_id=?
    """, (pid,)).fetchall()
    conn.close()

    wb = Workbook()
    ws = wb.active
    ws.title = 'Rencana Pembelian'

    bold = Font(bold=True)
    center = Alignment(horizontal='center', vertical='center')
    border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    header_fill = PatternFill(start_color='D9E1F2', end_color='D9E1F2', fill_type='solid')

    # Title
    ws.merge_cells('A1:G1')
    ws['A1'] = get_clinic_name()
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = center

    ws.merge_cells('A2:G2')
    ws['A2'] = 'DOKUMEN RENCANA PEMBELIAN ATK & RTK'
    ws['A2'].font = Font(bold=True, size=11)
    ws['A2'].alignment = center

    ws['A4'] = 'Tanggal:'
    ws['B4'] = pu['date']
    ws['A4'].font = bold
    ws['D4'] = 'No. Dokumen:'
    ws['E4'] = pu['id'].upper()
    ws['D4'].font = bold
    ws['A5'] = 'Catatan:'
    ws['B5'] = pu['notes'] or '-'
    ws['A5'].font = bold

    # Table header
    headers = ['No', 'Nama Produk', 'Kategori', 'Vendor', 'Qty', 'Harga Satuan', 'Total']
    ws.column_dimensions['A'].width = 5
    ws.column_dimensions['B'].width = 30
    ws.column_dimensions['C'].width = 16
    ws.column_dimensions['D'].width = 22
    ws.column_dimensions['E'].width = 8
    ws.column_dimensions['F'].width = 16
    ws.column_dimensions['G'].width = 18

    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=7, column=col, value=h)
        cell.font = bold
        cell.alignment = center
        cell.border = border
        cell.fill = header_fill

    grand_total = 0
    for i, it in enumerate(items, 1):
        row = 7 + i
        subtotal = it['qty'] * it['price']
        grand_total += subtotal
        vals = [i, it['product_name'], it['category'], it['vendor_name'] or '-',
                it['qty'], it['price'], subtotal]
        for col, v in enumerate(vals, 1):
            cell = ws.cell(row=row, column=col, value=v)
            cell.border = border
            if col in (5, 6, 7):
                cell.number_format = '#,##0'

    # Total row
    total_row = 8 + len(items)
    ws.merge_cells(f'A{total_row}:E{total_row}')
    ws.cell(row=total_row, column=1, value='TOTAL').font = Font(bold=True, size=12)
    ws.cell(row=total_row, column=1).alignment = Alignment(horizontal='right')
    ws.cell(row=total_row, column=1).border = border
    for c in range(2, 6):
        ws.cell(row=total_row, column=c).border = border
    ws.cell(row=total_row, column=6).border = border
    ws.cell(row=total_row, column=7, value=grand_total).font = Font(bold=True, size=12)
    ws.cell(row=total_row, column=7).number_format = '#,##0'
    ws.cell(row=total_row, column=7).border = border

    # Signature section
    sig_row = total_row + 3
    ws.merge_cells(f'B{sig_row}:C{sig_row}')
    ws.cell(row=sig_row, column=2, value='Mengetahui,').font = bold
    ws.cell(row=sig_row, column=2).alignment = center
    ws.merge_cells(f'E{sig_row}:G{sig_row}')
    ws.cell(row=sig_row, column=5, value='Menyetujui,').font = bold
    ws.cell(row=sig_row, column=5).alignment = center

    sig_row2 = sig_row + 1
    ws.merge_cells(f'B{sig_row2}:C{sig_row2}')
    ws.cell(row=sig_row2, column=2, value='Admin Pengadaan').alignment = center
    ws.merge_cells(f'E{sig_row2}:G{sig_row2}')
    ws.cell(row=sig_row2, column=5, value='Direktur Klinik').alignment = center

    sig_row3 = sig_row + 5
    ws.merge_cells(f'B{sig_row3}:C{sig_row3}')
    admin_name = pu['admin_name'] or '____________________'
    ws.cell(row=sig_row3, column=2, value=admin_name).alignment = center
    ws.cell(row=sig_row3, column=2).font = Font(bold=True, underline='single')
    ws.merge_cells(f'E{sig_row3}:G{sig_row3}')
    director_name = pu['director_name'] or '____________________'
    ws.cell(row=sig_row3, column=5, value=director_name).alignment = center
    ws.cell(row=sig_row3, column=5).font = Font(bold=True, underline='single')

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f'Pembelian_{pu["id"]}_{pu["date"]}.xlsx'
    return send_file(buf, download_name=fname,
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ===================== PENDING APPROVALS (DIRECTOR) =====================
@bp.route('/api/pending-approvals')
@safe_db
def pending_approvals():
    conn = get_db()
    pending_purchases = conn.execute("""
        SELECT p.*, v.name as vendor_name,
               (SELECT COUNT(*) FROM purchase_items WHERE purchase_id=p.id) as item_count
        FROM purchases p LEFT JOIN vendors v ON p.vendor_id = v.id
        WHERE p.status='submitted' ORDER BY p.submitted_at DESC
    """).fetchall()
    pending_plans = conn.execute("""
        SELECT *,
               (SELECT COUNT(*) FROM monthly_plan_items WHERE plan_id=monthly_plans.id) as item_count
        FROM monthly_plans WHERE status='submitted' ORDER BY submitted_at DESC
    """).fetchall()
    conn.close()
    return jsonify({
        'purchases': dict_rows(pending_purchases),
        'plans': dict_rows(pending_plans),
        'total': len(pending_purchases) + len(pending_plans),
    })
