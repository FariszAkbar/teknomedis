"""RAT (Rencana Anggaran Tahunan) per unit.

Lifecycle:
    draft -> submitted (unit kirim) -> admin_approved (admin review)
          -> approved (direktur final) -> LOCKED = proyeksi bulanan
                                           alat ukur tahun tsb.

Semua approved RAT tahun berjalan jadi dasar "sisa proyeksi bulan ini"
saat unit bikin request.

Endpoints:
    GET    /api/rat                              list (filter year, unit_id, status)
    GET    /api/rat/<id>                         detail dgn matrix items
    POST   /api/rat/generate                     auto-generate draft dari 3-bulan pattern
    PUT    /api/rat/<id>/item                    edit 1 sel qty (unit only, saat draft)
    PUT    /api/rat/<id>                         edit meta (growth_factor, notes)
    POST   /api/rat/<id>/submit                  unit kirim ke admin
    POST   /api/rat/<id>/admin-approve           admin lulus
    POST   /api/rat/<id>/director-approve        direktur final
    POST   /api/rat/<id>/reject                  dari mana saja, dgn alasan
    DELETE /api/rat/<id>                         hapus draft
    GET    /api/rat/<id>/realization             realisasi vs proyeksi
    GET    /api/rat/projection/current           proyeksi bulan berjalan untuk unit login
"""
import math
from datetime import date, datetime
from flask import Blueprint, request, jsonify
from db_manager import get_db, log_audit
from helpers import safe_db, get_json, ok, err, role_required, current_user

bp = Blueprint('rat', __name__)


# ================ LIST ================

@bp.route('/api/rat')
@safe_db
def list_rat():
    year = request.args.get('year', type=int)
    unit_id = request.args.get('unit_id')
    status = request.args.get('status')
    conn = get_db()
    q = """
      SELECT ap.*, u.name AS unit_name
      FROM annual_projections ap
      LEFT JOIN units u ON u.id = ap.unit_id
      WHERE 1=1
    """
    args = []
    if year:    q += " AND ap.year = ?";    args.append(year)
    if unit_id: q += " AND ap.unit_id = ?"; args.append(unit_id)
    if status:  q += " AND ap.status = ?";  args.append(status)
    q += " ORDER BY ap.year DESC, u.name"
    rows = conn.execute(q, args).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@bp.route('/api/rat/<rid>')
@safe_db
def get_rat(rid):
    conn = get_db()
    r = conn.execute("""
        SELECT ap.*, u.name AS unit_name FROM annual_projections ap
        LEFT JOIN units u ON u.id = ap.unit_id
        WHERE ap.id = ?
    """, (rid,)).fetchone()
    if not r:
        conn.close()
        return err('RAT tidak ditemukan', 404)
    items = conn.execute("""
        SELECT ai.*, p.name AS product_name, p.category, p.type, p.uom,
               v.name AS vendor_name
        FROM annual_projection_items ai
        JOIN products p ON p.id = ai.product_id
        LEFT JOIN vendors v ON v.id = ai.vendor_id
        WHERE ai.projection_id = ?
        ORDER BY p.name, ai.month
    """, (rid,)).fetchall()
    conn.close()
    return jsonify({'ok': True, 'rat': dict(r), 'items': [dict(i) for i in items]})


# ================ AUTO-GENERATE ================

@bp.route('/api/rat/generate', methods=['POST'])
@safe_db
@role_required('unit', 'admin')
def generate_rat():
    """Create a fresh draft RAT for (unit_id, year) based on past 3 months usage.

    Body: { unit_id, year, growth_factor (default 1.05) }
    Strategy per product (unit filtered):
      avg_month_usage = SUM(qty_used in last 3 months) / 3
      target_year_qty = ceil(avg_month_usage * 12 * growth_factor)
      per_month_qty   = round(target_year_qty / 12)   # flat distribution
    User can later edit each cell.

    If RAT for (unit, year) already exists — returns 409. Unit harus
    DELETE draft lama dulu kalau mau regenerate.
    """
    data = get_json()
    unit_id = data.get('unit_id')
    try:
        year = int(data.get('year', 0))
    except (TypeError, ValueError):
        year = 0
    growth = float(data.get('growth_factor', 1.05))
    if not unit_id or not year:
        return err('unit_id dan year wajib diisi')

    conn = get_db()
    if not conn.execute("SELECT 1 FROM units WHERE id=?", (unit_id,)).fetchone():
        conn.close()
        return err('Unit tidak ditemukan', 404)

    existing = conn.execute(
        "SELECT id, status FROM annual_projections WHERE year=? AND unit_id=?",
        (year, unit_id)
    ).fetchone()
    if existing:
        conn.close()
        return jsonify({'ok': False,
                        'error': f'RAT untuk unit ini tahun {year} sudah ada (status {existing["status"]}). Hapus draft lama atau edit yang ini.',
                        'existing_id': existing['id'],
                        'existing_status': existing['status']}), 409

    # Past 3 months window ending today
    from datetime import timedelta
    today = date.today()
    start = (today.replace(day=1) - timedelta(days=1)).replace(day=1)  # first of previous month
    start = (start.replace(day=1) - timedelta(days=2)).replace(day=1)  # go back 2 more months
    # simpler: 90 days window
    start_90 = (today - timedelta(days=90)).isoformat()
    end_90 = today.isoformat()

    usage_rows = conn.execute("""
        SELECT p.id, p.name, SUM(ul.qty_used) AS total_used
        FROM usage_log ul JOIN products p ON p.id = ul.product_id
        WHERE ul.date BETWEEN ? AND ? AND ul.unit_id = ?
        GROUP BY p.id, p.name
    """, (start_90, end_90, unit_id)).fetchall()

    # Build items list
    total_qty = 0
    total_cost = 0
    item_rows = []
    # Include a timestamp suffix to avoid collisions when two units share
    # the same 6-char prefix, or the same unit gets regenerated after delete.
    rid = f"RAT-{year}-{unit_id[:6]}-{datetime.now().strftime('%H%M%S')}"
    if conn.execute("SELECT 1 FROM annual_projections WHERE id=?", (rid,)).fetchone():
        # Impossibly rare — but belt-and-braces.
        conn.close()
        return err('RAT id conflict — coba lagi sebentar')

    for row in usage_rows:
        avg_month = (row['total_used'] or 0) / 3
        target_year = math.ceil(avg_month * 12 * growth)
        if target_year <= 0:
            continue
        per_month = max(1, round(target_year / 12))
        # default vendor price
        vp = conn.execute("""
            SELECT vendor_id, price FROM vendor_prices
            WHERE product_id = ? ORDER BY is_default DESC LIMIT 1
        """, (row['id'],)).fetchone()
        vendor_id = vp['vendor_id'] if vp else None
        unit_price = vp['price'] if vp else 0
        # Add 12 rows (one per month)
        for m in range(1, 13):
            item_rows.append((rid, row['id'], m, per_month, unit_price, vendor_id))
        total_qty += per_month * 12
        total_cost += per_month * 12 * unit_price

    if not item_rows:
        conn.close()
        return err('Tidak ada data pemakaian 3 bulan terakhir untuk unit ini. '
                   'Isi pemakaian manual dulu atau buat RAT dari awal.')

    now_iso = datetime.now().isoformat(timespec='seconds')
    conn.execute("""
        INSERT INTO annual_projections
            (id, year, unit_id, status, growth_factor, total_qty, total_cost,
             created_date, created_by, notes)
        VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?)
    """, (rid, year, unit_id, growth, total_qty, total_cost,
          now_iso, '', f'Auto-generated dari usage 90 hari terakhir × 12 × {growth:.2f}'))
    conn.executemany("""
        INSERT INTO annual_projection_items
            (projection_id, product_id, month, qty, unit_price, vendor_id)
        VALUES (?, ?, ?, ?, ?, ?)
    """, item_rows)
    log_audit(conn, '', 'CREATE_RAT', 'annual_projections', rid,
              f'year={year} unit={unit_id} growth={growth}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': rid, 'total_qty': total_qty, 'total_cost': total_cost,
                    'products': len({r[1] for r in item_rows})})


# ================ EDIT ================

def _recompute_totals(conn, rid):
    """Recompute total_qty + total_cost from items. Called after any edit."""
    row = conn.execute("""
        SELECT COALESCE(SUM(qty),0) AS qty, COALESCE(SUM(qty*unit_price),0) AS cost
        FROM annual_projection_items WHERE projection_id = ?
    """, (rid,)).fetchone()
    conn.execute("UPDATE annual_projections SET total_qty=?, total_cost=? WHERE id=?",
                 (row['qty'], row['cost'], rid))


@bp.route('/api/rat/<rid>/item', methods=['PUT'])
@safe_db
@role_required('unit', 'admin')
def edit_rat_item(rid):
    """Edit qty / unit_price / vendor_id for (projection, product, month).

    Editable states:
      - draft       : unit sedang menyusun
      - rejected    : direktur/admin tolak → unit harus revisi, harus bisa edit
      - submitted   : admin boleh tweak sebelum approve
    Locked states: admin_approved, approved — ini sudah berjalan sebagai
    proyeksi aktif, jangan diubah diam-diam.
    """
    data = get_json()
    product_id = data.get('product_id')
    month = int(data.get('month', 0) or 0)
    if not product_id or month < 1 or month > 12:
        return err('product_id + month (1..12) wajib')

    conn = get_db()
    r = conn.execute("SELECT status FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return err('RAT tidak ditemukan', 404)
    if r['status'] not in ('draft', 'submitted', 'rejected'):
        conn.close(); return err(f'RAT status "{r["status"]}" tidak bisa diedit', 400)

    # Upsert: replace-or-insert
    existing = conn.execute("""
        SELECT id FROM annual_projection_items
        WHERE projection_id=? AND product_id=? AND month=?
    """, (rid, product_id, month)).fetchone()

    qty = max(0, int(data.get('qty', 0) or 0))
    unit_price = max(0, int(data.get('unit_price', 0) or 0))
    vendor_id = data.get('vendor_id')

    if existing:
        conn.execute("""
            UPDATE annual_projection_items
            SET qty=?, unit_price=?, vendor_id=?
            WHERE id=?
        """, (qty, unit_price, vendor_id, existing['id']))
    else:
        conn.execute("""
            INSERT INTO annual_projection_items
                (projection_id, product_id, month, qty, unit_price, vendor_id)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (rid, product_id, month, qty, unit_price, vendor_id))
    _recompute_totals(conn, rid)
    conn.commit()
    conn.close()
    return ok()


@bp.route('/api/rat/<rid>', methods=['PUT'])
@safe_db
@role_required('unit', 'admin')
def edit_rat_meta(rid):
    data = get_json()
    conn = get_db()
    r = conn.execute("SELECT status FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return err('RAT tidak ditemukan', 404)
    if r['status'] not in ('draft', 'submitted'):
        conn.close(); return err('Hanya draft/submitted yg bisa diedit', 400)
    notes = data.get('notes', '')
    growth = float(data.get('growth_factor', 0)) or None
    if growth:
        conn.execute("UPDATE annual_projections SET growth_factor=?, notes=? WHERE id=?",
                     (growth, notes, rid))
    else:
        conn.execute("UPDATE annual_projections SET notes=? WHERE id=?", (notes, rid))
    conn.commit()
    conn.close()
    return ok()


# ================ APPROVAL CHAIN ================

def _advance_status(rid, from_status, to_status, actor_field_prefix, actor_name='admin'):
    conn = get_db()
    r = conn.execute("SELECT status FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return None, err('RAT tidak ditemukan', 404)
    if r['status'] != from_status:
        conn.close(); return None, err(f'Tidak bisa: status saat ini "{r["status"]}"')
    now_iso = datetime.now().isoformat(timespec='seconds')
    if actor_field_prefix:
        conn.execute(f"""
            UPDATE annual_projections
            SET status=?, {actor_field_prefix}_at=?, {actor_field_prefix}_by=?
            WHERE id=?
        """, (to_status, now_iso, actor_name, rid))
    else:
        conn.execute("UPDATE annual_projections SET status=?, submitted_at=? WHERE id=?",
                     (to_status, now_iso, rid))
    log_audit(conn, actor_name, 'RAT_' + to_status.upper(), 'annual_projections', rid, '')
    conn.commit()
    conn.close()
    return True, None


@bp.route('/api/rat/<rid>/submit', methods=['POST'])
@safe_db
@role_required('unit', 'admin')
def submit_rat(rid):
    """Submit draft → submitted, OR rejected → submitted (resubmit setelah revisi).

    Rejected flow: kalau unit sudah revise angka, tombol 'Submit ulang' harus
    work. Kalau admin bantu submit draft, juga lewat endpoint ini.
    """
    conn = get_db()
    r = conn.execute("SELECT status FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close()
        return err('RAT tidak ditemukan', 404)
    if r['status'] not in ('draft', 'rejected'):
        conn.close()
        return err(f'Tidak bisa submit: status saat ini "{r["status"]}"')
    u = current_user() or {}
    actor_name = u.get('display_name') or 'unit'
    # Tag submitter: "Administrator (admin)" atau "UGD (unit)" — jelas di UI
    role_label = {'admin': ' (admin)', 'direktur': ' (direktur)', 'unit': ' (unit)'}.get(u.get('role', ''), '')
    submitted_by = f"{actor_name}{role_label}"
    now_iso = datetime.now().isoformat(timespec='seconds')
    # Reset rejection trail saat resubmit — direktur/admin lihat submission fresh
    conn.execute("""
        UPDATE annual_projections
        SET status='submitted', submitted_at=?, submitted_by=?,
            rejected_by='', rejected_at='', reject_reason=''
        WHERE id=?
    """, (now_iso, submitted_by, rid))
    log_audit(conn, actor_name, 'RAT_SUBMIT', 'annual_projections', rid,
              f'from {r["status"]} by {submitted_by}')
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'status': 'submitted', 'submitted_by': submitted_by})


@bp.route('/api/rat/<rid>/admin-approve', methods=['POST'])
@safe_db
@role_required('admin')
def admin_approve_rat(rid):
    actor = (get_json().get('admin_name')
             or (current_user() or {}).get('display_name')
             or 'admin').strip()
    ok_, err_ = _advance_status(rid, 'submitted', 'admin_approved', 'admin_approved', actor)
    return err_ or jsonify({'ok': True, 'status': 'admin_approved'})


@bp.route('/api/rat/<rid>/director-approve', methods=['POST'])
@safe_db
@role_required('direktur')
def director_approve_rat(rid):
    actor = (get_json().get('director_name')
             or (current_user() or {}).get('display_name')
             or 'direktur').strip()
    ok_, err_ = _advance_status(rid, 'admin_approved', 'approved', 'director_approved', actor)
    return err_ or jsonify({'ok': True, 'status': 'approved'})


@bp.route('/api/rat/<rid>/reject', methods=['POST'])
@safe_db
@role_required('admin', 'direktur')
def reject_rat(rid):
    data = get_json()
    reason = (data.get('reason') or '').strip()
    actor = (data.get('actor') or 'admin').strip()
    if not reason:
        return err('Alasan penolakan wajib diisi')
    conn = get_db()
    r = conn.execute("SELECT status FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return err('RAT tidak ditemukan', 404)
    # Only meaningful to reject something that's in review. Drafts belong to
    # the unit and haven't been sent for review yet; approved/rejected are
    # already terminal.
    if r['status'] not in ('submitted', 'admin_approved'):
        conn.close(); return err(f'Tidak bisa reject status "{r["status"]}"', 400)
    conn.execute("""
        UPDATE annual_projections
        SET status='rejected', rejected_by=?, rejected_at=?, reject_reason=?
        WHERE id=?
    """, (actor, datetime.now().isoformat(timespec='seconds'), reason, rid))
    log_audit(conn, actor, 'RAT_REJECT', 'annual_projections', rid, reason)
    conn.commit()
    conn.close()
    return ok()


@bp.route('/api/rat/<rid>', methods=['DELETE'])
@safe_db
@role_required('unit', 'admin')
def delete_rat(rid):
    conn = get_db()
    r = conn.execute("SELECT status FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return err('RAT tidak ditemukan', 404)
    if r['status'] not in ('draft', 'rejected'):
        conn.close(); return err('Hanya draft/rejected yang bisa dihapus', 400)
    conn.execute("DELETE FROM annual_projections WHERE id=?", (rid,))
    log_audit(conn, '', 'DELETE_RAT', 'annual_projections', rid, '')
    conn.commit()
    conn.close()
    return ok()


# ================ REALISASI VS PROYEKSI ================

@bp.route('/api/rat/<rid>/realization/download')
@safe_db
def rat_realization_download(rid):
    """Excel report: month-by-month projected vs actual for this RAT."""
    from flask import send_file
    import io
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    conn = get_db()
    r = conn.execute("SELECT ap.*, u.name AS unit_name FROM annual_projections ap "
                     "LEFT JOIN units u ON u.id=ap.unit_id WHERE ap.id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return err('RAT tidak ditemukan', 404)

    # Reuse computation by calling the JSON endpoint logic inline.
    # (Can't call the Flask handler directly in a loop-safe way, duplicate logic.)
    proj = {m: {'qty': 0, 'cost': 0} for m in range(1, 13)}
    for row in conn.execute("SELECT month, SUM(qty) AS qty, SUM(qty*unit_price) AS cost "
                            "FROM annual_projection_items WHERE projection_id=? GROUP BY month",
                            (rid,)).fetchall():
        proj[row['month']] = {'qty': row['qty'] or 0, 'cost': row['cost'] or 0}

    actual = {m: {'qty': 0, 'cost': 0} for m in range(1, 13)}
    for row in conn.execute("""
        SELECT CAST(SUBSTR(r.date, 6, 2) AS INTEGER) AS m,
               SUM(ri.qty) AS qty,
               SUM(ri.qty * COALESCE((SELECT price FROM vendor_prices vp
                                      WHERE vp.product_id=ri.product_id
                                      ORDER BY is_default DESC LIMIT 1), 0)) AS cost
        FROM requests r JOIN request_items ri ON ri.request_id = r.id
        WHERE r.status='fulfilled' AND r.unit_id=?
          AND SUBSTR(r.date,1,4)=? AND COALESCE(ri.status,'active')='active'
        GROUP BY m
    """, (r['unit_id'], str(r['year']))).fetchall():
        if row['m']:
            actual[row['m']] = {'qty': row['qty'] or 0, 'cost': row['cost'] or 0}
    conn.close()

    from helpers import get_clinic_name
    wb = Workbook(); ws = wb.active; ws.title = f'Realisasi {r["year"]}'
    ws['A1'] = get_clinic_name(); ws['A1'].font = Font(size=14, bold=True)
    ws.merge_cells('A1:H1'); ws['A1'].alignment = Alignment(horizontal='center')
    ws['A2'] = f'Realisasi vs Proyeksi — {r["unit_name"]} ({r["year"]})'
    ws['A2'].font = Font(size=12, bold=True, color='0891B2')
    ws.merge_cells('A2:H2'); ws['A2'].alignment = Alignment(horizontal='center')

    bold = Font(bold=True, color='FFFFFF')
    fill = PatternFill('solid', fgColor='0D2137')
    border = Border(left=Side('thin'), right=Side('thin'),
                    top=Side('thin'), bottom=Side('thin'))
    headers = ['Bulan', 'Proyeksi Qty', 'Aktual Qty', 'Selisih Qty',
               'Proyeksi Biaya', 'Aktual Biaya', 'Selisih Biaya', 'Deviasi %']
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=4, column=i, value=h)
        c.font = bold; c.fill = fill; c.alignment = Alignment(horizontal='center')
        c.border = border

    months_id = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des']
    for i, m in enumerate(range(1, 13), start=5):
        p = proj[m]; a = actual[m]
        dev = (a['cost'] / p['cost'] * 100) if p['cost'] > 0 else 0
        ws.cell(row=i, column=1, value=months_id[m-1])
        ws.cell(row=i, column=2, value=p['qty'])
        ws.cell(row=i, column=3, value=a['qty'])
        ws.cell(row=i, column=4, value=a['qty'] - p['qty'])
        ws.cell(row=i, column=5, value=p['cost'])
        ws.cell(row=i, column=6, value=a['cost'])
        ws.cell(row=i, column=7, value=a['cost'] - p['cost'])
        ws.cell(row=i, column=8, value=f'{dev:.1f}%' if p['cost'] > 0 else '-')
        for col in range(1, 9):
            ws.cell(row=i, column=col).border = border
    # Totals row
    tot_p_q = sum(proj[m]['qty'] for m in range(1,13))
    tot_a_q = sum(actual[m]['qty'] for m in range(1,13))
    tot_p_c = sum(proj[m]['cost'] for m in range(1,13))
    tot_a_c = sum(actual[m]['cost'] for m in range(1,13))
    tot_dev = (tot_a_c / tot_p_c * 100) if tot_p_c > 0 else 0
    r_idx = 17
    ws.cell(row=r_idx, column=1, value='TOTAL').font = Font(bold=True)
    ws.cell(row=r_idx, column=2, value=tot_p_q).font = Font(bold=True)
    ws.cell(row=r_idx, column=3, value=tot_a_q).font = Font(bold=True)
    ws.cell(row=r_idx, column=4, value=tot_a_q - tot_p_q).font = Font(bold=True)
    ws.cell(row=r_idx, column=5, value=tot_p_c).font = Font(bold=True)
    ws.cell(row=r_idx, column=6, value=tot_a_c).font = Font(bold=True)
    ws.cell(row=r_idx, column=7, value=tot_a_c - tot_p_c).font = Font(bold=True)
    ws.cell(row=r_idx, column=8, value=f'{tot_dev:.1f}%').font = Font(bold=True)
    for col, w in enumerate([10, 14, 14, 14, 18, 18, 18, 12], start=1):
        ws.column_dimensions[chr(64 + col)].width = w

    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f'Realisasi-{r["unit_name"]}-{r["year"]}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@bp.route('/api/rat/<rid>/realization')
@safe_db
def rat_realization(rid):
    """For each month: projected qty/cost vs actual distributed qty/cost.

    Actual = fulfilled request_items sum untuk unit & tahun RAT.
    Deviasi = aktual / proyeksi * 100 (persentase).
    """
    conn = get_db()
    r = conn.execute("SELECT * FROM annual_projections WHERE id=?", (rid,)).fetchone()
    if not r:
        conn.close(); return err('RAT tidak ditemukan', 404)
    year = r['year']
    unit_id = r['unit_id']

    # Proyeksi per bulan (aggregate)
    proj = {m: {'qty': 0, 'cost': 0} for m in range(1, 13)}
    for row in conn.execute("""
        SELECT month, SUM(qty) AS qty, SUM(qty*unit_price) AS cost
        FROM annual_projection_items WHERE projection_id=?
        GROUP BY month
    """, (rid,)).fetchall():
        proj[row['month']] = {'qty': row['qty'] or 0, 'cost': row['cost'] or 0}

    # Actual: distribusi fulfilled per bulan untuk unit ini tahun ini
    actual = {m: {'qty': 0, 'cost': 0} for m in range(1, 13)}
    for row in conn.execute("""
        SELECT CAST(SUBSTR(r.date, 6, 2) AS INTEGER) AS m,
               SUM(ri.qty) AS qty,
               SUM(ri.qty * COALESCE((SELECT price FROM vendor_prices vp
                                      WHERE vp.product_id=ri.product_id
                                      ORDER BY is_default DESC LIMIT 1), 0)) AS cost
        FROM requests r
        JOIN request_items ri ON ri.request_id = r.id
        WHERE r.status='fulfilled' AND r.unit_id=?
          AND SUBSTR(r.date,1,4)=? AND COALESCE(ri.status,'active')='active'
        GROUP BY m
    """, (unit_id, str(year))).fetchall():
        if row['m']:
            actual[row['m']] = {'qty': row['qty'] or 0, 'cost': row['cost'] or 0}

    months = []
    for m in range(1, 13):
        p, a = proj[m], actual[m]
        ratio_qty = (a['qty'] / p['qty'] * 100) if p['qty'] > 0 else 0
        ratio_cost = (a['cost'] / p['cost'] * 100) if p['cost'] > 0 else 0
        months.append({
            'month': m,
            'projected_qty': p['qty'], 'projected_cost': p['cost'],
            'actual_qty': a['qty'], 'actual_cost': a['cost'],
            'qty_deviation_pct': round(ratio_qty, 1),
            'cost_deviation_pct': round(ratio_cost, 1),
            'qty_diff': a['qty'] - p['qty'],
            'cost_diff': a['cost'] - p['cost'],
        })
    conn.close()
    return jsonify({'ok': True, 'rat_id': rid, 'year': year, 'unit_id': unit_id, 'months': months})


# ================ DASHBOARD REALISASI (DIREKTUR) ================

@bp.route('/api/rat/dashboard')
@safe_db
def rat_dashboard():
    """Aggregate realization across all approved RATs for a given year.

    Output per unit: YTD projected qty/cost vs actual qty/cost + YTD %,
    plus 12-month series supaya direktur bisa lihat trend per bulan.

    Query: ?year=YYYY (default: current year)
    """
    year = request.args.get('year', type=int) or date.today().year
    now = date.today()
    current_month = now.month if now.year == year else 12

    conn = get_db()
    rats = conn.execute("""
        SELECT ap.id, ap.unit_id, ap.total_qty, ap.total_cost,
               u.name AS unit_name
        FROM annual_projections ap
        LEFT JOIN units u ON u.id = ap.unit_id
        WHERE ap.year=? AND ap.status='approved'
        ORDER BY u.name
    """, (year,)).fetchall()

    units_data = []
    total_proj_qty = total_proj_cost = 0
    total_act_qty = total_act_cost = 0
    # Aggregate per bulan untuk chart 12-bulan (semua unit digabung)
    monthly_agg = {m: {'proj_qty': 0, 'proj_cost': 0, 'act_qty': 0, 'act_cost': 0}
                   for m in range(1, 13)}

    for r in rats:
        rid = r['id']
        unit_id = r['unit_id']

        # Proyeksi per bulan
        proj_months = {m: {'qty': 0, 'cost': 0} for m in range(1, 13)}
        for row in conn.execute("""
            SELECT month, SUM(qty) AS qty, SUM(qty*unit_price) AS cost
            FROM annual_projection_items WHERE projection_id=?
            GROUP BY month
        """, (rid,)).fetchall():
            proj_months[row['month']] = {'qty': row['qty'] or 0, 'cost': row['cost'] or 0}

        # Actual per bulan (fulfilled distribusi)
        act_months = {m: {'qty': 0, 'cost': 0} for m in range(1, 13)}
        for row in conn.execute("""
            SELECT CAST(SUBSTR(r.date, 6, 2) AS INTEGER) AS m,
                   SUM(ri.qty) AS qty,
                   SUM(ri.qty * COALESCE((SELECT price FROM vendor_prices vp
                                          WHERE vp.product_id=ri.product_id
                                          ORDER BY is_default DESC LIMIT 1), 0)) AS cost
            FROM requests r JOIN request_items ri ON ri.request_id = r.id
            WHERE r.status='fulfilled' AND r.unit_id=?
              AND SUBSTR(r.date,1,4)=? AND COALESCE(ri.status,'active')='active'
            GROUP BY m
        """, (unit_id, str(year))).fetchall():
            if row['m']:
                act_months[row['m']] = {'qty': row['qty'] or 0, 'cost': row['cost'] or 0}

        # YTD sampai bulan berjalan
        ytd_proj_qty = sum(proj_months[m]['qty'] for m in range(1, current_month + 1))
        ytd_proj_cost = sum(proj_months[m]['cost'] for m in range(1, current_month + 1))
        ytd_act_qty = sum(act_months[m]['qty'] for m in range(1, current_month + 1))
        ytd_act_cost = sum(act_months[m]['cost'] for m in range(1, current_month + 1))
        pct_cost = (ytd_act_cost / ytd_proj_cost * 100) if ytd_proj_cost > 0 else 0
        pct_qty = (ytd_act_qty / ytd_proj_qty * 100) if ytd_proj_qty > 0 else 0

        # Status: underspend (ok), ontrack (~100%), overspend (>115%)
        if ytd_proj_cost == 0:
            status = 'nodata'
        elif pct_cost > 115:
            status = 'overspend'
        elif pct_cost < 70:
            status = 'underspend'
        else:
            status = 'ontrack'

        units_data.append({
            'rat_id': rid,
            'unit_id': unit_id,
            'unit_name': r['unit_name'] or '?',
            'annual_proj_qty': r['total_qty'],
            'annual_proj_cost': r['total_cost'],
            'ytd_proj_qty': ytd_proj_qty,
            'ytd_proj_cost': ytd_proj_cost,
            'ytd_act_qty': ytd_act_qty,
            'ytd_act_cost': ytd_act_cost,
            'ytd_pct_cost': round(pct_cost, 1),
            'ytd_pct_qty': round(pct_qty, 1),
            'status': status,
            'months': [
                {'month': m,
                 'proj_qty': proj_months[m]['qty'], 'proj_cost': proj_months[m]['cost'],
                 'act_qty': act_months[m]['qty'], 'act_cost': act_months[m]['cost']}
                for m in range(1, 13)
            ],
        })

        total_proj_qty += r['total_qty'] or 0
        total_proj_cost += r['total_cost'] or 0
        total_act_qty += sum(act_months[m]['qty'] for m in range(1, 13))
        total_act_cost += sum(act_months[m]['cost'] for m in range(1, 13))
        for m in range(1, 13):
            monthly_agg[m]['proj_qty'] += proj_months[m]['qty']
            monthly_agg[m]['proj_cost'] += proj_months[m]['cost']
            monthly_agg[m]['act_qty'] += act_months[m]['qty']
            monthly_agg[m]['act_cost'] += act_months[m]['cost']

    # Klinik-wide YTD
    ytd_proj_cost_all = sum(monthly_agg[m]['proj_cost'] for m in range(1, current_month + 1))
    ytd_act_cost_all = sum(monthly_agg[m]['act_cost'] for m in range(1, current_month + 1))
    ytd_pct_all = (ytd_act_cost_all / ytd_proj_cost_all * 100) if ytd_proj_cost_all > 0 else 0

    conn.close()
    return jsonify({
        'ok': True,
        'year': year,
        'current_month': current_month,
        'total_units_with_rat': len(rats),
        'annual_proj_qty': total_proj_qty,
        'annual_proj_cost': total_proj_cost,
        'annual_act_qty': total_act_qty,
        'annual_act_cost': total_act_cost,
        'ytd_proj_cost': ytd_proj_cost_all,
        'ytd_act_cost': ytd_act_cost_all,
        'ytd_pct_cost': round(ytd_pct_all, 1),
        'units': units_data,
        'monthly_agg': [
            {'month': m, **monthly_agg[m]} for m in range(1, 13)
        ],
    })


# ================ PROYEKSI BULAN BERJALAN (for request UI) ================

@bp.route('/api/rat/projection/current')
@safe_db
def current_projection():
    """Return per-product stats bulan berjalan untuk dipakai di Buat Permintaan UI.

    Output per produk: usage 7 hari lalu, proyeksi bulanan (kalau ada RAT
    approved), sudah didistribusi bulan ini, sisa proyeksi.

    - Kalau RAT approved ada: semua produk dalam RAT tampil (prioritas).
    - Plus: produk yang tidak ada di RAT tapi punya usage 7 hari juga
      tampil (info mentah, tanpa angka proyeksi).
    - Kalau RAT belum ada sama sekali: cuma usage 7 hari yang muncul.

    Query: ?unit_id=X
    """
    from datetime import timedelta
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return err('unit_id wajib diisi')
    today = date.today()
    year = today.year
    month = today.month
    seven_ago = (today - timedelta(days=7)).isoformat()
    end_iso = today.isoformat()
    mo_prefix = f'{year}-{month:02d}'

    conn = get_db()

    # Usage 7 hari terakhir per produk (untuk unit ini)
    usage_7 = {r['pid']: r['q'] for r in conn.execute("""
        SELECT product_id AS pid, SUM(qty_used) AS q
        FROM usage_log
        WHERE date BETWEEN ? AND ? AND unit_id=?
        GROUP BY product_id
    """, (seven_ago, end_iso, unit_id)).fetchall()}

    # Sudah didistribusi (fulfilled) bulan ini
    distributed = {r['pid']: r['q'] for r in conn.execute("""
        SELECT ri.product_id AS pid, SUM(ri.qty) AS q
        FROM requests r JOIN request_items ri ON ri.request_id=r.id
        WHERE r.status='fulfilled' AND r.unit_id=?
          AND SUBSTR(r.date, 1, 7) = ?
          AND COALESCE(ri.status, 'active') = 'active'
        GROUP BY ri.product_id
    """, (unit_id, mo_prefix)).fetchall()}

    # RAT approved untuk tahun ini (opsional)
    rat = conn.execute("""
        SELECT id FROM annual_projections
        WHERE year=? AND unit_id=? AND status='approved'
    """, (year, unit_id)).fetchone()

    items = []
    seen = set()

    if rat:
        # Baris dari RAT — produk yang punya proyeksi bulan ini
        rows = conn.execute("""
            SELECT ai.product_id, ai.qty AS projected_qty, ai.unit_price,
                   p.name AS product_name, p.uom
            FROM annual_projection_items ai
            JOIN products p ON p.id = ai.product_id
            WHERE ai.projection_id=? AND ai.month=?
        """, (rat['id'], month)).fetchall()
        for p in rows:
            pid = p['product_id']
            seen.add(pid)
            d = distributed.get(pid, 0)
            items.append({
                'product_id': pid,
                'product_name': p['product_name'],
                'uom': p['uom'],
                'usage_last_7d': usage_7.get(pid, 0),
                'projected_qty': p['projected_qty'],
                'already_distributed': d,
                'remaining': max(0, p['projected_qty'] - d),
                'over_projection': max(0, d - p['projected_qty']),
                'unit_price': p['unit_price'],
                'has_rat': True,
            })

    # Tambahkan produk yang punya usage 7 hari tapi bukan dalam RAT —
    # tetap kasih konteks ke unit walaupun belum diproyeksikan.
    for pid, qty in usage_7.items():
        if pid in seen:
            continue
        pr = conn.execute("SELECT name, uom FROM products WHERE id=?", (pid,)).fetchone()
        if not pr:
            continue
        items.append({
            'product_id': pid,
            'product_name': pr['name'],
            'uom': pr['uom'],
            'usage_last_7d': qty,
            'projected_qty': None,
            'already_distributed': distributed.get(pid, 0),
            'remaining': None,
            'over_projection': 0,
            'unit_price': 0,
            'has_rat': False,
        })

    conn.close()
    return jsonify({
        'ok': True,
        'has_projection': bool(rat),
        'year': year, 'month': month,
        'rat_id': rat['id'] if rat else None,
        'items': items,
    })
