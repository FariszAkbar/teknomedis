"""Request routes: unit requests, approve/reject/fulfill, resolve suggested items.

Auth:
- Create request: unit (hanya untuk unit_id sendiri) + admin.
- Approve/reject/fulfill: admin only.
- Resolve suggestion: admin only.

Request dari unit bisa berisi dua jenis item:
  1. Item existing — {product_id, qty}                       status='active'
  2. Item usulan   — {suggested_name, qty, reason, brand}    status='suggested'
Admin lalu resolve (2) jadi (1) dengan bikin produk baru di master, match
ke produk existing, atau tolak. Request dengan item 'suggested' tidak bisa
di-fulfill sampai semua item usulan selesai di-resolve.

Request juga punya flag urgency: 'normal' | 'urgent' — urgent muncul di
atas antrian admin.
"""
from flask import Blueprint, request, jsonify
from datetime import date
from db_manager import get_db, log_audit
from helpers import (gid, safe_db, get_json, role_required, current_user,
                     validate_int, err, ok)

bp = Blueprint('requests', __name__)


def _fmt_request(conn, r):
    items = conn.execute("""
        SELECT ri.id, ri.product_id, ri.qty,
               COALESCE(ri.status, 'active') AS status,
               COALESCE(ri.suggested_name, '')   AS suggested_name,
               COALESCE(ri.suggested_brand, '')  AS suggested_brand,
               COALESCE(ri.suggested_uom, '')    AS suggested_uom,
               COALESCE(ri.suggested_reason, '') AS suggested_reason,
               p.name  AS product_name,
               p.type  AS product_type,
               p.uom   AS product_uom
        FROM request_items ri
        LEFT JOIN products p ON p.id = ri.product_id
        WHERE ri.request_id = ?
        ORDER BY ri.id
    """, (r['id'],)).fetchall()
    rd = dict(r)
    rd['urgency'] = rd.get('urgency') or 'normal'
    rd['items'] = [dict(i) for i in items]
    return rd


@bp.route('/api/requests')
@safe_db
def get_requests():
    unit_id = request.args.get('unit_id')
    urgency = request.args.get('urgency')  # optional filter
    conn = get_db()
    sql = "SELECT * FROM requests"
    args = []
    where = []
    if unit_id:
        where.append("unit_id = ?"); args.append(unit_id)
    if urgency:
        where.append("COALESCE(urgency, 'normal') = ?"); args.append(urgency)
    if where:
        sql += " WHERE " + " AND ".join(where)
    # Urgent first within pending, then by date desc.
    sql += " ORDER BY CASE WHEN COALESCE(urgency,'normal')='urgent' AND status='pending' THEN 0 ELSE 1 END, date DESC"
    rows = conn.execute(sql, args).fetchall()
    result = [_fmt_request(conn, r) for r in rows]
    conn.close()
    return jsonify(result)


@bp.route('/api/requests', methods=['POST'])
@safe_db
@role_required('unit', 'admin')
def create_request():
    """Create a new request. Unit force unit_id = milik session, admin bebas."""
    data = get_json()
    user = current_user() or {}
    unit_id = data.get('unit_id')
    if user.get('role') == 'unit':
        # Unit hanya boleh bikin untuk unit sendiri — tidak bisa impersonate
        if not user.get('unit_id'):
            return err('User unit belum terasosiasi dengan unit — hubungi admin', 403)
        unit_id = user['unit_id']
    if not unit_id:
        return err('unit_id wajib diisi')

    urgency = data.get('urgency', 'normal')
    if urgency not in ('normal', 'urgent'):
        urgency = 'normal'

    items = data.get('items') or []
    if not items or len(items) > 500:
        return err('Minimal 1 item, maksimal 500')

    notes = (data.get('notes') or '')[:500]

    conn = get_db()
    # Validate unit exists
    if not conn.execute("SELECT 1 FROM units WHERE id=?", (unit_id,)).fetchone():
        conn.close(); return err('Unit tidak ditemukan', 404)

    today = date.today()
    prefix = f"REQ-{today.strftime('%Y-%m')}"
    count = conn.execute("SELECT COUNT(*) FROM requests WHERE id LIKE ?", (prefix + '%',)).fetchone()[0]
    rid = f"{prefix}-{count+1:03d}"
    conn.execute(
        "INSERT INTO requests (id, unit_id, status, urgency, date, notes) VALUES (?,?,?,?,?,?)",
        (rid, unit_id, 'pending', urgency, today.isoformat(), notes)
    )

    n_existing = 0
    n_suggested = 0
    for item in items:
        qty = validate_int(item.get('qty', 0), min_val=1, max_val=10**6)
        if qty <= 0:
            continue
        pid = item.get('product_id')
        if pid:
            # Validate product exists
            if not conn.execute("SELECT 1 FROM products WHERE id=?", (pid,)).fetchone():
                continue  # skip invalid product silently
            conn.execute(
                "INSERT INTO request_items (request_id, product_id, qty, status) "
                "VALUES (?,?,?,'active')",
                (rid, pid, qty)
            )
            n_existing += 1
        else:
            name = (item.get('suggested_name') or '').strip()
            if not name:
                continue
            conn.execute(
                "INSERT INTO request_items "
                "(request_id, product_id, qty, status, suggested_name, suggested_brand, suggested_uom, suggested_reason) "
                "VALUES (?, NULL, ?, 'suggested', ?, ?, ?, ?)",
                (rid, qty, name[:150],
                 (item.get('suggested_brand') or '').strip()[:100],
                 (item.get('suggested_uom') or '').strip()[:20],
                 (item.get('suggested_reason') or '').strip()[:300])
            )
            n_suggested += 1

    if n_existing == 0 and n_suggested == 0:
        conn.rollback()
        conn.close()
        return err('Tidak ada item valid')

    log_audit(conn, user.get('display_name', ''), 'CREATE_REQUEST', 'requests', rid,
              f'unit={unit_id} urgency={urgency} items={n_existing}+{n_suggested}suggested')
    conn.commit()
    conn.close()
    return jsonify({'ok': True, 'id': rid, 'items_existing': n_existing, 'items_suggested': n_suggested})


@bp.route('/api/requests/<rid>/approve', methods=['POST'])
@safe_db
@role_required('admin')
def approve_request(rid):
    conn = get_db()
    # Can't approve if any suggested item is still unresolved.
    unresolved = conn.execute(
        "SELECT COUNT(*) FROM request_items WHERE request_id=? AND status='suggested'", (rid,)
    ).fetchone()[0]
    if unresolved:
        conn.close()
        return err(f'{unresolved} item usulan belum di-resolve. '
                   'Buat produk baru / match ke existing / tolak dulu.')
    active_items = conn.execute(
        "SELECT COUNT(*) FROM request_items WHERE request_id=? AND COALESCE(status,'active') = 'active'",
        (rid,)
    ).fetchone()[0]
    if active_items == 0:
        conn.close()
        return err('Semua item ditolak, tidak bisa disetujui')
    # Atomic: only move pending → approved (guard race with reject)
    r = conn.execute("UPDATE requests SET status='approved' WHERE id=? AND status='pending'", (rid,))
    if r.rowcount == 0:
        conn.close()
        return err('Request tidak dalam status pending (mungkin sudah di-approve/reject)')
    log_audit(conn, (current_user() or {}).get('display_name', ''),
              'APPROVE_REQUEST', 'requests', rid, '')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/<rid>/reject', methods=['POST'])
@safe_db
@role_required('admin')
def reject_request(rid):
    conn = get_db()
    r = conn.execute("UPDATE requests SET status='rejected' WHERE id=? AND status='pending'", (rid,))
    if r.rowcount == 0:
        conn.close()
        return err('Request tidak dalam status pending')
    log_audit(conn, (current_user() or {}).get('display_name', ''),
              'REJECT_REQUEST', 'requests', rid, '')
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/item/<int:item_id>/reject', methods=['POST'])
@safe_db
@role_required('admin')
def reject_request_item(item_id):
    """Reject a single item in a request."""
    conn = get_db()
    item = conn.execute("SELECT * FROM request_items WHERE id=?", (item_id,)).fetchone()
    if not item:
        conn.close()
        return err('Item tidak ditemukan', 404)

    conn.execute("UPDATE request_items SET status='rejected' WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


@bp.route('/api/requests/item/<int:item_id>/restore', methods=['POST'])
@safe_db
@role_required('admin')
def restore_request_item(item_id):
    """Restore a rejected item to active."""
    conn = get_db()
    conn.execute("UPDATE request_items SET status='active' WHERE id=?", (item_id,))
    conn.commit()
    conn.close()
    return jsonify({'ok': True})


# ==================== SUGGESTED PRODUCT RESOLUTION ====================

@bp.route('/api/requests/item/<int:item_id>/resolve', methods=['POST'])
@safe_db
@role_required('admin')
def resolve_suggested_item(item_id):
    """Admin resolves a suggested item. Three modes:

    { "mode": "create", "name": "...", "category": "...", "type": "ATK|RTK",
      "uom": "Pcs", "default_vendor_id": "...", "default_price": 0 }
        -> create new product in master, link item to it, status='active'

    { "mode": "match", "product_id": "..." }
        -> item already exists in master under a different name;
           link to existing product, status='active'

    { "mode": "reject" }
        -> admin rejects the suggestion, status='rejected'
    """
    data = get_json()
    mode = data.get('mode', '')
    conn = get_db()
    item = conn.execute("SELECT * FROM request_items WHERE id=?", (item_id,)).fetchone()
    if not item:
        conn.close()
        return err('Item tidak ditemukan', 404)
    if item['status'] != 'suggested':
        conn.close()
        return err('Item bukan usulan baru')

    actor = (current_user() or {}).get('display_name', '')

    if mode == 'create':
        name = (data.get('name') or item['suggested_name'] or '').strip()
        if not name or len(name) > 200:
            conn.close()
            return err('Nama produk wajib (max 200 karakter)')
        category = (data.get('category') or 'Lainnya').strip()[:50]
        ptype = data.get('type', 'ATK')
        if ptype not in ('ATK', 'RTK'):
            ptype = 'ATK'
        uom = (data.get('uom') or item['suggested_uom'] or 'Pcs').strip()[:20]
        pid = gid()
        conn.execute(
            "INSERT INTO products (id, name, category, type, uom) VALUES (?,?,?,?,?)",
            (pid, name[:200], category, ptype, uom)
        )
        vendor_id = data.get('default_vendor_id')
        price = validate_int(data.get('default_price', 0), min_val=0, max_val=10**9)
        if vendor_id and price > 0:
            # Validate vendor exists
            if conn.execute("SELECT 1 FROM vendors WHERE id=?", (vendor_id,)).fetchone():
                conn.execute(
                    "INSERT INTO vendor_prices (id, product_id, vendor_id, price, is_default) "
                    "VALUES (?,?,?,?,1)",
                    (gid(), pid, vendor_id, price)
                )
        conn.execute(
            "UPDATE request_items SET product_id=?, status='active' WHERE id=?",
            (pid, item_id)
        )
        log_audit(conn, actor, 'RESOLVE_SUGGESTION_CREATE', 'products', pid,
                  f'Dari usulan: {name} (item_id={item_id})')
        conn.commit()
        conn.close()
        return jsonify({'ok': True, 'mode': 'create', 'product_id': pid, 'name': name})

    if mode == 'match':
        pid = data.get('product_id')
        if not pid:
            conn.close()
            return err('product_id wajib diisi untuk match')
        if not conn.execute("SELECT id FROM products WHERE id=?", (pid,)).fetchone():
            conn.close()
            return err('Produk master tidak ditemukan', 404)
        conn.execute(
            "UPDATE request_items SET product_id=?, status='active' WHERE id=?",
            (pid, item_id)
        )
        log_audit(conn, actor, 'RESOLVE_SUGGESTION_MATCH', 'request_items', str(item_id),
                  f'Matched ke {pid}')
        conn.commit()
        conn.close()
        return jsonify({'ok': True, 'mode': 'match', 'product_id': pid})

    if mode == 'reject':
        conn.execute("UPDATE request_items SET status='rejected' WHERE id=?", (item_id,))
        log_audit(conn, actor, 'RESOLVE_SUGGESTION_REJECT', 'request_items', str(item_id), '')
        conn.commit()
        conn.close()
        return jsonify({'ok': True, 'mode': 'reject'})

    conn.close()
    return err('Mode tidak valid (create|match|reject)')


@bp.route('/api/requests/suggested')
@safe_db
def list_suggested_items():
    """Admin dashboard view: all pending suggestion items across all requests."""
    conn = get_db()
    rows = conn.execute("""
        SELECT ri.id, ri.request_id, ri.qty,
               ri.suggested_name, ri.suggested_brand,
               ri.suggested_uom, ri.suggested_reason,
               r.unit_id, r.date, r.urgency,
               u.name AS unit_name
        FROM request_items ri
        JOIN requests r ON r.id = ri.request_id
        LEFT JOIN units u ON u.id = r.unit_id
        WHERE ri.status = 'suggested'
        ORDER BY r.date DESC, ri.id
    """).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


# ==================== FULFILL ====================

@bp.route('/api/requests/<rid>/fulfill', methods=['POST'])
@safe_db
@role_required('admin')
def fulfill_request(rid):
    """Admin kirim barang ke unit.

    Atomic: BEGIN IMMEDIATE lock supaya concurrent fulfill tidak double-deduct
    warehouse. Status transition dari 'approved' → 'fulfilled' pakai atomic
    UPDATE with status guard.

    Warehouse design: allowed to go negative (backlog — next purchase order
    akan isi ulang). Tapi kalau admin mau strict mode, bisa di-enforce via
    CHECK constraint di schema (commented untuk flexibility).
    """
    conn = get_db()
    req = conn.execute("SELECT * FROM requests WHERE id=?", (rid,)).fetchone()
    if not req:
        conn.close()
        return err('Not found', 404)
    if req['status'] not in ('approved',):
        conn.close()
        return err(f'Request harus status approved (sekarang: {req["status"]})')

    items = conn.execute(
        "SELECT * FROM request_items WHERE request_id=? AND COALESCE(status,'active') = 'active'",
        (rid,)
    ).fetchall()
    if not items:
        conn.close()
        return err('Tidak ada item aktif untuk dipenuhi')

    try:
        conn.execute('BEGIN IMMEDIATE')
        for it in items:
            pid = it['product_id']
            qty = it['qty']
            # Auto-create warehouse row with negative qty kalau belum ada
            # (konsisten dengan design: warehouse boleh negatif sebagai backlog)
            existing_wh = conn.execute(
                "SELECT id FROM warehouse_stock WHERE product_id=?", (pid,)
            ).fetchone()
            if existing_wh:
                conn.execute("UPDATE warehouse_stock SET qty=qty-? WHERE id=?",
                             (qty, existing_wh['id']))
            else:
                conn.execute(
                    "INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                    (gid(), pid, -qty)
                )
            # Add to unit stock (CHECK(qty>=0) di schema jamin tidak negatif)
            existing = conn.execute(
                "SELECT id FROM stock WHERE unit_id=? AND product_id=?",
                (req['unit_id'], pid)
            ).fetchone()
            if existing:
                conn.execute("UPDATE stock SET qty=qty+? WHERE id=?", (qty, existing['id']))
            else:
                conn.execute(
                    "INSERT INTO stock (id, unit_id, product_id, qty) VALUES (?,?,?,?)",
                    (gid(), req['unit_id'], pid, qty)
                )

        # Atomic status transition — guard against double-fulfill race
        r = conn.execute(
            "UPDATE requests SET status='fulfilled' WHERE id=? AND status='approved'",
            (rid,)
        )
        if r.rowcount == 0:
            conn.rollback()
            conn.close()
            return err('Request sudah di-fulfill atau status berubah')
        log_audit(conn, (current_user() or {}).get('display_name', ''),
                  'FULFILL', 'requests', rid, f'Unit: {req["unit_id"]}')
        conn.commit()
    except Exception:
        conn.rollback()
        conn.close()
        raise
    conn.close()
    return jsonify({'ok': True})
