"""Unit-scoped reports + weekly aggregation.

Endpoints yang dipakai per role:

Admin (semua unit digabung):
  GET  /api/report/weekly?month=YYYY-MM          ringkasan mingguan JSON
  GET  /api/report/weekly/download               Excel download

Unit (scope unit yang login):
  GET  /api/unit-report/weekly?unit_id=&month=   mingguan unit tertentu
  GET  /api/unit-report/monthly?unit_id=&year=   bulanan unit tertentu (12 bulan)
  GET  /api/unit-report/yearly?unit_id=&year=    akumulasi tahun berjalan
  GET  /api/unit-report/rat-next?unit_id=&year=  RAT tahun depan (prediksi)
  + semua endpoint di atas punya varian /download yang return Excel

Semua perhitungan berbasis `usage_log` + `requests/fulfilled` distribution.
Kalau unit belum punya data → return rows kosong (UI kasih empty state).
"""
from flask import Blueprint, request, jsonify, send_file
from datetime import date, datetime, timedelta
import io
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from db_manager import get_db
from helpers import safe_db, get_clinic_name

bp = Blueprint('unit_report', __name__)


# ==================== HELPERS ====================

def _parse_month(s, default=None):
    """YYYY-MM -> (year, month) or default."""
    if s and len(s) == 7 and s[4] == '-':
        try:
            return int(s[:4]), int(s[5:])
        except ValueError:
            pass
    d = default or date.today()
    return d.year, d.month


def _weeks_in_month(year, month):
    """Return list of (week_label, start_date, end_date) covering the given month.

    ISO weeks with a friendly Indonesian label. Weeks are capped to the
    month's boundaries so the first/last week label reflects that.
    """
    from calendar import monthrange
    last = monthrange(year, month)[1]
    weeks = []
    d = date(year, month, 1)
    while d.month == month:
        # Find Monday of current ISO week (or just use d)
        start = d
        end = d + timedelta(days=6 - d.weekday())
        if end.month != month or end.day > last:
            end = date(year, month, last)
        weeks.append((
            f"Minggu {len(weeks)+1} ({start.strftime('%d')}-{end.strftime('%d')} {_month_id(month)})",
            start, end,
        ))
        d = end + timedelta(days=1)
    return weeks


_MONTH_ID = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
             'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des']
def _month_id(m):
    return _MONTH_ID[m] if 1 <= m <= 12 else str(m)


def _excel_header(ws, title, subtitle=''):
    ws['A1'] = get_clinic_name()
    ws['A1'].font = Font(size=14, bold=True)
    ws.merge_cells('A1:F1')
    ws['A2'] = title
    ws['A2'].font = Font(size=12, bold=True, color='0891B2')
    ws.merge_cells('A2:F2')
    if subtitle:
        ws['A3'] = subtitle
        ws['A3'].font = Font(size=10, italic=True, color='64748B')
        ws.merge_cells('A3:F3')
    ws['A1'].alignment = ws['A2'].alignment = Alignment(horizontal='center')
    if subtitle:
        ws['A3'].alignment = Alignment(horizontal='center')


_TH_FILL = PatternFill('solid', fgColor='0D2137')
_TH_FONT = Font(color='FFFFFF', bold=True)
_BORDER = Border(left=Side('thin'), right=Side('thin'),
                 top=Side('thin'), bottom=Side('thin'))


def _write_table_row(ws, row_idx, values, header=False):
    for col_idx, v in enumerate(values, start=1):
        c = ws.cell(row=row_idx, column=col_idx, value=v)
        c.border = _BORDER
        if header:
            c.fill = _TH_FILL
            c.font = _TH_FONT
            c.alignment = Alignment(horizontal='center', vertical='center')


# ==================== ADMIN WEEKLY ====================

@bp.route('/api/report/weekly')
@safe_db
def admin_weekly_report():
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    year, m = _parse_month(month)
    weeks = _weeks_in_month(year, m)
    conn = get_db()

    # For each week: purchases ordered, distribution fulfilled, usage
    data = []
    for label, ws_start, ws_end in weeks:
        s, e = ws_start.isoformat(), ws_end.isoformat()
        row = {'week': label, 'start': s, 'end': e}
        row['spent'] = conn.execute(
            "SELECT COALESCE(SUM(total),0) FROM purchases "
            "WHERE date BETWEEN ? AND ? AND status='ordered'", (s, e)
        ).fetchone()[0]
        row['distributed_qty'] = conn.execute(
            "SELECT COALESCE(SUM(ri.qty),0) FROM requests r "
            "JOIN request_items ri ON ri.request_id=r.id "
            "WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled' "
            "AND COALESCE(ri.status,'active')='active'", (s, e)
        ).fetchone()[0]
        row['usage_qty'] = conn.execute(
            "SELECT COALESCE(SUM(qty_used),0) FROM usage_log WHERE date BETWEEN ? AND ?",
            (s, e)
        ).fetchone()[0]
        row['requests_count'] = conn.execute(
            "SELECT COUNT(*) FROM requests WHERE date BETWEEN ? AND ?", (s, e)
        ).fetchone()[0]
        data.append(row)

    # Top 10 products by qty distributed in the month (+ estimated cost
    # pakai default vendor_price — proxy biaya distribusi)
    top_products = conn.execute("""
        SELECT p.id, p.name, p.uom, p.type,
               COALESCE(SUM(ri.qty),0) AS total_qty,
               COALESCE(SUM(ri.qty) *
                 (SELECT price FROM vendor_prices vp
                  WHERE vp.product_id=p.id
                  ORDER BY is_default DESC LIMIT 1), 0) AS total_cost
        FROM requests r
        JOIN request_items ri ON ri.request_id = r.id
        JOIN products p ON p.id = ri.product_id
        WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled'
        AND COALESCE(ri.status,'active')='active'
        GROUP BY p.id, p.name, p.uom, p.type
        ORDER BY total_qty DESC LIMIT 10
    """, (f'{year}-{m:02d}-01', f'{year}-{m:02d}-31')).fetchall()

    conn.close()
    return jsonify({
        'ok': True, 'month': month,
        'weeks': data,
        'top_products': [dict(r) for r in top_products],
    })


@bp.route('/api/report/weekly/download')
@safe_db
def admin_weekly_download():
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    year, m = _parse_month(month)
    weeks = _weeks_in_month(year, m)
    conn = get_db()

    wb = Workbook()
    ws = wb.active
    ws.title = 'Ringkasan Mingguan'
    _excel_header(ws, f'Laporan Mingguan — {_month_id(m)} {year}',
                  'Rekap pengeluaran, distribusi, dan pemakaian per minggu')
    header = ['Minggu', 'Periode', 'Pengeluaran (Rp)',
              'Qty Didistribusi', 'Qty Dipakai', 'Jumlah Request']
    _write_table_row(ws, 5, header, header=True)
    row_idx = 6
    for label, s_date, e_date in weeks:
        s, e = s_date.isoformat(), e_date.isoformat()
        spent = conn.execute("SELECT COALESCE(SUM(total),0) FROM purchases "
                             "WHERE date BETWEEN ? AND ? AND status='ordered'",
                             (s, e)).fetchone()[0]
        dist = conn.execute("SELECT COALESCE(SUM(ri.qty),0) FROM requests r "
                            "JOIN request_items ri ON ri.request_id=r.id "
                            "WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled' "
                            "AND COALESCE(ri.status,'active')='active'",
                            (s, e)).fetchone()[0]
        usage = conn.execute("SELECT COALESCE(SUM(qty_used),0) FROM usage_log "
                             "WHERE date BETWEEN ? AND ?", (s, e)).fetchone()[0]
        rcount = conn.execute("SELECT COUNT(*) FROM requests "
                              "WHERE date BETWEEN ? AND ?", (s, e)).fetchone()[0]
        _write_table_row(ws, row_idx, [label, f'{s} s.d. {e}', spent, dist, usage, rcount])
        row_idx += 1

    for col, w in enumerate([20, 28, 18, 18, 18, 18], start=1):
        ws.column_dimensions[chr(64 + col)].width = w
    conn.close()

    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return send_file(buf,
                     as_attachment=True,
                     download_name=f'Laporan-Mingguan-{month}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ==================== UNIT WEEKLY ====================

@bp.route('/api/unit-report/weekly')
@safe_db
def unit_weekly():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    year, m = _parse_month(month)
    weeks = _weeks_in_month(year, m)
    conn = get_db()

    data = []
    for label, ws_start, ws_end in weeks:
        s, e = ws_start.isoformat(), ws_end.isoformat()
        # Distribution to this unit in this week
        dist = conn.execute("""
            SELECT p.id, p.name, p.uom, p.type, SUM(ri.qty) AS qty
            FROM requests r
            JOIN request_items ri ON ri.request_id = r.id
            JOIN products p ON p.id = ri.product_id
            WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled'
              AND r.unit_id = ? AND COALESCE(ri.status,'active')='active'
            GROUP BY p.id, p.name, p.uom, p.type
            ORDER BY qty DESC
        """, (s, e, unit_id)).fetchall()
        usage = conn.execute("""
            SELECT p.id, p.name, p.uom, p.type, SUM(ul.qty_used) AS qty
            FROM usage_log ul JOIN products p ON p.id = ul.product_id
            WHERE ul.date BETWEEN ? AND ? AND ul.unit_id = ?
            GROUP BY p.id, p.name, p.uom, p.type
            ORDER BY qty DESC
        """, (s, e, unit_id)).fetchall()
        data.append({
            'week': label, 'start': s, 'end': e,
            'distributions': [dict(r) for r in dist],
            'usage':        [dict(r) for r in usage],
        })

    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    conn.close()
    return jsonify({
        'ok': True, 'unit_id': unit_id,
        'unit_name': unit['name'] if unit else '-',
        'month': month, 'weeks': data,
    })


@bp.route('/api/unit-report/weekly/download')
@safe_db
def unit_weekly_download():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    month = request.args.get('month', date.today().strftime('%Y-%m'))
    year, m = _parse_month(month)
    weeks = _weeks_in_month(year, m)
    conn = get_db()
    unit_name = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    unit_name = unit_name['name'] if unit_name else '-'

    wb = Workbook()
    ws = wb.active
    ws.title = 'Mingguan Unit'
    _excel_header(ws, f'Laporan Mingguan — {unit_name}',
                  f'{_month_id(m)} {year}')
    _write_table_row(ws, 5, ['Minggu', 'Produk', 'Kategori', 'Didistribusi', 'Dipakai'], header=True)
    row_idx = 6
    for label, s_date, e_date in weeks:
        s, e = s_date.isoformat(), e_date.isoformat()
        combined = {}
        for r in conn.execute("""
            SELECT p.id, p.name, p.type,
                   SUM(ri.qty) AS qty
            FROM requests r
            JOIN request_items ri ON ri.request_id = r.id
            JOIN products p ON p.id = ri.product_id
            WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled'
              AND r.unit_id = ? AND COALESCE(ri.status,'active')='active'
            GROUP BY p.id, p.name, p.type
        """, (s, e, unit_id)).fetchall():
            combined[r['id']] = [r['name'], r['type'], r['qty'], 0]
        for r in conn.execute("""
            SELECT p.id, p.name, p.type, SUM(ul.qty_used) AS qty
            FROM usage_log ul JOIN products p ON p.id = ul.product_id
            WHERE ul.date BETWEEN ? AND ? AND ul.unit_id = ?
            GROUP BY p.id, p.name, p.type
        """, (s, e, unit_id)).fetchall():
            if r['id'] in combined:
                combined[r['id']][3] = r['qty']
            else:
                combined[r['id']] = [r['name'], r['type'], 0, r['qty']]
        if not combined:
            _write_table_row(ws, row_idx, [label, '—', '—', 0, 0])
            row_idx += 1
            continue
        for pid, (name, ptype, dist, usage) in combined.items():
            _write_table_row(ws, row_idx, [label, name, ptype, dist, usage])
            row_idx += 1

    for col, w in enumerate([28, 36, 12, 16, 16], start=1):
        ws.column_dimensions[chr(64 + col)].width = w
    conn.close()

    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f'Laporan-Mingguan-{unit_name}-{month}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ==================== UNIT MONTHLY (12 bulan tahun X) ====================

@bp.route('/api/unit-report/monthly')
@safe_db
def unit_monthly():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    try:
        year = int(request.args.get('year') or date.today().year)
    except ValueError:
        year = date.today().year
    conn = get_db()

    # For each month 1..12 give distribution + usage totals plus top 5 products
    months = []
    for m in range(1, 13):
        s = f'{year}-{m:02d}-01'
        e = f'{year}-{m:02d}-31'
        dist_total = conn.execute("""
            SELECT COALESCE(SUM(ri.qty),0) FROM requests r
            JOIN request_items ri ON ri.request_id=r.id
            WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled'
              AND r.unit_id=? AND COALESCE(ri.status,'active')='active'
        """, (s, e, unit_id)).fetchone()[0]
        usage_total = conn.execute("""
            SELECT COALESCE(SUM(qty_used),0) FROM usage_log
            WHERE date BETWEEN ? AND ? AND unit_id=?
        """, (s, e, unit_id)).fetchone()[0]
        top = conn.execute("""
            SELECT p.id, p.name, p.uom, SUM(ul.qty_used) AS qty
            FROM usage_log ul JOIN products p ON p.id = ul.product_id
            WHERE ul.date BETWEEN ? AND ? AND ul.unit_id=?
            GROUP BY p.id, p.name, p.uom
            ORDER BY qty DESC LIMIT 5
        """, (s, e, unit_id)).fetchall()
        months.append({
            'month': m, 'month_label': _month_id(m),
            'distributed': dist_total, 'used': usage_total,
            'top_products': [dict(r) for r in top],
        })

    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    conn.close()
    return jsonify({
        'ok': True, 'unit_id': unit_id,
        'unit_name': unit['name'] if unit else '-',
        'year': year, 'months': months,
    })


@bp.route('/api/unit-report/monthly/download')
@safe_db
def unit_monthly_download():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    try:
        year = int(request.args.get('year') or date.today().year)
    except ValueError:
        year = date.today().year
    conn = get_db()
    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    unit_name = unit['name'] if unit else '-'

    wb = Workbook()
    ws = wb.active
    ws.title = 'Bulanan Unit'
    _excel_header(ws, f'Laporan Bulanan — {unit_name}', f'Tahun {year}')
    _write_table_row(ws, 5, ['Bulan', 'Didistribusi (qty)', 'Dipakai (qty)',
                              'Top 1', 'Top 2', 'Top 3'], header=True)
    row_idx = 6
    for m in range(1, 13):
        s, e = f'{year}-{m:02d}-01', f'{year}-{m:02d}-31'
        dist = conn.execute("""
            SELECT COALESCE(SUM(ri.qty),0) FROM requests r
            JOIN request_items ri ON ri.request_id=r.id
            WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled'
              AND r.unit_id=? AND COALESCE(ri.status,'active')='active'
        """, (s, e, unit_id)).fetchone()[0]
        used = conn.execute("""
            SELECT COALESCE(SUM(qty_used),0) FROM usage_log
            WHERE date BETWEEN ? AND ? AND unit_id=?
        """, (s, e, unit_id)).fetchone()[0]
        top = conn.execute("""
            SELECT p.name, SUM(ul.qty_used) AS qty FROM usage_log ul
            JOIN products p ON p.id = ul.product_id
            WHERE ul.date BETWEEN ? AND ? AND ul.unit_id=?
            GROUP BY p.id, p.name ORDER BY qty DESC LIMIT 3
        """, (s, e, unit_id)).fetchall()
        top_names = [f"{t['name']} ({t['qty']})" for t in top] + ['', '', '']
        _write_table_row(ws, row_idx,
                         [_month_id(m), dist, used, top_names[0], top_names[1], top_names[2]])
        row_idx += 1

    for col, w in enumerate([14, 18, 18, 32, 32, 32], start=1):
        ws.column_dimensions[chr(64 + col)].width = w
    conn.close()

    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f'Laporan-Bulanan-{unit_name}-{year}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ==================== UNIT YEARLY (stok opname tahun berjalan) ====================
#
# Format "stok opname" per produk:
#   Stok Awal  : qty di awal periode = stok_saat_ini + dipakai - didistribusi
#   Didistribusi : qty masuk ke unit sepanjang periode (dari gudang)
#   Dipakai    : qty yang dicatat di usage_log
#   Stok Sisa  : qty di DB sekarang (snapshot live)
#
# Bisa negatif kalau unit habiskan stok lama yang tidak tercatat — jadi
# alert yang berguna untuk audit.

def _unit_stock_opname(conn, unit_id, s, e):
    """Return a list of per-product stock-opname rows for one unit across period [s, e]."""
    # Usage
    used = {r['id']: r['used'] for r in conn.execute("""
        SELECT p.id, SUM(ul.qty_used) AS used FROM usage_log ul
        JOIN products p ON p.id = ul.product_id
        WHERE ul.date BETWEEN ? AND ? AND ul.unit_id=?
        GROUP BY p.id
    """, (s, e, unit_id)).fetchall()}
    # Distribution (request_items status='active' di requests status='fulfilled')
    dist = {r['id']: r['dist'] for r in conn.execute("""
        SELECT p.id, SUM(ri.qty) AS dist FROM requests r
        JOIN request_items ri ON ri.request_id=r.id
        JOIN products p ON p.id = ri.product_id
        WHERE r.date BETWEEN ? AND ? AND r.status='fulfilled'
          AND r.unit_id=? AND COALESCE(ri.status,'active')='active'
        GROUP BY p.id
    """, (s, e, unit_id)).fetchall()}
    # Current stock at the unit (all products)
    current = {r['id']: r['qty'] for r in conn.execute("""
        SELECT p.id, COALESCE(s.qty, 0) AS qty
        FROM products p
        LEFT JOIN stock s ON s.product_id = p.id AND s.unit_id = ?
    """, (unit_id,)).fetchall()}
    # Product metadata
    rows = conn.execute("""
        SELECT id, name, uom, type, category FROM products ORDER BY name
    """).fetchall()
    out = []
    for p in rows:
        d = dist.get(p['id'], 0)
        u = used.get(p['id'], 0)
        s_end = current.get(p['id'], 0)
        s_begin = s_end + u - d            # reverse calc
        # Skip rows where everything is zero (produk gak pernah dipakai unit ini)
        if d == 0 and u == 0 and s_end == 0 and s_begin == 0:
            continue
        out.append({
            'id': p['id'], 'name': p['name'], 'uom': p['uom'],
            'type': p['type'], 'category': p['category'],
            'stok_awal': s_begin,
            'didistribusi': d,
            'dipakai': u,
            'stok_sisa': s_end,
        })
    return out


@bp.route('/api/unit-report/yearly')
@safe_db
def unit_yearly():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    try:
        year = int(request.args.get('year') or date.today().year)
    except ValueError:
        year = date.today().year
    conn = get_db()
    s, e = f'{year}-01-01', f'{year}-12-31'
    products = _unit_stock_opname(conn, unit_id, s, e)
    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    conn.close()
    return jsonify({
        'ok': True, 'unit_id': unit_id,
        'unit_name': unit['name'] if unit else '-',
        'year': year,
        'total_stok_awal':   sum(p['stok_awal']   for p in products),
        'total_distribusi':  sum(p['didistribusi'] for p in products),
        'total_dipakai':     sum(p['dipakai']     for p in products),
        'total_stok_sisa':   sum(p['stok_sisa']   for p in products),
        'products': products,
    })


@bp.route('/api/unit-report/yearly/download')
@safe_db
def unit_yearly_download():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    try:
        year = int(request.args.get('year') or date.today().year)
    except ValueError:
        year = date.today().year
    conn = get_db()
    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    unit_name = unit['name'] if unit else '-'
    s, e = f'{year}-01-01', f'{year}-12-31'

    wb = Workbook()
    ws = wb.active
    ws.title = 'Stok Opname'
    _excel_header(ws, f'Stok Opname — {unit_name}', f'Tahun {year}')
    _write_table_row(ws, 5, [
        'No', 'Produk', 'Kategori', 'Jenis', 'UoM',
        'Stok Awal', 'Didistribusi', 'Dipakai', 'Stok Sisa'
    ], header=True)
    products = _unit_stock_opname(conn, unit_id, s, e)
    row_idx = 6
    for i, r in enumerate(products, start=1):
        _write_table_row(ws, row_idx, [
            i, r['name'], r['category'], r['type'], r['uom'],
            r['stok_awal'], r['didistribusi'], r['dipakai'], r['stok_sisa']
        ])
        # Highlight negative stock_sisa in red
        if r['stok_sisa'] < 0:
            ws.cell(row=row_idx, column=9).font = Font(color='B91C1C', bold=True)
        row_idx += 1
    # Totals row
    _write_table_row(ws, row_idx, [
        '', 'TOTAL', '', '', '',
        sum(p['stok_awal']   for p in products),
        sum(p['didistribusi'] for p in products),
        sum(p['dipakai']     for p in products),
        sum(p['stok_sisa']   for p in products),
    ], header=True)

    for col, w in enumerate([6, 36, 20, 10, 10, 14, 14, 14, 14], start=1):
        ws.column_dimensions[chr(64 + col)].width = w
    conn.close()

    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f'Pemakaian-{unit_name}-{year}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


# ==================== UNIT RAT NEXT YEAR ====================

@bp.route('/api/unit-report/rat-next')
@safe_db
def unit_rat_next():
    """RAT tahun depan untuk satu unit — berbasis usage aktual tahun berjalan.

    Metode:
      base_annual = sum(usage_log[unit_id] tahun berjalan sampai hari ini)
      elapsed_months = bulan saat ini
      projected = base_annual / elapsed_months * 12
      next_year_qty = ceil(projected * 1.05)   # +5% antisipasi pertumbuhan

    Return per produk: name, avg_month_used, projected_this_year,
    suggested_next_year_qty.
    """
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    try:
        year = int(request.args.get('year') or date.today().year)
    except ValueError:
        year = date.today().year
    next_year = year + 1
    today = date.today()
    elapsed = today.month if today.year == year else 12
    elapsed = max(1, elapsed)
    conn = get_db()

    s, e = f'{year}-01-01', today.isoformat() if today.year == year else f'{year}-12-31'
    rows = conn.execute("""
        SELECT p.id, p.name, p.uom, p.category, p.type,
               SUM(ul.qty_used) AS used
        FROM usage_log ul JOIN products p ON p.id = ul.product_id
        WHERE ul.date BETWEEN ? AND ? AND ul.unit_id=?
        GROUP BY p.id, p.name, p.uom, p.category, p.type
        ORDER BY used DESC
    """, (s, e, unit_id)).fetchall()

    import math
    items = []
    for r in rows:
        used = r['used'] or 0
        avg_month = used / elapsed
        projected_year = round(avg_month * 12)
        suggested = int(math.ceil(projected_year * 1.05))
        items.append({
            'product_id': r['id'], 'name': r['name'], 'uom': r['uom'],
            'category': r['category'], 'type': r['type'],
            'avg_month_used': round(avg_month, 1),
            'projected_this_year': projected_year,
            'suggested_next_year_qty': suggested,
        })

    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    conn.close()
    return jsonify({
        'ok': True, 'unit_id': unit_id,
        'unit_name': unit['name'] if unit else '-',
        'base_year': year, 'next_year': next_year,
        'elapsed_months': elapsed,
        'items': items,
    })


@bp.route('/api/unit-report/rat-next/download')
@safe_db
def unit_rat_next_download():
    unit_id = request.args.get('unit_id')
    if not unit_id:
        return jsonify({'ok': False, 'error': 'unit_id wajib diisi'}), 400
    try:
        year = int(request.args.get('year') or date.today().year)
    except ValueError:
        year = date.today().year
    next_year = year + 1
    today = date.today()
    elapsed = today.month if today.year == year else 12
    elapsed = max(1, elapsed)
    conn = get_db()
    unit = conn.execute("SELECT name FROM units WHERE id=?", (unit_id,)).fetchone()
    unit_name = unit['name'] if unit else '-'

    wb = Workbook()
    ws = wb.active
    ws.title = f'RAT {next_year}'
    _excel_header(ws, f'RAT {next_year} — {unit_name}',
                  f'Prediksi berbasis pemakaian {year} (elapsed {elapsed} bln, growth +5%)')
    _write_table_row(ws, 5,
        ['No', 'Produk', 'Kategori', 'Jenis', 'UoM',
         'Avg/bulan', f'Proyeksi {year}', f'Usulan {next_year}'], header=True)

    s, e = f'{year}-01-01', today.isoformat() if today.year == year else f'{year}-12-31'
    rows = conn.execute("""
        SELECT p.id, p.name, p.uom, p.category, p.type,
               SUM(ul.qty_used) AS used
        FROM usage_log ul JOIN products p ON p.id = ul.product_id
        WHERE ul.date BETWEEN ? AND ? AND ul.unit_id=?
        GROUP BY p.id, p.name, p.uom, p.category, p.type
        ORDER BY used DESC
    """, (s, e, unit_id)).fetchall()
    import math
    row_idx = 6
    for i, r in enumerate(rows, start=1):
        used = r['used'] or 0
        avg_month = used / elapsed
        projected = round(avg_month * 12)
        suggested = int(math.ceil(projected * 1.05))
        _write_table_row(ws, row_idx,
            [i, r['name'], r['category'], r['type'], r['uom'],
             round(avg_month, 1), projected, suggested])
        row_idx += 1

    for col, w in enumerate([6, 36, 20, 10, 10, 14, 18, 20], start=1):
        ws.column_dimensions[chr(64 + col)].width = w
    conn.close()

    buf = io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f'RAT-{unit_name}-{next_year}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
