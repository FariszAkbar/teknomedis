"""Upload routes: excel upload/download templates.

Security:
- Only admin can upload (audit finding: dulu open to anyone).
- load_workbook dengan data_only=True mencegah formula execution
  (potential exploit via malicious Excel formula di openpyxl).
- File size limit diaplikasi di Flask level (MAX_CONTENT_LENGTH 10MB).
"""
import io
from flask import Blueprint, request, jsonify, send_file
from datetime import date
from openpyxl import Workbook, load_workbook
from db_manager import get_db, log_audit
from helpers import (gid, safe_db, role_required, current_user,
                     validate_int, err)

bp = Blueprint('upload', __name__)

_MAX_ROWS = 5000  # Hard cap baris per upload supaya tidak blok server


@bp.route('/api/template/<ttype>')
@safe_db
def download_template(ttype):
    wb = Workbook()
    ws = wb.active
    if ttype == 'products':
        ws.title = 'Produk'
        ws.append(['Nama Produk', 'Kategori', 'Jenis (ATK/RTK)', 'Satuan'])
        ws.append(['Contoh: Pulpen Hitam', 'Tulis menulis', 'ATK', 'Pcs'])
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 20
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 12
    elif ttype == 'purchase':
        ws.title = 'Pembelian'
        ws.append(['Nama Produk (harus sudah terdaftar)', 'Qty', 'Harga Satuan (Rp)'])
        ws.append(['Pulpen hitam', 100, 2000])
        ws.column_dimensions['A'].width = 35
        ws.column_dimensions['B'].width = 10
        ws.column_dimensions['C'].width = 20
    elif ttype == 'warehouse':
        ws.title = 'Stok Gudang'
        ws.append(['Nama Produk (harus sudah terdaftar)', 'Qty'])
        ws.append(['Pulpen hitam', 50])
        ws.column_dimensions['A'].width = 35
        ws.column_dimensions['B'].width = 10
    else:
        return jsonify({'ok': False, 'error': 'Unknown template'}), 400

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, download_name=f'template_{ttype}.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@bp.route('/api/upload/<utype>', methods=['POST'])
@safe_db
@role_required('admin')
def upload_excel(utype):
    if utype not in ('products', 'purchase', 'warehouse'):
        return err('Unknown upload type')
    if 'file' not in request.files:
        return err('No file uploaded')
    f = request.files['file']
    if not f.filename or not f.filename.lower().endswith(('.xlsx', '.xls')):
        return err('File harus format Excel (.xlsx / .xls)')

    # data_only=True: skip formula evaluation, pakai cached values saja.
    # Mencegah exploit via malicious formula (openpyxl CVEs) + lebih cepat.
    try:
        wb = load_workbook(f, data_only=True, read_only=True)
    except Exception as e:
        return err(f'File Excel tidak valid atau rusak: {str(e)[:100]}')
    ws = wb.active
    if ws.max_row > _MAX_ROWS:
        return err(f'Upload terlalu besar (max {_MAX_ROWS} baris)')

    conn = get_db()
    count = 0
    errors = []
    actor = (current_user() or {}).get('display_name', '')

    def _safe_int(val, default=0):
        try:
            return int(float(val)) if val is not None else default
        except (ValueError, TypeError):
            return default

    try:
        if utype == 'products':
            for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
                if not row or not row[0] or str(row[0]).startswith('Contoh'):
                    continue
                name = str(row[0]).strip()[:200]
                if not name:
                    continue
                cat = (str(row[1]).strip()[:50] if row[1] else 'Lainnya')
                ptype = (str(row[2]).strip().upper() if row[2] else 'ATK')
                uom = (str(row[3]).strip()[:20] if row[3] else 'Pcs')
                if ptype not in ('ATK', 'RTK'):
                    ptype = 'ATK'
                existing = conn.execute("SELECT id FROM products WHERE name=?", (name,)).fetchone()
                if existing:
                    conn.execute("UPDATE products SET category=?, type=?, uom=? WHERE id=?",
                                 (cat, ptype, uom, existing['id']))
                else:
                    conn.execute("INSERT INTO products (id, name, category, type, uom) VALUES (?,?,?,?,?)",
                                 (gid(), name, cat, ptype, uom))
                count += 1

        elif utype == 'purchase':
            vendor_id = request.form.get('vendor_id')
            # Validate vendor (sebelumnya tidak di-cek — FK fail pada insert)
            if vendor_id and not conn.execute("SELECT 1 FROM vendors WHERE id=?", (vendor_id,)).fetchone():
                conn.close()
                return err('Vendor tidak ditemukan')
            purchase_id = gid()
            total = 0
            items_added = 0
            for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
                if not row or not row[0] or str(row[0]).startswith('Contoh'):
                    continue
                name = str(row[0]).strip()
                qty = _safe_int(row[1] if len(row) > 1 else 0)
                price = _safe_int(row[2] if len(row) > 2 else 0)
                if qty <= 0 or qty > 10**6:
                    errors.append(f'Baris {i}: qty invalid ({qty})')
                    continue
                if price < 0 or price > 10**9:
                    errors.append(f'Baris {i}: harga invalid ({price})')
                    continue
                prod = conn.execute("SELECT id FROM products WHERE name=?", (name,)).fetchone()
                if not prod:
                    errors.append(f'Baris {i}: produk "{name[:50]}" tidak ditemukan')
                    continue
                total += qty * price
                conn.execute("INSERT INTO purchase_items (purchase_id, product_id, qty, price, vendor_id) VALUES (?,?,?,?,?)",
                             (purchase_id, prod['id'], qty, price, vendor_id))
                ws_row = conn.execute("SELECT id FROM warehouse_stock WHERE product_id=?",
                                     (prod['id'],)).fetchone()
                if ws_row:
                    conn.execute("UPDATE warehouse_stock SET qty=qty+? WHERE id=?", (qty, ws_row['id']))
                else:
                    conn.execute("INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                                 (gid(), prod['id'], qty))
                items_added += 1
            if items_added > 0:
                conn.execute(
                    "INSERT INTO purchases (id, date, vendor_id, notes, total, status) VALUES (?,?,?,?,?,'ordered')",
                    (purchase_id, date.today().isoformat(), vendor_id, 'Upload Excel', total)
                )
                log_audit(conn, actor, 'UPLOAD_PURCHASE', 'purchases', purchase_id,
                          f'{items_added} items · total {total}')
            count = items_added

        elif utype == 'warehouse':
            for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
                if not row or not row[0] or str(row[0]).startswith('Contoh'):
                    continue
                name = str(row[0]).strip()
                qty = _safe_int(row[1] if len(row) > 1 else 0)
                if qty < 0 or qty > 10**7:
                    errors.append(f'Baris {i}: qty invalid ({qty})')
                    continue
                prod = conn.execute("SELECT id FROM products WHERE name=?", (name,)).fetchone()
                if not prod:
                    errors.append(f'Baris {i}: produk "{name[:50]}" tidak ditemukan')
                    continue
                ws_row = conn.execute("SELECT id FROM warehouse_stock WHERE product_id=?",
                                     (prod['id'],)).fetchone()
                if ws_row:
                    conn.execute("UPDATE warehouse_stock SET qty=? WHERE id=?", (qty, ws_row['id']))
                else:
                    conn.execute("INSERT INTO warehouse_stock (id, product_id, qty) VALUES (?,?,?)",
                                 (gid(), prod['id'], qty))
                count += 1

        conn.commit()
    except Exception:
        conn.rollback()
        conn.close()
        raise
    conn.close()
    return jsonify({'ok': True, 'count': count, 'errors': errors[:50]})
