@echo off
cd /d "%~dp0"
title MedOps Pro - Server
echo ==========================================
echo   MedOps Pro - Server Running
echo ==========================================
echo.
echo   Buka browser: http://localhost:8060
echo   Tekan Ctrl+C untuk stop server
echo.
echo ==========================================
python app.py
pause
