# TeknoMedis Hub

Local product launcher & licensing portal for TeknoMedis clinic software
(MedOps Pro, CaseMix Pro, UnitCost Pro, and future products).

Installs on the clinic's PC. Fetches the product catalog from the central
license server, handles one-time Midtrans Snap payments, caches active
licenses locally (HWID-bound), and launches installed products.

## Architecture

```
[teknomedis.com]            ← public landing (marketing, download installer)
        │
        ▼
[TeknoMedis Hub :8050]      ← this repo, runs on clinic PC
        │  catalog, payment, activation
        ▼
[license server :8061]      ← central VPS (teknomedis-license repo)
        │  Midtrans + license key generation
        ▼
[installed products]        ← MedOps :8060, UnitCost :8080, ...
```

## Stack

- Python 3.12, Flask, Flask-CORS
- SQLite (local `data/hub.db`)
- Midtrans Snap.js for payment
- Vanilla HTML/CSS/JS frontend — no build step

## Directory layout

```
teknomedis-hub/
├── app.py            Flask entry, port 8050
├── hub_manager.py    SQLite wrapper (orders, licenses, installed products)
├── hwid.py           Hardware ID (must match products)
├── index.html        SPA UI (catalog, licenses, orders)
├── requirements.txt
├── start.sh
├── .env              license server URL, port (NOT committed)
└── data/
    └── hub.db        local state
```

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env    # then edit
./start.sh
```

Open `http://localhost:8050`.

## Environment

```
LICENSE_SERVER=https://teknomedis.com
HUB_PORT=8050
```

## API

Public endpoints consumed by the SPA:

| Method | Path | Purpose |
|---|---|---|
| `GET`  | `/api/hwid` | machine hardware ID |
| `GET`  | `/api/catalog` | product catalog (cached from license server) |
| `GET`  | `/api/midtrans/client-key` | Snap client key |
| `POST` | `/api/order/create` | create order + Snap token |
| `GET`  | `/api/order/<id>/status` | poll order status; auto-saves license when paid |
| `GET`  | `/api/orders` | local order history |
| `GET`  | `/api/machine/licenses` | active licenses on this PC |
| `GET`  | `/api/machine/installed` | installed products (auto-detected) |
| `GET`  | `/api/launch/<code>` | launch URL for an installed product |
| `GET`  | `/payment/success` | Midtrans redirect landing |
| `GET`  | `/payment/error` | Midtrans redirect landing |
| `GET`  | `/payment/unfinish` | Midtrans redirect landing |

## License model

- HWID-bound: license key encodes the hardware ID at purchase time
- Per-product expiry: each product has its own `expires_at`
- Multi-product: hub can manage several licenses independently
- Offline-capable: license cached locally; grace period enforced by each product

## Related repos

- [teknomedis](https://github.com/FariszAkbar/teknomedis) — public landing page
- [teknomedis-license](https://github.com/FariszAkbar/teknomedis-license) — license + payment server
- [medops-pro](https://github.com/FariszAkbar/medops-pro) — product
- [unitcost-pro](https://github.com/FariszAkbar/unitcost-pro) — product
