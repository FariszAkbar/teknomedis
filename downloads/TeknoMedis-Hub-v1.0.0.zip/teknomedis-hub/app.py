"""TeknoMedis Hub — local product launcher + purchase UI.

Runs on the clinic's PC (port 8050). Fetches product catalog from the
license server, handles Midtrans Snap payment, caches active licenses,
and launches installed products.
"""
from flask import Flask, request, jsonify, send_from_directory, render_template_string
from flask_cors import CORS
from dotenv import load_dotenv
from datetime import datetime, timezone
import os
import logging
import requests

import hub_manager as hm
from hwid import get_hardware_id, format_hwid

load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

LICENSE_SERVER = os.environ.get('LICENSE_SERVER', 'https://teknomedis.com').rstrip('/')
HUB_PORT = int(os.environ.get('HUB_PORT', 8050))

app = Flask(__name__, static_folder='static', static_url_path='/static')
CORS(app)
logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger('hub')

_catalog_cache = {'data': None, 'ts': 0}
_CATALOG_TTL = 15  # 15 seconds — balance freshness vs server load


# ==================== CATALOG ====================
@app.route('/api/catalog')
def api_catalog():
    """Return catalog (cached 5 min). Falls back to cached copy if license server is down."""
    import time
    now = time.time()
    if _catalog_cache['data'] and (now - _catalog_cache['ts']) < _CATALOG_TTL:
        return jsonify(_catalog_cache['data'])
    try:
        r = requests.get(f'{LICENSE_SERVER}/api/catalog', timeout=8)
        data = r.json()
        _catalog_cache['data'] = data
        _catalog_cache['ts'] = now
        return jsonify(data)
    except Exception as e:
        log.warning(f'catalog fetch failed: {e}')
        if _catalog_cache['data']:
            return jsonify({**_catalog_cache['data'], 'stale': True})
        return jsonify({'ok': False, 'error': 'Server katalog tidak dapat dihubungi'}), 502


# ==================== MACHINE INFO ====================
@app.route('/api/hwid')
def api_hwid():
    hwid = get_hardware_id()
    return jsonify({'ok': True, 'hwid': hwid, 'formatted': format_hwid(hwid)})


@app.route('/api/midtrans/client-key')
def api_midtrans_client_key():
    try:
        r = requests.get(f'{LICENSE_SERVER}/api/midtrans/client-key', timeout=5)
        return jsonify(r.json())
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 502


# ==================== ORDER / PAYMENT ====================
@app.route('/api/order/create', methods=['POST'])
def api_order_create():
    data = request.get_json(silent=True) or {}
    clinic = (data.get('clinic') or '').strip()
    email = (data.get('email') or '').strip()
    phone = (data.get('phone') or '').strip()
    product = data.get('product', '')
    package_id = data.get('package_id', '')
    if not clinic or not email or '@' not in email:
        return jsonify({'ok': False, 'error': 'Nama klinik dan email wajib diisi'}), 400
    if not product or not package_id:
        return jsonify({'ok': False, 'error': 'Produk/paket belum dipilih'}), 400

    payload = {
        'hwid': get_hardware_id(),
        'clinic': clinic, 'email': email, 'phone': phone,
        'product': product, 'package_id': package_id,
    }
    try:
        r = requests.post(f'{LICENSE_SERVER}/api/order/create', json=payload, timeout=15)
        resp = r.json()
    except Exception as e:
        log.exception('order create failed')
        return jsonify({'ok': False, 'error': f'Gagal hubungi server: {e}'}), 502
    if not resp.get('ok'):
        return jsonify(resp), 400

    hm.save_order({
        'order_id': resp['order_id'],
        'req_id': resp.get('req_id', ''),
        'product_code': product,
        'package_id': package_id,
        'package_name': resp.get('package_name', ''),
        'amount': resp.get('amount', 0),
        'snap_token': resp.get('snap_token', ''),
        'redirect_url': resp.get('redirect_url', ''),
        'clinic': clinic, 'email': email, 'phone': phone,
    })
    # Cache the per-PC activation token so /api/machine/sync can later call
    # the protected /api/licenses/by-hwid endpoint without re-prompting.
    token = resp.get('activation_token', '')
    if token:
        hm.save_activation_token(get_hardware_id(), token)
    log.info(f"Order created: {resp['order_id']} ({resp.get('product_name')} / {clinic})")
    # Don't echo the token back to the browser — it's a server-side cache only.
    resp.pop('activation_token', None)
    return jsonify(resp)


@app.route('/api/order/<order_id>/status')
def api_order_status(order_id):
    """Proxy + sync: poll license server, cache result, auto-save license on paid."""
    try:
        r = requests.get(f'{LICENSE_SERVER}/api/order/{order_id}/status', timeout=8)
        remote = r.json()
    except Exception as e:
        local = hm.get_order(order_id)
        if local:
            return jsonify({
                'ok': True, 'order_id': order_id,
                'status': local['status'],
                'transaction_status': local.get('transaction_status', ''),
                'paid': local['status'] == 'confirmed',
                'offline': True,
            })
        return jsonify({'ok': False, 'error': f'Tidak bisa cek status: {e}'}), 502

    if not remote.get('ok'):
        return jsonify(remote), 404

    local = hm.get_order(order_id)
    if local:
        hm.update_order_status(
            order_id,
            status=remote.get('status', local['status']),
            transaction_status=remote.get('transaction_status', ''),
            paid_at=hm.now() if remote.get('paid') else None,
        )
        if remote.get('paid') and remote.get('license_key'):
            existing = hm.get_license(local['product_code'])
            if not existing or existing.get('license_key') != remote['license_key']:
                hm.save_license(local['product_code'], {
                    'license_key': remote['license_key'],
                    'clinic': remote.get('clinic') or local['clinic'],
                    'hwid': get_hardware_id(),
                    'plan': remote.get('plan', ''),
                    'days': remote.get('days', 0),
                    'expires_at': remote.get('expires', ''),
                    'activated_at': remote.get('issued') or hm.now(),
                    'status': 'active',
                    'order_id': order_id,
                })
                log.info(f"License activated locally: {local['product_code']} "
                         f"plan={remote.get('plan')} expires={remote.get('expires')} "
                         f"(order {order_id})")
    return jsonify(remote)


@app.route('/api/orders')
def api_orders():
    return jsonify({'ok': True, 'orders': hm.list_orders(50)})


# ==================== MACHINE LICENSES ====================
@app.route('/api/machine/licenses')
def api_machine_licenses():
    return jsonify({'ok': True, 'licenses': hm.list_licenses()})


@app.route('/api/machine/sync', methods=['POST'])
def api_machine_sync():
    """Pull all licenses from the central server for this PC's HWID.

    Requires a cached activation token. If not present (fresh hub install on
    a PC that already has licenses), the user must supply {order_id, email}
    in the POST body so the server can re-issue the token.
    """
    hwid = get_hardware_id()
    token = hm.get_activation_token(hwid)
    if not token:
        body = request.get_json(silent=True) or {}
        order_id = (body.get('order_id') or '').strip()
        email = (body.get('email') or '').strip()
        if not order_id or not email:
            return jsonify({
                'ok': False,
                'need_bootstrap': True,
                'error': 'Belum ada activation token untuk PC ini. '
                         'Kirim {order_id, email} dari email lisensi untuk setup pertama.',
            }), 401
        try:
            br = requests.post(
                f'{LICENSE_SERVER}/api/activation-token',
                json={'order_id': order_id, 'email': email},
                timeout=10,
            )
            boot = br.json()
        except Exception as e:
            return jsonify({'ok': False, 'error': f'Tidak bisa setup token: {e}'}), 502
        if not boot.get('ok'):
            return jsonify(boot), 400
        token = boot['token']
        hm.save_activation_token(hwid, token)

    try:
        r = requests.get(
            f'{LICENSE_SERVER}/api/licenses/by-hwid/{hwid}',
            headers={'X-Activation-Token': token},
            timeout=10,
        )
        resp = r.json()
    except Exception as e:
        return jsonify({'ok': False, 'error': f'Tidak bisa sinkron: {e}'}), 502
    if not resp.get('ok'):
        return jsonify(resp), 400

    imported = 0
    for lic in resp.get('licenses', []):
        code = lic['product']
        existing = hm.get_license(code)
        if existing and existing.get('license_key') == lic['license_key']:
            continue
        hm.save_license(code, {
            'license_key': lic['license_key'],
            'clinic': lic.get('clinic', ''),
            'hwid': hwid,
            'plan': lic.get('plan', ''),
            'days': lic.get('days', 0),
            'expires_at': lic.get('expires', ''),
            'activated_at': lic.get('issued', hm.now()),
            'status': 'active',
            'order_id': '',
        })
        imported += 1
    log.info(f'Synced {imported} license(s) from server for HWID {hwid}')
    return jsonify({'ok': True, 'imported': imported, 'total': len(resp.get('licenses', []))})


@app.route('/api/product/<code>/summary')
def api_product_summary(code):
    """Proxy GET /api/hub/summary ke produk lokal (kalau running).

    Dipakai dashboard Hub untuk tampilin widget "MedOps: 3 pending request,
    RAT 5 unit approved" tanpa perlu login ke produknya.

    Guardrail: only whitelisted product codes, only localhost port yang
    terdaftar di INSTALL_DEFAULTS. Tidak boleh mengikuti path sembarangan.
    """
    info = hm.get_installed(code)
    if not info:
        return jsonify({'ok': False, 'installed': False,
                        'error': 'Produk belum terinstall'}), 404
    port = info.get('port') or hm.INSTALL_DEFAULTS.get(code, {}).get('port')
    if not port:
        return jsonify({'ok': False, 'error': 'Port produk tidak diketahui'}), 500
    if not _port_alive(port):
        return jsonify({'ok': False, 'installed': True, 'running': False,
                        'error': 'Produk tidak sedang berjalan'}), 409
    try:
        r = requests.get(f'http://127.0.0.1:{port}/api/hub/summary', timeout=3)
        return jsonify(r.json())
    except Exception as e:
        log.warning(f'Failed to fetch {code} summary: {e}')
        return jsonify({'ok': False, 'error': f'Gagal ambil data dari {code}: {e}'}), 502


@app.route('/api/machine/installed')
def api_machine_installed():
    """List known install paths for products (whether actually present on disk)."""
    out = []
    for code, d in hm.INSTALL_DEFAULTS.items():
        info = hm.get_installed(code)
        out.append({
            'code': code,
            'installed': info is not None,
            'path': info.get('install_path', '') if info else d['path'],
            'port': info.get('port', 0) if info else d['port'],
        })
    return jsonify({'ok': True, 'products': out})


def _port_alive(port, timeout=0.4):
    """Return True if a process is listening on localhost:<port>."""
    import socket
    try:
        with socket.create_connection(('127.0.0.1', int(port)), timeout=timeout):
            return True
    except Exception:
        return False


def _start_product(code):
    """Spawn a product's start script as a background daemon.

    Accepts a product *code* (medops, unitcost, ...), not an arbitrary path.
    Only paths in hm.INSTALL_DEFAULTS are honored — this prevents a
    compromised or malicious installed_products row from pointing at a
    system directory and getting us to execute arbitrary binaries there
    (audit: hub subprocess whitelist).

    Picks a launcher based on what exists in the install folder:
      Windows: start_hidden.vbs > start.bat
      Linux/Mac: start.sh > python3 app.py
    """
    import subprocess
    import platform
    default = hm.INSTALL_DEFAULTS.get(code)
    if not default:
        log.warning(f'_start_product: unknown product code {code!r}')
        return False
    path = default['path']
    if not os.path.isdir(path):
        log.warning(f'_start_product: path {path} does not exist')
        return False

    is_win = platform.system() == 'Windows'
    if is_win:
        candidates = [('wscript', 'start_hidden.vbs'), ('cmd', 'start.bat')]
    else:
        candidates = [('bash', 'start.sh'), ('python3', 'app.py')]
    for runner, script in candidates:
        full = os.path.join(path, script)
        if os.path.exists(full):
            try:
                subprocess.Popen(
                    [runner, script] if runner != 'cmd' else ['cmd', '/c', script],
                    cwd=path,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL,
                    start_new_session=not is_win,
                )
                log.info(f'Started product {code}: {runner} {script} (cwd={path})')
                return True
            except Exception as e:
                log.warning(f'Failed to spawn {runner} {script}: {e}')
    return False


@app.route('/api/launch/<code>', methods=['GET', 'POST'])
def api_launch(code):
    """Ensure the product is running, then return its URL.

    GET = check + launch URL (no auto-start, quick)
    POST = auto-start if not running, wait up to 20s for port to open
    """
    info = hm.get_installed(code)
    if not info:
        return jsonify({'ok': False, 'error': 'Produk belum terinstall di PC ini'}), 404
    lic = hm.get_license(code)
    if not lic:
        return jsonify({'ok': False, 'error': 'Lisensi produk belum aktif'}), 403
    port = info.get('port') or hm.INSTALL_DEFAULTS.get(code, {}).get('port')

    # Build the URL the browser should hit. In production (hub + products on
    # the same clinic PC), 'localhost' works. But when the hub is accessed
    # remotely (dev test on VPS, LAN desktop hitting a server PC), the
    # browser's idea of 'localhost' is the WRONG machine. Reuse whatever
    # host the current HTTP request came in on.
    req_host = request.host.split(':')[0] if request.host else 'localhost'
    url = f'http://{req_host}:{port}'

    if _port_alive(port):
        return jsonify({'ok': True, 'url': url, 'code': code, 'started': False})

    if request.method == 'GET':
        return jsonify({'ok': False, 'url': url, 'code': code, 'running': False,
                        'error': 'Produk tidak sedang berjalan. Klik "Jalankan" untuk memulai.'}), 409

    if not _start_product(code):
        return jsonify({'ok': False, 'error': 'Tidak dapat memulai produk. Cek apakah script start ada.'}), 500

    import time
    for _ in range(40):  # ~20 s
        if _port_alive(port):
            return jsonify({'ok': True, 'url': url, 'code': code, 'started': True})
        time.sleep(0.5)
    return jsonify({'ok': False, 'error': 'Produk terlalu lama merespon. Coba lagi dalam beberapa detik.'}), 504


# ==================== PAYMENT REDIRECT PAGES ====================
# NOTE: render_template_string auto-escapes Jinja variables — DO NOT switch
# to plain f-strings for these pages, or Midtrans-controlled query params
# (order_id, status_code) become an XSS vector (audit #12).
_PAYMENT_PAGE = """<!doctype html>
<html lang="id"><head>
<meta charset="utf-8"><title>{{ title }} — TeknoMedis</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#0f172a;color:#e2e8f0;
  display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;padding:20px}
.card{background:#1e293b;border:1px solid #334155;border-radius:16px;padding:40px;max-width:460px;text-align:center;
  box-shadow:0 20px 60px rgba(0,0,0,.4)}
.icon{font-size:64px;margin-bottom:16px}
h1{margin:0 0 10px;font-size:22px;color:{{ color }}}
p{color:#94a3b8;font-size:14px;line-height:1.6;margin:0 0 22px}
.oid{background:#0f172a;border:1px solid #334155;border-radius:8px;padding:10px;
  font-family:monospace;font-size:12px;color:#64748b;margin:14px 0}
.btn{display:inline-block;background:{{ color }};color:#fff;text-decoration:none;padding:10px 28px;
  border-radius:8px;font-weight:600;font-size:14px;margin-top:6px}
.btn:hover{opacity:.9}
</style></head><body>
<div class="card">
  <div class="icon">{{ icon }}</div>
  <h1>{{ title }}</h1>
  <p>{{ message }}</p>
  {% if order_id %}<div class="oid">Order: {{ order_id }}</div>{% endif %}
  <a href="/" class="btn">{{ button }}</a>
</div></body></html>"""


@app.route('/payment/success')
def payment_success():
    return render_template_string(_PAYMENT_PAGE,
        title='Pembayaran Berhasil', icon='✓', color='#10b981',
        message='Terima kasih! License key sudah terkirim ke email Anda. Sistem akan mengaktifkan lisensi secara otomatis.',
        order_id=request.args.get('order_id', ''),
        button='Kembali ke Hub')


@app.route('/payment/error')
def payment_error():
    return render_template_string(_PAYMENT_PAGE,
        title='Pembayaran Gagal', icon='✕', color='#ef4444',
        message='Maaf, pembayaran tidak dapat diproses. Silakan coba lagi atau pilih metode pembayaran lain.',
        order_id=request.args.get('order_id', ''),
        button='Coba Lagi')


@app.route('/payment/unfinish')
def payment_unfinish():
    return render_template_string(_PAYMENT_PAGE,
        title='Pembayaran Belum Selesai', icon='⏳', color='#f59e0b',
        message='Anda dapat melanjutkan pembayaran nanti melalui dashboard hub. Order tersimpan dan dapat dilanjutkan.',
        order_id=request.args.get('order_id', ''),
        button='Kembali ke Hub')


# ==================== STATIC ====================
@app.route('/')
def index():
    return send_from_directory(os.path.dirname(__file__), 'index.html')


@app.errorhandler(Exception)
def err(e):
    log.exception(f'Unhandled error: {e}')
    return jsonify({'ok': False, 'error': 'Internal server error'}), 500


# ==================== STARTUP ====================
if __name__ == '__main__':
    hm.init_db()
    # Auto-detect installed products from default paths
    for code, d in hm.INSTALL_DEFAULTS.items():
        if os.path.isdir(d['path']) and not hm.get_installed(code):
            hm.mark_installed(code, name=code.title(), path=d['path'], port=d['port'])
    print('\n' + '=' * 50)
    print('  TeknoMedis Hub — Product Launcher')
    print('=' * 50)
    print(f'  Local:  http://localhost:{HUB_PORT}')
    print(f'  License server: {LICENSE_SERVER}')
    print(f'  HWID:   {format_hwid(get_hardware_id())}')
    print('=' * 50 + '\n')
    app.run(host='0.0.0.0', port=HUB_PORT, debug=False)
