"""Hub database layer — SQLite wrapper for orders, licenses, installed products."""
import os
import sqlite3
from datetime import datetime, timezone

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
DB_FILE = os.path.join(DATA_DIR, 'hub.db')

# Known installation paths per product — used by launcher.
# On Windows this will be `C:\Teknomedis\<product>`.
# Ports must match each product's `app.py` (PORT env or hardcoded default).
INSTALL_DEFAULTS = {
    'medops':    {'path': '/root/medops-pro',    'port': 8060},
    'casemix':   {'path': '/root/casemix-pro',   'port': 8070},
    'unitcost':  {'path': '/root/unitcost-pro',  'port': 5050},
    'kalibrasi': {'path': '/root/kalibrasi-pro', 'port': 8100},
}


def _conn():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    # Enable WAL once at init; persists in the file header. Lets readers and
    # one writer proceed concurrently without blocking each other — important
    # when hub polls /api/orders while a webhook is updating licenses.
    with _conn() as c:
        c.execute('PRAGMA journal_mode=WAL')
        c.executescript("""
        CREATE TABLE IF NOT EXISTS orders (
            order_id TEXT PRIMARY KEY,
            req_id TEXT,
            product_code TEXT NOT NULL,
            package_id TEXT,
            package_name TEXT,
            amount INTEGER,
            snap_token TEXT,
            redirect_url TEXT,
            status TEXT DEFAULT 'pending',
            transaction_status TEXT,
            clinic TEXT,
            email TEXT,
            phone TEXT,
            created_at TEXT,
            paid_at TEXT
        );

        CREATE TABLE IF NOT EXISTS machine_licenses (
            product_code TEXT PRIMARY KEY,
            license_key TEXT NOT NULL,
            clinic TEXT,
            hwid TEXT,
            plan TEXT,
            days INTEGER,
            expires_at TEXT,
            activated_at TEXT,
            status TEXT DEFAULT 'active',
            order_id TEXT
        );

        -- Cached activation token returned by the license server after
        -- the first successful /api/order/create. HMAC of HWID using
        -- server-side PANEL_SECRET; same for every product on this PC.
        CREATE TABLE IF NOT EXISTS machine_auth (
            hwid TEXT PRIMARY KEY,
            activation_token TEXT NOT NULL,
            updated_at TEXT
        );

        CREATE TABLE IF NOT EXISTS installed_products (
            code TEXT PRIMARY KEY,
            name TEXT,
            install_path TEXT,
            port INTEGER,
            version TEXT,
            installed_at TEXT
        );

        CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
        CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
        """)


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


# ---- orders ----
def save_order(data):
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO orders
            (order_id, req_id, product_code, package_id, package_name, amount,
             snap_token, redirect_url, status, transaction_status,
             clinic, email, phone, created_at, paid_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data['order_id'], data.get('req_id', ''), data['product_code'],
            data.get('package_id', ''), data.get('package_name', ''),
            int(data.get('amount', 0)), data.get('snap_token', ''),
            data.get('redirect_url', ''), data.get('status', 'pending'),
            data.get('transaction_status', ''),
            data.get('clinic', ''), data.get('email', ''), data.get('phone', ''),
            data.get('created_at', now()), data.get('paid_at'),
        ))


def get_order(order_id):
    with _conn() as c:
        row = c.execute('SELECT * FROM orders WHERE order_id = ?', (order_id,)).fetchone()
        return dict(row) if row else None


def update_order_status(order_id, status, transaction_status='', paid_at=None):
    with _conn() as c:
        c.execute("""UPDATE orders SET status=?, transaction_status=?, paid_at=COALESCE(?, paid_at)
                     WHERE order_id=?""",
                  (status, transaction_status, paid_at, order_id))


def list_orders(limit=50):
    with _conn() as c:
        rows = c.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT ?', (limit,)).fetchall()
        return [dict(r) for r in rows]


# ---- licenses ----
def save_license(product_code, data):
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO machine_licenses
            (product_code, license_key, clinic, hwid, plan, days, expires_at,
             activated_at, status, order_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            product_code, data['license_key'], data.get('clinic', ''),
            data.get('hwid', ''), data.get('plan', ''), int(data.get('days', 0)),
            data.get('expires_at', ''), data.get('activated_at', now()),
            data.get('status', 'active'), data.get('order_id', ''),
        ))


def get_license(product_code):
    with _conn() as c:
        row = c.execute('SELECT * FROM machine_licenses WHERE product_code=?', (product_code,)).fetchone()
        return dict(row) if row else None


def list_licenses():
    with _conn() as c:
        rows = c.execute('SELECT * FROM machine_licenses').fetchall()
        return [dict(r) for r in rows]


# ---- installed products ----
def mark_installed(code, name, path=None, port=None, version=''):
    defaults = INSTALL_DEFAULTS.get(code, {})
    path = path or defaults.get('path', '')
    port = int(port or defaults.get('port', 0))
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO installed_products
            (code, name, install_path, port, version, installed_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (code, name, path, port, version, now()))


def get_installed(code):
    with _conn() as c:
        row = c.execute('SELECT * FROM installed_products WHERE code=?', (code,)).fetchone()
        if row:
            return dict(row)
    # Fall back to built-in defaults + auto-detect folder existence.
    d = INSTALL_DEFAULTS.get(code)
    if d and os.path.isdir(d['path']):
        return {'code': code, 'install_path': d['path'], 'port': d['port']}
    return None


def list_installed():
    with _conn() as c:
        rows = c.execute('SELECT * FROM installed_products').fetchall()
        return [dict(r) for r in rows]


# ---- activation token ----
def save_activation_token(hwid, token):
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO machine_auth (hwid, activation_token, updated_at)
            VALUES (?, ?, ?)
        """, (hwid, token, now()))


def get_activation_token(hwid):
    with _conn() as c:
        row = c.execute('SELECT activation_token FROM machine_auth WHERE hwid=?',
                        (hwid,)).fetchone()
        return row['activation_token'] if row else ''
