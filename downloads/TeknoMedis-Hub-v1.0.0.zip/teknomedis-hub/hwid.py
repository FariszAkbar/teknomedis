"""Hardware ID computation — MUST match license_manager.get_hardware_id.

CANONICAL SOURCE:
  /root/teknomedis-license/license_manager.py :: get_hardware_id
  /root/medops-pro/license_manager.py        :: get_hardware_id

If you change the formula here, change it in both of those files and
re-issue any outstanding licenses. Hub and installed products must agree
byte-for-byte on this value, otherwise every activated license is
rejected as hwid_mismatch.

Formula: sha256(f"{mac}-{system}-{node}-MediStokPro")[:16].upper()
"""
import hashlib
import platform
import uuid


def get_hardware_id():
    """Generate unique hardware fingerprint from MAC + platform."""
    mac = uuid.getnode()
    system = platform.system()
    node = platform.node()
    raw = f"{mac}-{system}-{node}-MediStokPro"
    return hashlib.sha256(raw.encode()).hexdigest()[:16].upper()


def format_hwid(hwid):
    """Format HWID as XXXX-XXXX-XXXX-XXXX."""
    s = hwid.replace('-', '')
    return '-'.join(s[i:i+4] for i in range(0, len(s), 4))
