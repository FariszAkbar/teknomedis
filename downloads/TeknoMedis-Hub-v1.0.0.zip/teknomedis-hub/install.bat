@echo off
echo ==========================================
echo   TeknoMedis Hub - Installer
echo ==========================================
python --version >/dev/null 2>&1
if %errorlevel% neq 0 (echo [ERROR] Python 3.10+ required & pause & exit /b 1)
python -m pip install -r requirements.txt
echo.
echo [OK] Hub siap. Jalankan start.bat lalu buka http://localhost:8050
pause
