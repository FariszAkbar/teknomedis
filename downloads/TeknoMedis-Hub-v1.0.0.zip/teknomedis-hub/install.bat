@echo off
cd /d "%~dp0"
echo ==========================================
echo   TeknoMedis Hub - Installer
echo ==========================================
echo.
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python 3.10+ tidak terdeteksi.
    echo         Install dari https://python.org — centang "Add Python to PATH"
    pause
    exit /b 1
)
echo [OK] Python ditemukan.
echo.
echo [1/1] Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Gagal install dependencies. Cek koneksi internet atau error di atas.
    pause
    exit /b 1
)
echo.
echo ==========================================
echo   [OK] Hub siap dipakai!
echo   Next: jalankan start.bat
echo   Lalu buka browser ke http://localhost:8050
echo ==========================================
pause
