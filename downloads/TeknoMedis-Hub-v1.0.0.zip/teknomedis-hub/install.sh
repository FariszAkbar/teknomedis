#!/bin/bash
echo "TeknoMedis Hub - Installer"
pip3 install -r requirements.txt
echo "[OK] Jalankan: bash start.sh"
echo "Buka browser: http://localhost:8050"
