@echo off
cd /d "%~dp0"
echo ==========================================
echo   TeknoMedis Hub - Starting...
echo ==========================================
python app.py
pause
