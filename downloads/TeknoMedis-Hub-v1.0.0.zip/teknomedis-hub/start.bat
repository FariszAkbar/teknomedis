@echo off
echo ==========================================
echo   TeknoMedis Hub - Starting...
echo ==========================================
python app.py
pause
