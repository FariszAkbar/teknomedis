#!/bin/bash
cd "$(dirname "$0")"
echo "Starting TeknoMedis Hub..."
python3 app.py
