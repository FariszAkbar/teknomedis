from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from db_manager import init_db, seed_data
from helpers import get_json, ok, err, safe_db
from license_manager import (validate_license, activate_license, get_license_info,
                              update_online_check, get_hardware_id, format_hwid)
from routes import auth, unitcost
import os
import logging

APP_VERSION = '1.0.0'


def get_license_server_url():
    url = os.environ.get('LICENSE_SERVER', '')
    if not url:
        cfg_path = os.path.join(os.path.dirname(__file__), 'data', 'config.json')
        if os.path.exists(cfg_path):
            try:
                import json as _j
                with open(cfg_path) as _f:
                    url = _j.load(_f).get('license_server', '')
            except Exception:
                pass
    return url or 'http://localhost:8061'


app = Flask(__name__, static_folder='.', static_url_path='')
app.secret_key = os.environ.get('SECRET_KEY', 'unitcost-pro-secret-key-2026')
CORS(app)

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# Register blueprints
app.register_blueprint(auth.bp)
app.register_blueprint(unitcost.bp)


# ===================== ERROR HANDLER =====================
@app.errorhandler(Exception)
def handle_error(e):
    logger.exception(f"Unhandled error: {e}")
    return jsonify({'ok': False, 'error': 'Internal server error'}), 500


# ===================== LICENSE CHECK =====================
# Endpoints that never require license (any method)
LICENSE_FREE_ALWAYS = {
    '/', '/api/license', '/api/license/activate', '/api/license/info',
    '/api/license/heartbeat', '/api/login', '/api/version', '/api/restart',
}


@app.before_request
def check_license():
    path = request.path
    method = request.method

    # Always allow core endpoints
    if path in LICENSE_FREE_ALWAYS:
        return
    if path.startswith('/api/proxy/'):
        return
    if not path.startswith('/api/'):
        return

    # Allow all GET requests (read-only / view mode)
    if method == 'GET':
        return

    # For write operations (POST/PUT/DELETE), require valid license
    revoked_file = os.path.join(os.path.dirname(__file__), 'data', '.revoked')
    if os.path.exists(revoked_file):
        return jsonify({'ok': False, 'error': 'LICENSE_REVOKED',
                        'license': {'valid': False, 'status': 'revoked',
                                    'message': 'Lisensi dicabut. Hubungi developer.'}}), 403
    lic = validate_license()
    if not lic['valid']:
        return jsonify({'ok': False, 'error': 'LICENSE_REQUIRED',
                        'license': lic,
                        'message': 'Aktivasi lisensi diperlukan untuk fitur ini.'}), 403


# ===================== LICENSE ENDPOINTS =====================
@app.route('/api/license')
@safe_db
def license_status():
    info = get_license_info()
    revoked_file = os.path.join(os.path.dirname(__file__), 'data', '.revoked')
    if os.path.exists(revoked_file):
        info['valid'] = False
        info['status'] = 'revoked'
        info['message'] = 'Lisensi dicabut. Hubungi developer untuk informasi.'
    return jsonify(info)


@app.route('/api/license/activate', methods=['POST'])
@safe_db
def license_activate():
    data = get_json()
    key = data.get('key', '').strip()
    if not key:
        return err('Masukkan license key')
    result = activate_license(key)
    if result['ok']:
        revoked_file = os.path.join(os.path.dirname(__file__), 'data', '.revoked')
        if os.path.exists(revoked_file):
            os.remove(revoked_file)
        logger.info(f"License activated: {result['data'].get('clinic', '?')}")
    return jsonify(result)


@app.route('/api/license/info')
@safe_db
def license_info():
    return jsonify(get_license_info())


@app.route('/api/license/validate-online', methods=['POST'])
@safe_db
def license_validate_online():
    lic = validate_license()
    if lic['valid']:
        update_online_check()
        return ok(message='Online validation berhasil')
    return err(lic['message'])


@app.route('/api/license/heartbeat', methods=['POST'])
@safe_db
def license_heartbeat():
    import urllib.request
    lic = validate_license()
    hwid = get_hardware_id()
    revoked_file = os.path.join(os.path.dirname(__file__), 'data', '.revoked')
    try:
        license_server = get_license_server_url()
        req_url = f'{license_server}/check-revoked/{hwid}'
        with urllib.request.urlopen(req_url, timeout=5) as resp:
            import json as json_mod
            data = json_mod.loads(resp.read())
            if data.get('revoked'):
                with open(revoked_file, 'w') as f:
                    f.write('revoked')
                return jsonify({'ok': False, 'status': 'revoked',
                                'message': 'Lisensi dicabut oleh developer.'})
            else:
                if os.path.exists(revoked_file):
                    os.remove(revoked_file)
    except Exception:
        pass

    # Ping license server (update last_seen for online status)
    try:
        license_server = get_license_server_url()
        import json as json_ping
        ping_data = json_ping.dumps({'hwid': hwid, 'version': APP_VERSION, 'product': 'unitcost'}).encode()
        ping_req = urllib.request.Request(f'{license_server}/ping', data=ping_data,
                                          headers={'Content-Type': 'application/json'}, method='POST')
        urllib.request.urlopen(ping_req, timeout=5)
    except Exception:
        pass

    update_info = None
    try:
        license_server = get_license_server_url()
        import urllib.request as urllib_req
        import json as json_mod2
        update_url = f'{license_server}/check-update?version={APP_VERSION}&hwid={hwid}&product=unitcost'
        with urllib_req.urlopen(update_url, timeout=5) as resp2:
            update_info = json_mod2.loads(resp2.read())
    except Exception:
        pass

    return jsonify({
        'ok': lic['valid'],
        'status': lic['status'],
        'days_left': lic.get('days_left', 0),
        'clinic': lic['data']['clinic'] if lic.get('data') else '',
        'version': APP_VERSION,
        'update': update_info if update_info and update_info.get('available') else None,
    })


# ===================== VERSION =====================
@app.route('/api/version')
def get_version():
    return jsonify({'version': APP_VERSION, 'product': 'UnitCost Pro'})


# ===================== UPDATE =====================
@app.route('/api/update/apply', methods=['POST'])
@safe_db
def apply_update():
    import urllib.request as urllib_req
    import json as json_mod
    import zipfile
    import shutil
    import tempfile

    data = request.json or {}
    version = data.get('version', '')
    if not version:
        return err('Version required')

    license_server = get_license_server_url()
    hwid = get_hardware_id()

    try:
        check_url = f'{license_server}/check-update?version={APP_VERSION}&hwid={hwid}&product=unitcost'
        with urllib_req.urlopen(check_url, timeout=10) as resp:
            info = json_mod.loads(resp.read())
        if not info.get('available') or info.get('version') != version:
            return err('Update tidak tersedia')

        download_url = info.get('download_url', '')
        if not download_url:
            return err('Download URL tidak tersedia')

        app_dir = os.path.dirname(os.path.abspath(__file__))
        backup_dir = os.path.join(app_dir, 'data', '_backup_' + APP_VERSION)

        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp:
            tmp_path = tmp.name
            with urllib_req.urlopen(download_url, timeout=60) as resp:
                tmp.write(resp.read())

        os.makedirs(backup_dir, exist_ok=True)
        for fname in ['app.py', 'helpers.py', 'db_manager.py', 'index.html',
                       'engine.py', 'license_manager.py', 'requirements.txt', 'start.sh']:
            src = os.path.join(app_dir, fname)
            if os.path.exists(src):
                shutil.copy2(src, os.path.join(backup_dir, fname))

        routes_backup = os.path.join(backup_dir, 'routes')
        routes_src = os.path.join(app_dir, 'routes')
        if os.path.isdir(routes_src):
            if os.path.exists(routes_backup):
                shutil.rmtree(routes_backup)
            shutil.copytree(routes_src, routes_backup)

        with zipfile.ZipFile(tmp_path, 'r') as zf:
            for member in zf.namelist():
                parts = member.split('/', 1)
                if len(parts) < 2 or not parts[1]:
                    continue
                rel_path = parts[1]
                target = os.path.join(app_dir, rel_path)
                if member.endswith('/'):
                    os.makedirs(target, exist_ok=True)
                else:
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with zf.open(member) as src, open(target, 'wb') as dst:
                        dst.write(src.read())

        os.unlink(tmp_path)

        try:
            notify_data = json_mod.dumps({'hwid': hwid, 'version': version, 'product': 'unitcost'}).encode()
            req2 = urllib_req.Request(f'{license_server}/update-applied',
                                      data=notify_data,
                                      headers={'Content-Type': 'application/json'},
                                      method='POST')
            urllib_req.urlopen(req2, timeout=5)
        except Exception:
            pass

        return ok(message=f'Update ke v{version} berhasil! Restart server untuk menerapkan.',
                  version=version, backup=backup_dir, needs_restart=True)
    except Exception as e:
        logging.exception(f"Update error: {e}")
        return err(f'Gagal update: {str(e)}')


@app.route('/api/update/rollback', methods=['POST'])
@safe_db
def rollback_update():
    import shutil
    app_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(app_dir, 'data')
    backups = sorted([d for d in os.listdir(data_dir) if d.startswith('_backup_')], reverse=True)
    if not backups:
        return err('Tidak ada backup untuk rollback')

    backup_dir = os.path.join(data_dir, backups[0])
    try:
        for fname in os.listdir(backup_dir):
            src = os.path.join(backup_dir, fname)
            dst = os.path.join(app_dir, fname)
            if os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
        return ok(message=f'Rollback dari {backups[0]} berhasil! Restart server.', needs_restart=True)
    except Exception as e:
        return err(f'Gagal rollback: {str(e)}')


# ===================== RESTART =====================
@app.route('/api/restart', methods=['POST'])
@safe_db
def restart_server():
    import subprocess
    import sys
    import threading
    import platform

    def do_restart():
        import time
        time.sleep(1)
        app_dir = os.path.dirname(os.path.abspath(__file__))
        if platform.system() == 'Windows':
            vbs = os.path.join(app_dir, 'start_hidden.vbs')
            if os.path.exists(vbs):
                subprocess.Popen(['wscript', vbs], cwd=app_dir)
            else:
                subprocess.Popen([sys.executable, os.path.abspath(__file__)] + sys.argv[1:], cwd=app_dir)
        else:
            subprocess.Popen([sys.executable, os.path.abspath(__file__)] + sys.argv[1:], cwd=app_dir)
        os._exit(0)

    threading.Thread(target=do_restart, daemon=True).start()
    return ok(message='Server restarting...')


# ===================== LICENSE SERVER PROXY =====================
def _proxy_license_server(path, method='GET', data=None):
    import urllib.request as urllib_req
    import json as json_mod
    license_server = get_license_server_url()
    url = f'{license_server}{path}'
    try:
        if method == 'GET':
            with urllib_req.urlopen(url, timeout=10) as resp:
                return json_mod.loads(resp.read())
        else:
            body = json_mod.dumps(data or {}).encode()
            req = urllib_req.Request(url, data=body, headers={'Content-Type': 'application/json'}, method=method)
            with urllib_req.urlopen(req, timeout=10) as resp:
                return json_mod.loads(resp.read())
    except Exception as e:
        return {'ok': False, 'error': f'License server tidak tersedia: {str(e)}'}


@app.route('/api/proxy/pricing')
@safe_db
def proxy_pricing():
    product = request.args.get('product', 'unitcost')
    return jsonify(_proxy_license_server(f'/pricing?product={product}'))


@app.route('/api/proxy/request-renewal', methods=['POST'])
@safe_db
def proxy_request_renewal():
    data = request.json or {}
    return jsonify(_proxy_license_server('/request-renewal', method='POST', data=data))


@app.route('/api/proxy/ping', methods=['POST'])
@safe_db
def proxy_ping():
    data = request.json or {}
    return jsonify(_proxy_license_server('/ping', method='POST', data=data))


@app.route('/api/proxy/pending-key/<hwid>')
@safe_db
def proxy_pending_key(hwid):
    return jsonify(_proxy_license_server(f'/pending-key/{hwid}'))


@app.route('/api/proxy/mark-delivered', methods=['POST'])
@safe_db
def proxy_mark_delivered():
    data = request.json or {}
    return jsonify(_proxy_license_server('/mark-delivered', method='POST', data=data))


# ===================== DASHBOARD =====================
@app.route('/api/dashboard')
@safe_db
def dashboard():
    from db_manager import get_db
    conn = get_db()
    total_periods = conn.execute("SELECT COUNT(*) FROM periods").fetchone()[0]
    total_units = conn.execute("SELECT COUNT(*) FROM units").fetchone()[0]
    total_calcs = conn.execute("SELECT COUNT(*) FROM calculations").fetchone()[0]

    recent = conn.execute("""
        SELECT c.id, c.method, c.calculated_at, p.name as period_name,
               (SELECT COUNT(*) FROM calculation_results WHERE calculation_id=c.id) as result_count
        FROM calculations c JOIN periods p ON c.period_id = p.id
        ORDER BY c.calculated_at DESC LIMIT 5
    """).fetchall()
    conn.close()

    from helpers import dict_rows
    return ok({
        'total_periods': total_periods, 'total_units': total_units,
        'total_calculations': total_calcs, 'recent_calculations': dict_rows(recent),
    })


# ===================== STATIC =====================
@app.route('/')
@safe_db
def index():
    return send_from_directory('.', 'index.html')


# ===================== STARTUP =====================
if __name__ == '__main__':
    import sys
    demo = '--demo' in sys.argv
    port = int(os.environ.get('PORT', 5050))

    init_db()
    seed_data(demo=demo)
    lic = get_license_info()
    print("\n" + "=" * 50)
    print("  UnitCost Pro — Server Running")
    print("=" * 50)
    print(f"  Mode:    {'DEMO' if demo else 'PRODUCTION'}")
    print(f"  Local:   http://localhost:{port}")
    print(f"  LAN:     http://0.0.0.0:{port}")
    print(f"  HWID:    {lic['hwid']}")
    print(f"  Version: {APP_VERSION}")
    print(f"  License: {lic['status'].upper()}")
    if lic['data']:
        print(f"  Clinic:  {lic['data'].get('clinic', '-')}")
        print(f"  Expires: {lic['data'].get('expires', '-')[:10]}")
    print("=" * 50 + "\n")
    app.run(host='0.0.0.0', port=port, debug=False)
