"""UnitCost Pro — Database Manager (SQLite3, raw SQL)."""
import os
import sqlite3
import logging

logger = logging.getLogger(__name__)

DB_PATH = os.path.join(os.path.dirname(__file__), 'data', 'unitcost.db')


def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    conn = get_db()
    c = conn.cursor()

    # ─── Users & Auth ─────────────────────────────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT CHECK(role IN ('admin','viewer')) DEFAULT 'admin',
        display_name TEXT DEFAULT ''
    )""")

    # ─── Periods ──────────────────────────────────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS periods (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now','localtime'))
    )""")

    # ─── Units (Instalasi/Cost Center) ────────────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS units (
        id TEXT PRIMARY KEY,
        period_id TEXT NOT NULL,
        name TEXT NOT NULL,
        unit_type TEXT CHECK(unit_type IN ('support','production')) NOT NULL,
        direct_cost REAL DEFAULT 0,
        output_volume INTEGER DEFAULT 0,
        output_unit TEXT DEFAULT '',
        cost_driver_type TEXT DEFAULT '',
        sort_order INTEGER DEFAULT 0,
        FOREIGN KEY (period_id) REFERENCES periods(id) ON DELETE CASCADE
    )""")

    # ─── Allocations (Cost Driver Matrix) ─────────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS allocations (
        id TEXT PRIMARY KEY,
        from_unit_id TEXT NOT NULL,
        to_unit_id TEXT NOT NULL,
        driver_value REAL DEFAULT 0,
        proportion REAL DEFAULT 0,
        FOREIGN KEY (from_unit_id) REFERENCES units(id) ON DELETE CASCADE,
        FOREIGN KEY (to_unit_id) REFERENCES units(id) ON DELETE CASCADE,
        UNIQUE(from_unit_id, to_unit_id)
    )""")

    # ─── Calculations (History) ───────────────────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS calculations (
        id TEXT PRIMARY KEY,
        period_id TEXT NOT NULL,
        method TEXT DEFAULT 'double_distribution',
        calculated_at TEXT DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (period_id) REFERENCES periods(id) ON DELETE CASCADE
    )""")

    # ─── Calculation Results (per production unit) ────────────
    c.execute("""CREATE TABLE IF NOT EXISTS calculation_results (
        id TEXT PRIMARY KEY,
        calculation_id TEXT NOT NULL,
        unit_id TEXT NOT NULL,
        unit_name TEXT DEFAULT '',
        direct_cost REAL DEFAULT 0,
        indirect_cost REAL DEFAULT 0,
        total_cost REAL DEFAULT 0,
        output_volume INTEGER DEFAULT 0,
        output_unit TEXT DEFAULT '',
        unit_cost REAL DEFAULT 0,
        FOREIGN KEY (calculation_id) REFERENCES calculations(id) ON DELETE CASCADE,
        FOREIGN KEY (unit_id) REFERENCES units(id) ON DELETE CASCADE
    )""")

    # ─── Distribution Details (audit trail) ───────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS distribution_details (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        calculation_id TEXT NOT NULL,
        stage TEXT NOT NULL,
        from_unit_id TEXT NOT NULL,
        from_unit_name TEXT DEFAULT '',
        to_unit_id TEXT NOT NULL,
        to_unit_name TEXT DEFAULT '',
        amount REAL DEFAULT 0,
        FOREIGN KEY (calculation_id) REFERENCES calculations(id) ON DELETE CASCADE
    )""")

    # ─── Audit Log ────────────────────────────────────────────
    c.execute("""CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT DEFAULT (datetime('now','localtime')),
        user_id TEXT,
        user_name TEXT,
        action TEXT,
        entity TEXT,
        entity_id TEXT,
        detail TEXT
    )""")

    # ─── Indexes ──────────────────────────────────────────────
    c.execute("CREATE INDEX IF NOT EXISTS idx_units_period ON units(period_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_units_type ON units(unit_type)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_alloc_from ON allocations(from_unit_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_alloc_to ON allocations(to_unit_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_calc_period ON calculations(period_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_calcres_calc ON calculation_results(calculation_id)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_distdet_calc ON distribution_details(calculation_id)")

    conn.commit()
    conn.close()
    logger.info(f"Database initialized: {DB_PATH}")


def seed_data(demo=False):
    """Seed default admin user."""
    conn = get_db()
    admin = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
    if not admin:
        from werkzeug.security import generate_password_hash
        conn.execute(
            "INSERT INTO users (id, username, password_hash, role, display_name) VALUES (?,?,?,?,?)",
            ('admin01', 'admin', generate_password_hash('admin123'), 'admin', 'Administrator')
        )
        logger.info("Default admin user created: admin / admin123")

    if demo:
        # Seed demo period + units
        existing = conn.execute("SELECT id FROM periods LIMIT 1").fetchone()
        if not existing:
            from helpers import gid
            pid = gid()
            conn.execute(
                "INSERT INTO periods (id, name, start_date, end_date) VALUES (?,?,?,?)",
                (pid, 'Tahun 2025', '2025-01-01', '2025-12-31')
            )
            demo_units = [
                (gid(), pid, 'Administrasi', 'support', 100000000, 0, '', 'jumlah pegawai', 1),
                (gid(), pid, 'Laundry', 'support', 60000000, 0, '', 'kg cucian', 2),
                (gid(), pid, 'Dapur/Gizi', 'support', 80000000, 0, '', 'jumlah porsi', 3),
                (gid(), pid, 'IPSRS', 'support', 50000000, 0, '', 'luas m2', 4),
                (gid(), pid, 'Rawat Jalan', 'production', 200000000, 10000, 'kunjungan', '', 5),
                (gid(), pid, 'Rawat Inap', 'production', 300000000, 5000, 'hari rawat', '', 6),
                (gid(), pid, 'IGD', 'production', 150000000, 8000, 'kunjungan', '', 7),
                (gid(), pid, 'Laboratorium', 'production', 120000000, 15000, 'pemeriksaan', '', 8),
            ]
            conn.executemany(
                "INSERT INTO units (id,period_id,name,unit_type,direct_cost,output_volume,output_unit,cost_driver_type,sort_order) VALUES (?,?,?,?,?,?,?,?,?)",
                demo_units
            )
            logger.info("Demo data seeded")

    conn.commit()
    conn.close()
