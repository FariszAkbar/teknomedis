"""
Engine perhitungan Unit Cost.
Metode: Double Distribution.
"""

from dataclasses import dataclass


@dataclass
class UnitData:
    id: str
    name: str
    unit_type: str  # 'support' | 'production'
    direct_cost: float
    total_cost: float = 0.0
    output_volume: int = 0
    output_unit: str = ""
    unit_cost: float = 0.0
    indirect_cost: float = 0.0


@dataclass
class AllocationEntry:
    from_unit_id: str
    to_unit_id: str
    proportion: float  # 0.0 - 1.0


@dataclass
class DistributionRecord:
    stage: str  # 'dist_1' | 'dist_2'
    from_unit_id: str
    to_unit_id: str
    amount: float


def double_distribution(units: list[UnitData], allocations: list[AllocationEntry]) -> dict:
    """
    Hitung unit cost dengan metode Double Distribution.

    Returns:
        {
            "results": {unit_id: UnitData},
            "distributions": [DistributionRecord],
            "total_initial": float,
            "total_final": float,
        }
    """
    unit_map = {}
    for u in units:
        u.total_cost = u.direct_cost
        u.indirect_cost = 0.0
        unit_map[u.id] = u

    support_ids = [u.id for u in units if u.unit_type == "support"]
    production_ids = [u.id for u in units if u.unit_type == "production"]

    alloc_map = {}
    for a in allocations:
        alloc_map.setdefault(a.from_unit_id, []).append((a.to_unit_id, a.proportion))

    total_initial = sum(u.direct_cost for u in units)
    distributions = []

    # === TAHAP 1: Distribusi I ===
    dist1_costs = {uid: 0.0 for uid in unit_map}

    for sid in support_ids:
        cost_to_distribute = unit_map[sid].total_cost
        if cost_to_distribute <= 0:
            continue

        targets = alloc_map.get(sid, [])
        for to_id, proportion in targets:
            if to_id == sid:
                continue
            amount = cost_to_distribute * proportion
            dist1_costs[to_id] += amount
            distributions.append(DistributionRecord("dist_1", sid, to_id, amount))

        dist1_costs[sid] -= cost_to_distribute

    for uid in unit_map:
        unit_map[uid].total_cost += dist1_costs[uid]
        if unit_map[uid].unit_type == "production":
            unit_map[uid].indirect_cost += dist1_costs[uid]

    # === TAHAP 2: Distribusi II ===
    for sid in support_ids:
        remaining = unit_map[sid].total_cost
        if remaining <= 0:
            unit_map[sid].total_cost = 0
            continue

        original_targets = alloc_map.get(sid, [])
        prod_targets = [(to_id, prop) for to_id, prop in original_targets if to_id in production_ids]

        if not prod_targets:
            equal_share = remaining / len(production_ids) if production_ids else 0
            for pid in production_ids:
                unit_map[pid].total_cost += equal_share
                unit_map[pid].indirect_cost += equal_share
                distributions.append(DistributionRecord("dist_2", sid, pid, equal_share))
        else:
            total_prop = sum(p for _, p in prod_targets)
            for to_id, prop in prod_targets:
                normalized = prop / total_prop if total_prop > 0 else 0
                amount = remaining * normalized
                unit_map[to_id].total_cost += amount
                unit_map[to_id].indirect_cost += amount
                distributions.append(DistributionRecord("dist_2", sid, to_id, amount))

        unit_map[sid].total_cost = 0

    # === Hitung Unit Cost ===
    for pid in production_ids:
        u = unit_map[pid]
        if u.output_volume > 0:
            u.unit_cost = u.total_cost / u.output_volume
        else:
            u.unit_cost = 0

    total_final = sum(unit_map[pid].total_cost for pid in production_ids)

    return {
        "results": unit_map,
        "distributions": distributions,
        "total_initial": total_initial,
        "total_final": total_final,
    }
