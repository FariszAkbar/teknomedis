"""Shared helpers: validation, formatting, auth decorator."""
import uuid
import re
import logging
from datetime import date, datetime
from functools import wraps
from flask import request, jsonify

logger = logging.getLogger(__name__)


def safe_db(fn):
    """Decorator: wraps route in try/except with proper DB cleanup."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            logger.exception(f"Error in {fn.__name__}: {e}")
            return jsonify({'ok': False, 'error': 'Terjadi kesalahan internal'}), 500
    return wrapper


def gid():
    return uuid.uuid4().hex[:8]


def now_ts():
    return f"{date.today().isoformat()} {datetime.now().strftime('%H:%M')}"


def validate_date(s):
    if not s:
        return None
    try:
        datetime.strptime(s, '%Y-%m-%d')
        return s
    except ValueError:
        return None


def validate_int(val, min_val=0, max_val=999999999, default=0):
    try:
        v = int(val)
        return max(min_val, min(v, max_val))
    except (TypeError, ValueError):
        return default


def validate_float(val, min_val=0, default=0.0):
    try:
        v = float(val)
        return max(min_val, v)
    except (TypeError, ValueError):
        return default


def get_json():
    return request.json or {}


def dict_row(row):
    if row is None:
        return None
    return dict(row)


def dict_rows(rows):
    return [dict(r) for r in rows]


def ok(data=None, **kwargs):
    resp = {'ok': True}
    if data is not None:
        resp['data'] = data
    resp.update(kwargs)
    return jsonify(resp)


def err(message, status=400):
    return jsonify({'ok': False, 'error': message}), status


def require_json(*fields):
    data = get_json()
    missing = [f for f in fields if not data.get(f)]
    if missing:
        return None, err(f"Field wajib: {', '.join(missing)}")
    return data, None


def get_clinic_name():
    try:
        from license_manager import get_license_info
        info = get_license_info()
        if info.get('data') and info['data'].get('clinic'):
            return info['data']['clinic'].upper()
    except Exception:
        pass
    return 'UnitCost Pro'
