@echo off
cd /d "%~dp0"
echo ==========================================
echo   UnitCost Pro - Installer
echo ==========================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python tidak ditemukan!
    echo Download Python dari https://www.python.org/downloads/
    echo Pastikan centang "Add Python to PATH" saat install.
    pause
    exit /b 1
)

echo [1/2] Installing dependencies...
pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [ERROR] Gagal install dependencies!
    pause
    exit /b 1
)

echo [2/2] Initializing database...
python -c "from db_manager import init_db, seed_data; init_db(); seed_data()"

echo.
echo ==========================================
echo   Instalasi Selesai!
echo ==========================================
echo   Jalankan: start.bat atau start_hidden.vbs
echo ==========================================
pause
