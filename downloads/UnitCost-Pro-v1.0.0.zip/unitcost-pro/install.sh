#!/bin/bash
echo "=========================================="
echo "  UnitCost Pro - Installer"
echo "=========================================="
cd "$(dirname "$0")"
echo "[1/2] Installing dependencies..."
pip3 install -r requirements.txt --quiet
echo "[2/2] Initializing database..."
python3 -c "from db_manager import init_db, seed_data; init_db(); seed_data()"
echo ""
echo "Instalasi selesai! Jalankan: bash start.sh"
