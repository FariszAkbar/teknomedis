"""Auth routes: login, users."""
from flask import Blueprint
from helpers import get_json, ok, err, safe_db, dict_rows
from db_manager import get_db
from werkzeug.security import check_password_hash, generate_password_hash

bp = Blueprint('auth', __name__)


@bp.route('/api/login', methods=['POST'])
@safe_db
def login():
    data = get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    if not username or not password:
        return err('Username dan password wajib diisi')

    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    conn.close()

    if not user or not check_password_hash(user['password_hash'], password):
        return err('Username atau password salah')

    return ok({
        'id': user['id'], 'username': user['username'],
        'role': user['role'], 'display_name': user['display_name'],
    })


@bp.route('/api/users')
@safe_db
def list_users():
    conn = get_db()
    users = conn.execute("SELECT id, username, role, display_name FROM users").fetchall()
    conn.close()
    return ok(dict_rows(users))


@bp.route('/api/users/change-password', methods=['POST'])
@safe_db
def change_password():
    data = get_json()
    user_id = data.get('user_id', '')
    old_pass = data.get('old_password', '')
    new_pass = data.get('new_password', '')
    if not all([user_id, old_pass, new_pass]):
        return err('Semua field wajib diisi')

    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    if not user or not check_password_hash(user['password_hash'], old_pass):
        conn.close()
        return err('Password lama salah')

    conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                 (generate_password_hash(new_pass), user_id))
    conn.commit()
    conn.close()
    return ok(message='Password berhasil diubah')
