"""UnitCost routes: periods, units, allocations, calculations, export."""
from flask import Blueprint, request, jsonify, send_file
from helpers import get_json, ok, err, safe_db, dict_rows, dict_row, gid, validate_float, validate_int
from db_manager import get_db
from engine import double_distribution, UnitData, AllocationEntry
import tempfile

bp = Blueprint('unitcost', __name__)


# ─── Periods ──────────────────────────────────────────────────────

@bp.route('/api/periods')
@safe_db
def get_periods():
    conn = get_db()
    rows = conn.execute("SELECT * FROM periods ORDER BY created_at DESC").fetchall()
    conn.close()
    return ok(dict_rows(rows))


@bp.route('/api/periods', methods=['POST'])
@safe_db
def create_period():
    data = get_json()
    name = data.get('name', '').strip()
    start = data.get('start_date', '')
    end = data.get('end_date', '')
    if not all([name, start, end]):
        return err('Nama, tanggal mulai, dan tanggal akhir wajib diisi')

    pid = gid()
    conn = get_db()
    conn.execute("INSERT INTO periods (id,name,start_date,end_date) VALUES (?,?,?,?)",
                 (pid, name, start, end))
    conn.commit()
    conn.close()
    return ok({'id': pid, 'name': name})


@bp.route('/api/periods/<pid>', methods=['DELETE'])
@safe_db
def delete_period(pid):
    conn = get_db()
    conn.execute("DELETE FROM periods WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return ok(message='Periode dihapus')


# ─── Units ────────────────────────────────────────────────────────

@bp.route('/api/periods/<pid>/units')
@safe_db
def get_units(pid):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM units WHERE period_id=? ORDER BY sort_order, rowid", (pid,)
    ).fetchall()
    conn.close()
    return ok(dict_rows(rows))


@bp.route('/api/periods/<pid>/units', methods=['POST'])
@safe_db
def create_unit(pid):
    data = get_json()
    name = data.get('name', '').strip()
    unit_type = data.get('unit_type', '')
    if not name or unit_type not in ('support', 'production'):
        return err('Nama dan jenis unit wajib diisi')

    uid = gid()
    conn = get_db()
    conn.execute(
        """INSERT INTO units (id,period_id,name,unit_type,direct_cost,output_volume,output_unit,cost_driver_type,sort_order)
           VALUES (?,?,?,?,?,?,?,?,?)""",
        (uid, pid, name, unit_type,
         validate_float(data.get('direct_cost', 0)),
         validate_int(data.get('output_volume', 0)),
         data.get('output_unit', ''),
         data.get('cost_driver_type', ''),
         validate_int(data.get('sort_order', 0)))
    )
    conn.commit()
    conn.close()
    return ok({'id': uid, 'name': name})


@bp.route('/api/units/<uid>', methods=['PUT'])
@safe_db
def update_unit(uid):
    data = get_json()
    conn = get_db()
    unit = conn.execute("SELECT * FROM units WHERE id=?", (uid,)).fetchone()
    if not unit:
        conn.close()
        return err('Unit tidak ditemukan', 404)

    conn.execute(
        """UPDATE units SET name=?, unit_type=?, direct_cost=?, output_volume=?,
           output_unit=?, cost_driver_type=?, sort_order=? WHERE id=?""",
        (data.get('name', unit['name']),
         data.get('unit_type', unit['unit_type']),
         validate_float(data.get('direct_cost', unit['direct_cost'])),
         validate_int(data.get('output_volume', unit['output_volume'])),
         data.get('output_unit', unit['output_unit']),
         data.get('cost_driver_type', unit['cost_driver_type']),
         validate_int(data.get('sort_order', unit['sort_order'])),
         uid)
    )
    conn.commit()
    conn.close()
    return ok()


@bp.route('/api/units/<uid>', methods=['DELETE'])
@safe_db
def delete_unit(uid):
    conn = get_db()
    conn.execute("DELETE FROM allocations WHERE from_unit_id=? OR to_unit_id=?", (uid, uid))
    conn.execute("DELETE FROM units WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    return ok(message='Unit dihapus')


# ─── Allocations ──────────────────────────────────────────────────

@bp.route('/api/periods/<pid>/allocations')
@safe_db
def get_allocations(pid):
    conn = get_db()
    unit_ids = [r['id'] for r in conn.execute("SELECT id FROM units WHERE period_id=?", (pid,)).fetchall()]
    if not unit_ids:
        conn.close()
        return ok([])
    placeholders = ','.join('?' * len(unit_ids))
    rows = conn.execute(
        f"SELECT * FROM allocations WHERE from_unit_id IN ({placeholders})", unit_ids
    ).fetchall()
    conn.close()
    return ok(dict_rows(rows))


@bp.route('/api/periods/<pid>/allocations', methods=['POST'])
@safe_db
def save_allocations(pid):
    data = get_json()  # list of {from_unit_id, to_unit_id, driver_value}
    entries = data if isinstance(data, list) else data.get('entries', [])

    conn = get_db()
    unit_ids = [r['id'] for r in conn.execute("SELECT id FROM units WHERE period_id=?", (pid,)).fetchall()]
    if unit_ids:
        placeholders = ','.join('?' * len(unit_ids))
        conn.execute(f"DELETE FROM allocations WHERE from_unit_id IN ({placeholders})", unit_ids)

    # Group by from_unit to calculate proportions
    from_groups = {}
    for e in entries:
        fid = e['from_unit_id']
        from_groups.setdefault(fid, []).append(e)

    for fid, group in from_groups.items():
        total_driver = sum(validate_float(e.get('driver_value', 0)) for e in group)
        for e in group:
            dv = validate_float(e.get('driver_value', 0))
            proportion = round(dv / total_driver, 6) if total_driver > 0 else 0
            conn.execute(
                "INSERT INTO allocations (id,from_unit_id,to_unit_id,driver_value,proportion) VALUES (?,?,?,?,?)",
                (gid(), fid, e['to_unit_id'], dv, proportion)
            )

    conn.commit()
    conn.close()
    return ok(message='Alokasi disimpan')


# ─── Calculation ──────────────────────────────────────────────────

@bp.route('/api/periods/<pid>/calculate', methods=['POST'])
@safe_db
def calculate(pid):
    conn = get_db()
    units_db = conn.execute(
        "SELECT * FROM units WHERE period_id=? ORDER BY sort_order", (pid,)
    ).fetchall()

    support = [u for u in units_db if u['unit_type'] == 'support']
    production = [u for u in units_db if u['unit_type'] == 'production']

    if not support:
        conn.close()
        return err('Tidak ada unit penunjang')
    if not production:
        conn.close()
        return err('Tidak ada unit produksi')

    for pu in production:
        if pu['output_volume'] <= 0:
            conn.close()
            return err(f"Volume output '{pu['name']}' harus > 0")

    unit_ids = [u['id'] for u in units_db]
    placeholders = ','.join('?' * len(unit_ids))
    allocs_db = conn.execute(
        f"SELECT * FROM allocations WHERE from_unit_id IN ({placeholders})", unit_ids
    ).fetchall()

    for su in support:
        su_allocs = [a for a in allocs_db if a['from_unit_id'] == su['id']]
        if not su_allocs:
            conn.close()
            return err(f"Unit penunjang '{su['name']}' belum punya alokasi")

    # Build engine data
    engine_units = [
        UnitData(id=u['id'], name=u['name'], unit_type=u['unit_type'],
                 direct_cost=u['direct_cost'], output_volume=u['output_volume'],
                 output_unit=u['output_unit'])
        for u in units_db
    ]
    engine_allocs = [
        AllocationEntry(from_unit_id=a['from_unit_id'], to_unit_id=a['to_unit_id'],
                        proportion=a['proportion'])
        for a in allocs_db
    ]

    result = double_distribution(engine_units, engine_allocs)

    # Build name lookup
    name_map = {u['id']: u['name'] for u in units_db}

    # Save calculation
    calc_id = gid()
    conn.execute("INSERT INTO calculations (id,period_id,method) VALUES (?,?,?)",
                 (calc_id, pid, 'double_distribution'))

    response_results = []
    for u_id in [u['id'] for u in production]:
        u = result['results'][u_id]
        rid = gid()
        conn.execute(
            """INSERT INTO calculation_results
               (id,calculation_id,unit_id,unit_name,direct_cost,indirect_cost,total_cost,output_volume,output_unit,unit_cost)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (rid, calc_id, u.id, u.name, u.direct_cost,
             round(u.indirect_cost, 2), round(u.total_cost, 2),
             u.output_volume, u.output_unit, round(u.unit_cost, 2))
        )
        response_results.append({
            'unit_id': u.id, 'unit_name': u.name,
            'direct_cost': u.direct_cost, 'indirect_cost': round(u.indirect_cost, 2),
            'total_cost': round(u.total_cost, 2), 'output_volume': u.output_volume,
            'output_unit': u.output_unit, 'unit_cost': round(u.unit_cost, 2),
        })

    # Save distribution details
    for d in result['distributions']:
        conn.execute(
            """INSERT INTO distribution_details
               (calculation_id,stage,from_unit_id,from_unit_name,to_unit_id,to_unit_name,amount)
               VALUES (?,?,?,?,?,?,?)""",
            (calc_id, d.stage, d.from_unit_id, name_map.get(d.from_unit_id, ''),
             d.to_unit_id, name_map.get(d.to_unit_id, ''), round(d.amount, 2))
        )

    conn.commit()
    conn.close()

    return ok({
        'calculation_id': calc_id,
        'method': 'double_distribution',
        'total_initial': round(result['total_initial'], 2),
        'total_final': round(result['total_final'], 2),
        'results': response_results,
    })


@bp.route('/api/periods/<pid>/calculations')
@safe_db
def get_calculations(pid):
    conn = get_db()
    calcs = conn.execute(
        "SELECT * FROM calculations WHERE period_id=? ORDER BY calculated_at DESC", (pid,)
    ).fetchall()

    result = []
    for c in calcs:
        results = conn.execute(
            "SELECT * FROM calculation_results WHERE calculation_id=?", (c['id'],)
        ).fetchall()
        result.append({
            'id': c['id'], 'method': c['method'],
            'calculated_at': c['calculated_at'],
            'results': dict_rows(results),
        })

    conn.close()
    return ok(result)


@bp.route('/api/calculations/<cid>/details')
@safe_db
def get_calc_details(cid):
    conn = get_db()
    results = conn.execute(
        "SELECT * FROM calculation_results WHERE calculation_id=?", (cid,)
    ).fetchall()
    details = conn.execute(
        "SELECT * FROM distribution_details WHERE calculation_id=? ORDER BY stage, rowid", (cid,)
    ).fetchall()
    conn.close()
    return ok({'results': dict_rows(results), 'distributions': dict_rows(details)})


# ─── Export Excel ─────────────────────────────────────────────────

@bp.route('/api/calculations/<cid>/export/excel')
@safe_db
def export_excel(cid):
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from helpers import get_clinic_name

    conn = get_db()
    calc = conn.execute("SELECT * FROM calculations WHERE id=?", (cid,)).fetchone()
    if not calc:
        conn.close()
        return err('Perhitungan tidak ditemukan', 404)

    period = conn.execute("SELECT * FROM periods WHERE id=?", (calc['period_id'],)).fetchone()
    results = conn.execute(
        "SELECT * FROM calculation_results WHERE calculation_id=? ORDER BY rowid", (cid,)
    ).fetchall()
    conn.close()

    wb = Workbook()
    ws = wb.active
    ws.title = "Unit Cost"

    header_font = Font(bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="0891b2", end_color="0891b2", fill_type="solid")
    border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )
    currency_fmt = '#,##0'

    clinic = get_clinic_name()
    ws.merge_cells("A1:G1")
    ws["A1"] = clinic
    ws["A1"].font = Font(bold=True, size=14)

    ws.merge_cells("A2:G2")
    ws["A2"] = f"Laporan Unit Cost — {period['name'] if period else ''}"
    ws["A2"].font = Font(bold=True, size=12)

    ws.merge_cells("A3:G3")
    ws["A3"] = f"Metode: Double Distribution | {calc['calculated_at']}"
    ws["A3"].font = Font(size=10, italic=True)

    headers = ["No", "Unit Produksi", "Biaya Langsung", "Biaya Tidak Langsung",
               "Total Biaya", "Volume Output", "Unit Cost"]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=5, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")
        cell.border = border

    for i, r in enumerate(results, 1):
        row = i + 5
        ws.cell(row=row, column=1, value=i).border = border
        ws.cell(row=row, column=2, value=r['unit_name']).border = border
        c3 = ws.cell(row=row, column=3, value=r['direct_cost'])
        c3.border = border; c3.number_format = currency_fmt
        c4 = ws.cell(row=row, column=4, value=r['indirect_cost'])
        c4.border = border; c4.number_format = currency_fmt
        c5 = ws.cell(row=row, column=5, value=r['total_cost'])
        c5.border = border; c5.number_format = currency_fmt
        c6 = ws.cell(row=row, column=6, value=r['output_volume'])
        c6.border = border; c6.number_format = '#,##0'
        c7 = ws.cell(row=row, column=7, value=r['unit_cost'])
        c7.border = border; c7.number_format = currency_fmt

    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 22
    ws.column_dimensions["E"].width = 20
    ws.column_dimensions["F"].width = 16
    ws.column_dimensions["G"].width = 18

    tmp = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
    wb.save(tmp.name)
    tmp.close()

    pname = period['name'].replace(' ', '_') if period else 'export'
    return send_file(
        tmp.name, as_attachment=True,
        download_name=f"unit_cost_{pname}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
