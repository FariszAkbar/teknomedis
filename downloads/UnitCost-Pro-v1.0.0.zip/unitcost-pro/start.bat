@echo off
cd /d "%~dp0"
echo Starting UnitCost Pro...
python app.py
pause
