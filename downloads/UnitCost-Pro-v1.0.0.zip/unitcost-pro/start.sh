#!/bin/bash
cd "$(dirname "$0")"
echo "Starting UnitCost Pro..."
python3 app.py &
echo "UnitCost Pro started. Open http://localhost:5050"
