@echo off
echo Stopping UnitCost Pro...
taskkill /f /im python.exe 2>nul
echo Done.
pause
